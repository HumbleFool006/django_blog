#$Id$
import traceback
import time
import os, sys
from datetime import datetime
import json
import struct
from six.moves.urllib.parse import urlencode

from . import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
import com.manageengine.monagent.notify 
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util import ConfigHandler
from com.manageengine.monagent.discovery import HostHandler
from com.manageengine.monagent.scheduler import AgentScheduler
from com.manageengine.monagent.collector import DataCollector
from com.manageengine.monagent.collector import DataConsolidator
from com.manageengine.monagent.communication import CommunicationHandler, DMSHandler, AgentStatusHandler, BasicClientHandler, applog
from com.manageengine.monagent.docker import DockerAgent
from com.manageengine.monagent.upgrade import AgentUpgrader
from com.manageengine.monagent.network.AgentPingHandler import PingUtil
import com.manageengine.monagent.network
import com.manageengine.monagent.util.rca

isInstance = False
instanceDict = {}

dictErrorValues = {'3000': 'Wrong Device Key',
                   '3001' : 'Insufficient credits',
                   '3002' : 'Exception - Like extra params',
                   '3003' : 'Exception - Invalid param',
                   '3004' : 'Exception - params exceeds length'
                   }

def initialize():
    global isInstance,instanceDict
    AgentUtil.isWarmShutdown()
    if not loadAgentConfiguration():        
        return False
    domainDecider()
    if not evaluateAgentParameters():
        AgentLogger.log(AgentLogger.CRITICAL,' ************************* Exception While Evaluating Agent Parameters ************************* ')
        return False
    com.manageengine.monagent.communication.initialize()
    com.manageengine.monagent.actions.initialize()
    AgentStatusHandler.HEART_BEAT_THREAD = AgentStatusHandler.HeartBeatThread()
    AgentStatusHandler.HEART_BEAT_THREAD.setDaemon(True)
    AgentStatusHandler.HEART_BEAT_THREAD.start()
    CommunicationHandler.updateProxyDetails()
    bool_return,version = AgentUtil.getAgentVersion()
    CommunicationHandler.checkNetworkStatus()
    if not isAgentRegistered() and not CommunicationHandler.isServerReachable(3600, 60,AgentLogger.MAIN):# Trying to reach server for a day if the agent is not registered 
        AgentLogger.log(AgentLogger.MAIN,'Agent not registered and server not reachable.\n')
        return False
    if not HostHandler.initialize():
        return False
    AgentLogger.log(AgentLogger.MAIN,'Monitoring Agent Version - {0}'.format(version)+'\n')
    if AgentConstants.OS_NAME == AgentConstants.LINUX_OS:
        isInstance,instanceDict = getInstanceMetadata()
    if not isAgentRegistered() and not registerAgent():       
        AgentLogger.log(AgentLogger.MAIN,' Agent Registration with Server | Status - Failure ')
        return False
    AgentUtil.calculateNoOfCpuCores()
    AgentUtil.getSystemUUID()
    #check this
    if isAgentRegistered():
        if not reRegisterAgent():
            AgentLogger.log(AgentLogger.STDERR,' ************************* Re Registration Fails ************************* ')
            return False
        if AgentConstants.UPTIME_MONITORING=='false' and AgentConstants.OS_NAME==AgentConstants.LINUX_OS:
            DockerAgent.initializeDocker()
        if not initializeAgentModules():
            AgentLogger.log(AgentLogger.MAIN,'Agent Modules Initialized | Status - Failure.\n')
            return False
    if not isAgentProfileExist():
        AgentLogger.log(AgentLogger.STDOUT,'Agent Profile Not Exist | Status - Failure.\n')
        return False
    AgentLogger.log(AgentLogger.STDOUT,'Agent Profile Exist | Status - Success.\n')
    if not AgentUpgrader.initialize():
        AgentLogger.log(AgentLogger.MAIN,'Upgrade Module - Failure.\n')
        return False
    AgentLogger.log(AgentLogger.MAIN,'Upgrade Module - Success.\n')
    #check the order of status update here.
    if not AgentStatusHandler.initialize():
        AgentLogger.log(AgentLogger.MAIN,'Status Updater - Failure.\n')
        return False
    AgentLogger.log(AgentLogger.MAIN,'Status Updater - Success.\n')
    CommunicationHandler.checkNetworkStatus()
    #check if has to be removed
    AgentUtil.handleSpecialTasks()    
    #PingUtil.getPeerCheck() - will get it in response header
    if AgentConstants.OS_NAME == AgentConstants.LINUX_OS and isInstance:
        sendinstanceMetadata()
    #azure start status update
    try:
        if AgentUtil.AGENT_CONFIG.has_section('AGENT_INFO') and ((AgentUtil.AGENT_CONFIG.get('AGENT_INFO','agent_instance_type')==AgentConstants.AZURE_INSTANCE) or (AgentUtil.AGENT_CONFIG.get('AGENT_INFO','agent_instance_type')==AgentConstants.AZURE_INSTANCE_CLASSIC)):
            AgentUtil.do_status_report('Agent Startup','success',0,'Agent started successfully')
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT, AgentLogger.STDERR],' Exception While updating agent start status ')
        traceback.print_exc()
        
        
    DataCollector.executePlugins()  
    return True

def domainDecider():
    try:
        (bool_status, list_dict) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_CHECK_SERVER_LIST_FILE)
        if bool_status:
            for list_domains in list_dict.keys():
                if str(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')).startswith(str(list_domains)+'_'):
                    persistDomains(list_dict[list_domains])
                    
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' ************************* Exception while choosing domain for agent ************************* '+ repr(e))

def isAgentProfileExist():
    bool_toReturn = True
    try:
        if not os.path.exists(AgentConstants.AGENT_PROFILE_FILE):
            AgentConstants.AGENT_WARM_START = False
            AgentLogger.log(AgentLogger.STDOUT,'========================== Creating agent profile ======================== ')
            dict_profileData = {}
            if AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key') != '0' and AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id') != '0':
                dict_profileData['AGENT_KEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')  
                dict_profileData['AGENT_UNIQUE_ID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
                bool_toReturn = AgentUtil.persistProfile(AgentConstants.AGENT_PROFILE_FILE, dict_profileData)    
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' ************************* Exception while creating agent profile ************************* '+ repr(e))
        traceback.print_exc()
        bool_toReturn = False
    return bool_toReturn
    

def initializeAgentModules():
    #addd logs here
    DMSHandler.initialize()
    BasicClientHandler.initialize()
    AgentScheduler.initialize()
    DataConsolidator.updateAgentConfig(True)
    if not DataCollector.initialize():
        AgentLogger.log([AgentLogger.MAIN,AgentLogger.CRITICAL],'Agent Data Collection Initialized | Status - Failure \n')
        return False
#    else:
#        MemoryManager.initialize()    
##        else:
##            ListenerThread.initialize()
##        loadQueryConfAndCollectData()

    AgentLogger.log(AgentLogger.MAIN, "Going to start applog agent \n")
    applog.start()
    
    AgentLogger.log(AgentLogger.MAIN,'Data Collection Module - Success \n')
    AgentLogger.log([AgentLogger.STDOUT],'=============================== AGENT INITIALIZATION SUCCESSFUL ===============================')
    return True
    
def loadAgentConfiguration():
    try:
        if not os.path.exists(AgentConstants.AGENT_CONF_FILE):
            AgentLogger.log(AgentLogger.MAIN,'************************* Missing agent configuration file : '+AgentConstants.AGENT_CONF_FILE+' ************************* \n')
            return False
        AgentUtil.AGENT_CONFIG.read(AgentConstants.AGENT_CONF_FILE)
        (bool_status, dataFromFile) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PARAMS_FILE)        
        if bool_status:   
            AgentUtil.AGENT_PARAMS = dataFromFile     
            AgentLogger.log(AgentLogger.STDOUT,'Agent params loaded from '+AgentConstants.AGENT_PARAMS_FILE+' : '+repr(AgentUtil.AGENT_PARAMS))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Error while loading '+AgentConstants.AGENT_PARAMS_FILE+'. Setting AGENT_PARAMS to default values : '+repr(AgentUtil.AGENT_PARAMS))
        loadProductProfile()
        setAgentConstants()
        #checkAzureInstance()
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' ************************* Exception while loading agent configuration ************************* '+ repr(e))
        traceback.print_exc()
        return False
    return True

def updateAgentConfiguration():
    isConfUpdated = False
    try:
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'status_update_interval'):
            AgentConstants.STATUS_UPDATE_INTERVAL = int(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'status_update_interval'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding status_update_interval to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'status_update_interval', str(AgentConstants.STATUS_UPDATE_INTERVAL))
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_section('APPS_INFO'):
            #AgentConstants.DOCKER_KEY = AgentUtil.AGENT_CONFIG.get('APPS_INFO', 'docker_key')
            if AgentUtil.AGENT_CONFIG.has_option('APPS_INFO', 'docker_enabled'):
                AgentConstants.AGENT_DOCKER_ENABLED = int(AgentUtil.AGENT_CONFIG.get('APPS_INFO', 'docker_enabled'))
            else:
                AgentUtil.AGENT_CONFIG.set('APPS_INFO', 'docker_enabled',AgentConstants.AGENT_DOCKER_ENABLED)
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding docker_info to conf file')
            AgentUtil.AGENT_CONFIG.add_section('APPS_INFO')
            AgentUtil.AGENT_CONFIG.set('APPS_INFO', 'docker_key', AgentConstants.DEFAULT_DOCKER_KEY)
            AgentUtil.AGENT_CONFIG.set('APPS_INFO', 'docker_enabled', AgentConstants.AGENT_DOCKER_ENABLED )
        if AgentUtil.AGENT_CONFIG.has_section('SECONDARY_SERVER_INFO'):
            AgentConstants.SECONDARY_SERVER_NAME = AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_name')
            AgentConstants.SECONDARY_SERVER_IP_ADDRESS = AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_ip_address')
            AgentConstants.SECONDARY_SERVER_PORT = AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_port')
            AgentConstants.SECONDARY_SERVER_PROTOCOL = AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_protocol')
            AgentConstants.SECONDARY_SERVER_TIMEOUT = AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_timeout')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding secondary_server_info to conf file')
            AgentUtil.AGENT_CONFIG.add_section('SECONDARY_SERVER_INFO')
            AgentUtil.AGENT_CONFIG.set('SECONDARY_SERVER_INFO', 'server_name', str(AgentConstants.SECONDARY_SERVER_NAME))
            AgentUtil.AGENT_CONFIG.set('SECONDARY_SERVER_INFO', 'server_ip_address', str(AgentConstants.SECONDARY_SERVER_IP_ADDRESS))
            AgentUtil.AGENT_CONFIG.set('SECONDARY_SERVER_INFO', 'server_port', str(AgentConstants.SECONDARY_SERVER_PORT))
            AgentUtil.AGENT_CONFIG.set('SECONDARY_SERVER_INFO', 'server_protocol', str(AgentConstants.SECONDARY_SERVER_PROTOCOL))
            AgentUtil.AGENT_CONFIG.set('SECONDARY_SERVER_INFO', 'server_timeout', str(AgentConstants.SECONDARY_SERVER_TIMEOUT))
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_section('UDP_SERVER_INFO'):
            AgentConstants.UDP_SERVER_IP = AgentUtil.AGENT_CONFIG.get('UDP_SERVER_INFO', 'udp_server_ip')
            AgentConstants.UDP_PORT = AgentUtil.AGENT_CONFIG.get('UDP_SERVER_INFO', 'udp_server_port')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding udp server ip info to conf file')
            AgentUtil.AGENT_CONFIG.add_section('UDP_SERVER_INFO')
            AgentUtil.AGENT_CONFIG.set('UDP_SERVER_INFO', 'udp_server_ip', AgentConstants.UDP_SERVER_IP)
            AgentUtil.AGENT_CONFIG.set('UDP_SERVER_INFO', 'udp_server_port', AgentConstants.UDP_PORT)
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'agent_instance_type'):
            AgentConstants.AGENT_INSTANCE_TYPE = str(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_instance_type'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding agent_instance_type to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_instance_type', str(AgentConstants.AGENT_INSTANCE_TYPE))
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'count'):
            AgentConstants.PLUGINS_COUNT = str(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'count'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding count(plugin) to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'count', str(AgentConstants.PLUGINS_COUNT))
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'pl_zip_task_interval'):
            AgentConstants.PLUGINS_ZIP_INTERVAL = int(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'pl_zip_task_interval'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding pl_zip_task_interval count(plugin) to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'pl_zip_task_interval', AgentConstants.PLUGINS_ZIP_INTERVAL)
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'pl_dc_task_interval'):
            AgentConstants.PLUGINS_DC_INTERVAL = int(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'pl_dc_task_interval'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding pl_dc_task_interval count(plugin) to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'pl_dc_task_interval', AgentConstants.PLUGINS_DC_INTERVAL)
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'pl_dc_zip_count'):
            AgentConstants.PLUGINS_ZIP_FILE_SIZE = int(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'pl_dc_zip_count'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding dc_upload_interval count(plugin) to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'pl_dc_zip_count', AgentConstants.PLUGINS_ZIP_FILE_SIZE)
            isConfUpdated = True
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO', 'dc_upload_interval'):
            AgentConstants.UPLOAD_CHECK_INTERVAL = int(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'dc_upload_interval'))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Adding dc_upload_interval count(agent) to conf file')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'dc_upload_interval', AgentConstants.UPLOAD_CHECK_INTERVAL)
            isConfUpdated = True
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while updating agent configuration ************************* '+ repr(e))
        traceback.print_exc()
    finally:
        if isConfUpdated:
            AgentUtil.persistAgentInfo()
                    
def setAgentConstants():
    #product details
    str_productName = AgentUtil.AGENT_CONFIG.get('PRODUCT', 'product_name')        
    AgentConstants.AGENT_REGISTRATION_KEY = AgentUtil.AGENT_CONFIG.get('PRODUCT_REGISTRATION_KEY', str_productName)
    #dms details
    AgentConstants.DMS_SERVER = AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_server_name')
    AgentConstants.DMS_PORT = AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_server_port')
    AgentConstants.DMS_PRODUCT_CODE = AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_product_code')
    if AgentUtil.AGENT_CONFIG.get('PRODUCT', 'product_name') == 'SITE24X7':
        AgentConstants.AGENT_UPGRADE_CONTEXT = 'sagent'
    AgentConstants.AGENT_PREVIOUS_TIME_DIFF = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'time_diff')
    updateAgentConfiguration()
    boolStatus, strAgentVersion = AgentUtil.getAgentBuildNumber()
    if boolStatus:
        AgentConstants.AGENT_VERSION = strAgentVersion
        
        
def checkAzureInstance():
    try:
        if AgentConstants.AGENT_INSTANCE_TYPE=='SERVER':
            if os.path.isfile(AgentConstants.AZURE_AGENT_PATH):
                AgentConstants.AGENT_INSTANCE_TYPE=AgentConstants.AZURE_INSTANCE
            elif os.path.exists(AgentConstants.AZURE_LIB_PATH):
                AgentConstants.AGENT_INSTANCE_TYPE=AgentConstants.AZURE_INSTANCE
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while checking for azure instance ************************* '+ repr(e))
        traceback.print_exc()


def loadProductProfile():
    AgentConstants.LINUX_DIST = None
    file_obj = None
    if os.path.exists(AgentConstants.AGENT_PRODUCT_PROFILE_FILE):
        try:
            file_obj = open(AgentConstants.AGENT_PRODUCT_PROFILE_FILE,'r')
            str_data = file_obj.readline()
            str_linDist = str_data.split(';')[0]
            list_linDist = str_linDist.split('=')
            if list_linDist[0] == 'LINUX_DIST':
                AgentConstants.LINUX_DIST = list_linDist[1]
            AgentLogger.log(AgentLogger.STDOUT,'Linux distro from '+repr(AgentConstants.AGENT_PRODUCT_PROFILE_FILE)+' : '+repr(AgentConstants.LINUX_DIST));   
            str_data = file_obj.readline()
            str_osVa = str_data.split(';')[0]
            list_osVa = str_osVa.split('=')
            if list_osVa[0] == 'OS_VERSION_ARCH':
                AgentConstants.OS_VERSION_ARCH = list_osVa[1]
            if AgentConstants.OS_VERSION_ARCH:
                AgentLogger.log(AgentLogger.STDOUT,'OS_Version_Arch from '+repr(AgentConstants.AGENT_PRODUCT_PROFILE_FILE)+' : '+repr(AgentConstants.OS_VERSION_ARCH));      
        except:
            AgentLogger.log(AgentLogger.MAIN,'************************* Exception while reading the file '+AgentConstants.AGENT_PRODUCT_PROFILE_FILE+' ************************* \n')
            traceback.print_exc()
            bool_returnStatus = False
        finally:
            if not file_obj == None:
                file_obj.close()
    else:
        AgentLogger.log(AgentLogger.MAIN,'************************* Missing Conf File : '+AgentConstants.AGENT_PRODUCT_PROFILE_FILE+' ************************* \n')

        
def evaluateAgentParameters():    
    bool_isAgentInfoModified = False
    #AgentLogger.log(AgentLogger.STDOUT,'========================== PPPPPPPPPPPPP ======================== ')
    #AgentLogger.log(AgentLogger.STDOUT,''+repr(dir(AgentConstants)))
    #AgentLogger.log(AgentLogger.STDOUT,''+repr(AgentConstants.getAgentConstants()))
    AgentLogger.log(AgentLogger.STDOUT,'=========================== AGENT CONSTANTS ===========================')            
    list_sections = AgentUtil.AGENT_CONFIG.sections()
    for sec in list_sections:
        for key, value in AgentUtil.AGENT_CONFIG.items(sec):
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : '+key+' : '+repr(value))
    AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : AGENT_TIME_ZONE : '+repr(AgentConstants.AGENT_TIME_ZONE))
    AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : AGENT_TIME_DIFF_FROM_GMT : '+repr(AgentConstants.AGENT_TIME_DIFF_FROM_GMT))
    AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : AGENT_REGISTRATION_KEY :  '+str(AgentConstants.AGENT_REGISTRATION_KEY)) 
    AgentLogger.log(AgentLogger.STDOUT,'=========================== AGENT CONSTANTS ===========================')
    # check and update agent version from $HOME/version.txt - version changes during upgrade.  
    bool_status, str_agentVersion = AgentUtil.getAgentVersion()
    if bool_status:
        if AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_version') == '0' or AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_version') != str_agentVersion:
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_version', str(str_agentVersion))        
            bool_isAgentInfoModified = True
    else:            
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : Unable to obtain agent version from the file : '+AgentConstants.AGENT_VERSION_FILE)
        return False
    if AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name') == '' or AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name') == '0':
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : SERVER_NAME Is Empty. Agent Initialization Failed!!!')
        return False
    if AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_ip_address') == '':    
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : SERVER_IP_ADDRESS Is Empty. Agent Initialization Failed!!!')
        return False
    if AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port') == '' or AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port') == '0':    
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : SERVER_PORT Is Empty. Agent Initialization Failed!!!')
        return False
    if AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_protocol') == '' or AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_protocol') == '0':    
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : SERVER_PROTOCOL Is Empty. Agent Initialization Failed!!!')
        return False  
    if AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_server_name') == '' or AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_server_name') == '0':
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : DMS_SERVER_NAME Is Empty. Agent Initialization Failed!!!')
        return False
    if AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_server_port') == '' or AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_server_port') == '0':
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : DMS_SERVER_PORT Is Empty. Agent Initialization Failed!!!')
        return False
    if AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_product_code') == '' or AgentUtil.AGENT_CONFIG.get('DMS_INFO', 'dms_product_code') == '0':
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : DMS_PRODUCT_CODE Is Empty. Agent Initialization Failed!!!')
        return False
    if AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id') == '0':       
        AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_unique_id', str(AgentUtil.getUniqueId()))        
        bool_isAgentInfoModified = True
        AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : AGENT_UNIQUE_ID Is Empty. Assigned Temporary Value : '+AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id'))
    if bool_isAgentInfoModified:
        AgentUtil.persistAgentInfo()
    CommunicationHandler.initialize()
    return True

def isAgentRegistered():
    if AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key') == '0':    
        return False
    else:
        return True
        
def addRebootParam(dict_dataForAgentRegistration):
    try:
        for dirname, dirnames, filenames in os.walk(AgentConstants.AGENT_TEMP_DIR):
            for file in filenames:  
                if 'reboot_' in file:
                    fileSplit = file.split('_')
                    dict_dataForAgentRegistration['ACTIONREBOOTINITTIME'] = fileSplit[1]+','+fileSplit[2]
                    AgentLogger.log(AgentLogger.STDOUT,'file name for reboot : '+repr(fileSplit))
                    os.remove(AgentConstants.AGENT_TEMP_DIR+'/'+file)
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'exception while adding reboot param ')
        traceback.print_exc()
        
def reRegisterAgent():
    bool_toReturn = True
    bool_isFirstTime = True
    bool_isAgentInfoModified = False
    str_servlet = AgentConstants.AGENT_REGISTRATION_SERVLET
    bool_retry = True  
    int_retryCount = 0
    dict_dataForAgentRegistration = {}
    try:
        #Hardcoded Registration Parameters        
        dict_dataForAgentRegistration['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_dataForAgentRegistration['category'] = AgentUtil.AGENT_CONFIG.defaults().get('category')        
        dict_dataForAgentRegistration['updateStatus'] = AgentUtil.AGENT_CONFIG.defaults().get('update_status')
        if os.path.exists(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE):
            AgentLogger.log(AgentLogger.STDOUT,'watcher restart file exists : ')
            dict_dataForAgentRegistration['updateStatus'] = 'no'
            os.remove(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE)
        
        addRebootParam(dict_dataForAgentRegistration)
        
        dict_dataForAgentRegistration['agentVersion'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_version')
        dict_dataForAgentRegistration['isMasterAgent'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'master_agent')
        
        #dict_dataForAgentRegistration['agentType'] = AgentConstants.OS_NAME
        dict_dataForAgentRegistration['monagentID'] = AgentConstants.HOST_NAME
        dict_dataForAgentRegistration['IpAddress'] = AgentConstants.IP_ADDRESS
        dict_dataForAgentRegistration['MACAddress'] = AgentConstants.MAC_ADDRESS
        dict_dataForAgentRegistration['bno'] = AgentConstants.AGENT_VERSION
        #dict_dataForAgentRegistration['osFlavor'] = AgentConstants.OS_FLAVOR
        dict_dataForAgentRegistration['osName'] = AgentConstants.OS_NAME
        dict_dataForAgentRegistration['monagentDNS'] = AgentConstants.HOST_FQDN_NAME
        dict_dataForAgentRegistration['monagentKey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_dataForAgentRegistration['agentUniqueID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
        dict_dataForAgentRegistration['freeServiceFormat'] = 'json'
        
        upTime,serverRestart,bootTime = AgentUtil.getBootTime()
        
        if not upTime==None:
            dict_dataForAgentRegistration['upTime'] = upTime
        
        if not serverRestart==None and serverRestart:
            dict_dataForAgentRegistration['serverRestart']='true'
            
        if not bootTime==None:
            dict_dataForAgentRegistration['bootTime']=bootTime
            
        if not AgentConstants.DOMAIN_NAME == None:
            dict_dataForAgentRegistration['DomainName'] = AgentConstants.DOMAIN_NAME
            
        if not AgentConstants.SYSTEM_UUID == None:
            dict_dataForAgentRegistration['uuid'] = AgentConstants.SYSTEM_UUID
         
        if 'monagentDNS' in dict_dataForAgentRegistration and 'monagentID' in dict_dataForAgentRegistration and dict_dataForAgentRegistration['monagentDNS']=='localhost' and dict_dataForAgentRegistration['monagentID']!='localhost':
            dict_dataForAgentRegistration['monagentDNS'] = dict_dataForAgentRegistration['monagentID']
        
        if 'monagentDNS' in dict_dataForAgentRegistration and 'monagentID' in dict_dataForAgentRegistration and dict_dataForAgentRegistration['monagentDNS']=='localhost.localdomain' and dict_dataForAgentRegistration['monagentID']!='localhost.localdomain':
            dict_dataForAgentRegistration['monagentDNS'] = dict_dataForAgentRegistration['monagentID']
            
        if isInstance:
            bool_to_return,id = getInstanceId(instanceDict['cloudPlatform'],instanceDict)
            if bool_to_return and id is not None: 
                dict_dataForAgentRegistration['instanceId'] = id
            if 'cloudPlatform' in instanceDict.keys():
                dict_dataForAgentRegistration['cloudPlatform'] = instanceDict['cloudPlatform']
            
        AgentLogger.log([AgentLogger.STDOUT],'================================= RE-REGISTER AGENT =================================')
        while bool_retry and not AgentUtil.TERMINATE_AGENT:
            bool_retry = False
            int_retryCount+=1            
            if int_retryCount > AgentConstants.AGENT_REGISTRATION_RETRY_COUNT:
                bool_toReturn = False
                AgentLogger.log([AgentLogger.STDOUT, AgentLogger.MAIN],'************* Failed to re-register agent more than 10 times *************** \n' )
                break
            elif not bool_isFirstTime:
                AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.AGENT_REGISTRATION_RETRY_INTERVAL)
            elif bool_isFirstTime:
                bool_isFirstTime = False
            try:                
                dict_dataForAgentRegistration['timeStamp'] = str(AgentUtil.getCurrentTimeInMillis())
                AgentLogger.log(AgentLogger.STDOUT,'Data For Registration : '+repr(dict_dataForAgentRegistration))
                dict_processData = DataCollector.ProcessUtil.discoverProcessForRegisterAgent()
                if dict_processData:
                    str_jsonData = json.dumps(dict_processData)#python dictionary to json string
                else:
                    str_jsonData = ''
                AgentLogger.log(AgentLogger.STDOUT, 'Process details collected : '+repr(str_jsonData))
                str_url = None
                if not dict_dataForAgentRegistration == None:
                    str_requestParameters = urlencode(dict_dataForAgentRegistration)
                    str_url = str_servlet + str_requestParameters
                requestInfo = CommunicationHandler.RequestInfo()
                requestInfo.set_loggerName(AgentLogger.STDOUT)
                requestInfo.set_method(AgentConstants.HTTP_POST)
                requestInfo.set_url(str_url)
                requestInfo.set_data(str_jsonData)
                requestInfo.add_header("Content-Type", 'application/json')
                requestInfo.add_header("Accept", "text/plain")
                requestInfo.add_header("Connection", 'close')
                (isSuccess, int_errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)        
                if not dict_responseHeaders == None and 'FREE_SERVICE_DETAILS' in dict_responseHeaders:
                    dict_freeProcessDetails = json.loads(dict_responseHeaders['FREE_SERVICE_DETAILS'])#String to python object (dictionary)
                    AgentLogger.log(AgentLogger.STDOUT, 'Process to be monitored : '+repr(dict_freeProcessDetails))       
                    DataCollector.FREE_PROCESS_LIST = dict_freeProcessDetails['FreeProcessDetails']   
                else:
                    AgentLogger.log(AgentLogger.STDOUT, 'Process to be monitored is empty in reponse header map : '+repr(dict_responseHeaders))
                CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'REGISTER AGENT')                             
                if not isSuccess:
                    AgentLogger.log(AgentLogger.MAIN,'*************************** Unable To Send Agent Registration Data To Server. Will Retry Registration After 30 seconds *************************** \n')                    
                    bool_retry = True
                elif isSuccess and dict_responseHeaders == None:
                    AgentLogger.log(AgentLogger.MAIN,'*************************** Registration Response From The Server Is None. Will Retry Registration After 30 seconds *************************** \n')
                    bool_retry = True
                elif ((dict_responseHeaders) and ('errorCode' in dict_responseHeaders) and (dict_responseHeaders['errorCode'] != '0')):
                    if str(dict_responseHeaders['errorCode']) in dictErrorValues:
                        str_errorValue = dictErrorValues[dict_responseHeaders['errorCode']]
                        AgentLogger.log(AgentLogger.MAIN,'Unable to register agent due to : ' + str_errorValue + '\n\n')
                    continue 
                else:
                    AgentLogger.log(AgentLogger.STDOUT,'Response Headers :'+repr(dict_responseHeaders))
                    if 'status' in dict_responseHeaders and dict_responseHeaders['status'] == 'failure' and 'errorCode' in dict_responseHeaders and dict_responseHeaders['errorcode'] == 'RETRY':
                        AgentLogger.log(AgentLogger.STDERR,' *************************** Register Agent FAILED and Server Has Requested For RETRY *************************** ')
                        time.sleep(AgentConstants.AGENT_REGISTRATION_RETRY_INTERVAL)
                        bool_retry = True
                        continue                    
                    elif 'status' in dict_responseHeaders and dict_responseHeaders['status'] == 'failure' and 'errorCode' in dict_responseHeaders and dict_responseHeaders['errorcode'] == 'TERMINATE_AGENT':
                        AgentLogger.log(AgentLogger.STDERR,' *************************** Register Agent FAILED and Server Has Requested For TERMINATE_AGENT *************************** ')
                        AgentUtil.TerminateAgent()
                        return False 
                    agentKey = None 
                    nsPort = None
                    timeDiff = None
                    customerId = None
                    customerName = None   
                    if 'agentKey' in dict_responseHeaders:
                        agentKey = dict_responseHeaders['agentKey']
                    if 'NSPORT' in dict_responseHeaders:
                        nsPort = dict_responseHeaders['NSPORT']
                    if 'timeDiff' in dict_responseHeaders:
                        timeDiff = dict_responseHeaders['timeDiff']
                    if 'customerid' in dict_responseHeaders:
                        customerId = dict_responseHeaders['customerid']
                    if 'customername' in dict_responseHeaders:
                        customerName = dict_responseHeaders['customername']
                    if not nsPort == '' or not nsPort == None:
                        AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'ns_port', nsPort)                        
                        bool_isAgentInfoModified = True
                    if not timeDiff == '' or not timeDiff == None:
                        AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'time_diff', timeDiff)                        
                        bool_isAgentInfoModified = True
                    if bool_isAgentInfoModified:
                        AgentUtil.persistAgentInfo()
            except Exception as e:
                AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],'*************************** Exception While Re-Registering Agent *************************** '+ repr(e))
                traceback.print_exc()
                bool_retry = True
                bool_toReturn = False              
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],'*************************** Exception While Re-Registering Agent *************************** '+ repr(e))
        traceback.print_exc()
        bool_toReturn = False
    finally:
        if bool_toReturn:
            AgentConstants.AGENT_REGISTRATION_TIME = AgentUtil.getCurrentTimeInMillis()
            AgentConstants.AGENT_TIME_DIFF_BASED_REGISTRATION_TIME = AgentUtil.getTimeInMillis(AgentConstants.AGENT_REGISTRATION_TIME)
        AgentLogger.log(AgentLogger.STDOUT,'AGENT_REGISTRATION_TIME : '+repr(AgentUtil.getFormattedTime(AgentConstants.AGENT_REGISTRATION_TIME))+' --> '+repr(AgentConstants.AGENT_REGISTRATION_TIME))
        AgentLogger.log(AgentLogger.STDOUT,'AGENT_TIME_DIFF_BASED_REGISTRATION_TIME : '+repr(AgentUtil.getFormattedTime(AgentConstants.AGENT_TIME_DIFF_BASED_REGISTRATION_TIME))+' --> '+repr(AgentConstants.AGENT_TIME_DIFF_BASED_REGISTRATION_TIME))
    return bool_toReturn

def getInstanceId(type,dict):
    try:
        bool_to_return = True
        id = None
        if type == 'AWS':
            id = dict['instanceId']
        elif type == 'Azure':
            id = dict['ID']
        elif type == 'DigitalOcean':
            id = dict['droplet_id']
        elif type == 'GoogleCloud':
            id = dict['id']
    except Exception as e:
        bool_to_return = False
        AgentLogger.log(AgentLogger.STDOUT,'****************************** Exception while getting the instance id ********************************** '+repr(e))
        traceback.print_exc()
    AgentLogger.log(AgentLogger.STDOUT,'Instance id of the server : '+str(id))
    return bool_to_return,id

def getInstanceMetadata():
    try:
        resp_dict={}
        bool_To_Return = False
        AgentLogger.log(AgentLogger.STDOUT,'Loading the url to get the instance metaData')
        (bool_status,list_dict) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_INSTANCE_METADATA_CONF_FILE)
        if bool_status:
            for key in list_dict.keys():
                AgentLogger.log(AgentLogger.STDOUT,'Checking whether it is an instance of '+str(key))
                bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData = CommunicationHandler.sendrequesttoUrl(list_dict[key]['MetadataUrl'])
                if bool_toReturn:
                    AgentLogger.log(AgentLogger.STDOUT,'The server is an instance of  '+str(key))
                    resp_dict = json.loads(dict_responseData)
                    resp_dict['cloudPlatform']=key
                    bool_To_Return = True
                    break
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'****************************** Exception while getting the instance metaData ********************************** '+repr(e))
        traceback.print_exc()
    return bool_To_Return,resp_dict


def sendinstanceMetadata():
    dict_requestParameters = {}
    try:
        AgentLogger.log(AgentLogger.STDOUT,'MetaData to send : ' + repr(instanceDict))
        dict_requestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['agentKey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        dict_requestParameters['action'] = AgentConstants.METADATA
        str_requestParameters = urlencode(dict_requestParameters)
        str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
        str_url = str_servlet + str_requestParameters
        str_jsonData = json.dumps(instanceDict)
        requestInfo = CommunicationHandler.RequestInfo()
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_data(str_jsonData)
        requestInfo.add_header("Content-Type", 'application/json')
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        (isSuccess, int_errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)   
        if not isSuccess:
            AgentLogger.log(AgentLogger.STDOUT,'Sending Agent MetaData failed : Errorcode:'+repr(int_errorCode))
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Agent MetaData sent successfully :'+repr(dict_responseData))
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'****************************** Exception while posting the instance metaData ********************************** '+repr(e))
        traceback.print_exc()
        
def persistDomains(list_domains):
    try:
        list_dict={}
        AgentUtil.AGENT_CONFIG.set('SERVER_INFO', 'server_name',list_domains[0])
        AgentUtil.AGENT_CONFIG.set('SECONDARY_SERVER_INFO', 'server_name',list_domains[1])
        list_dict['servers_list']=list_domains[2]
        AgentConstants.STATIC_SERVER_HOST=list_domains[3]
        AgentUtil.persistAgentInfo()
        AgentUtil.writeDataToFile(AgentConstants.AGENT_STATUS_UPDATE_SERVER_LIST_FILE,list_dict)
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'****************************** Exception while persisting Domain info for registration ********************************** '+repr(e))
        traceback.print_exc()
        
def registerAgent():
    bool_toReturn = True
    bool_isFirstTime = True    
    bool_isAgentRegistered = False    
    str_servlet = AgentConstants.AGENT_REGISTRATION_SERVLET    
    int_retryCount = 0
    dict_dataForAgentRegistration = {}
    try:
        #Hardcoded Registration Parameters        
        dict_dataForAgentRegistration['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_dataForAgentRegistration['category'] = AgentUtil.AGENT_CONFIG.defaults().get('category')        
        dict_dataForAgentRegistration['updateStatus'] = AgentUtil.AGENT_CONFIG.defaults().get('update_status')
        dict_dataForAgentRegistration['agentVersion'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_version')
        dict_dataForAgentRegistration['isMasterAgent'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'master_agent')
        dict_dataForAgentRegistration['bno'] = AgentConstants.AGENT_VERSION
        #dict_dataForAgentRegistration['agentType'] = AgentConstants.OS_NAME
        dict_dataForAgentRegistration['monagentID'] = AgentConstants.HOST_NAME
        dict_dataForAgentRegistration['IpAddress'] = AgentConstants.IP_ADDRESS
        dict_dataForAgentRegistration['MACAddress'] = AgentConstants.MAC_ADDRESS
        #dict_dataForAgentRegistration['osFlavor'] = AgentConstants.OS_FLAVOR
        dict_dataForAgentRegistration['osName'] = AgentConstants.OS_NAME
        dict_dataForAgentRegistration['monagentDNS'] = AgentConstants.HOST_FQDN_NAME
        dict_dataForAgentRegistration['monagentKey'] = AgentConstants.AGENT_REGISTRATION_KEY
        dict_dataForAgentRegistration['agentUniqueID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')        
        dict_dataForAgentRegistration['freeServiceFormat'] = 'json'
        
        upTime = AgentUtil.getUpTime()
        if not upTime == None:
            dict_dataForAgentRegistration['upTime']=upTime
        
        if not AgentConstants.DOMAIN_NAME == None:
            dict_dataForAgentRegistration['DomainName'] = AgentConstants.DOMAIN_NAME
            
        if not AgentConstants.SYSTEM_UUID == None:
            dict_dataForAgentRegistration['uuid'] = AgentConstants.SYSTEM_UUID

         
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','display_name') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','display_name')=='0':
            dict_dataForAgentRegistration['dn'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','display_name')
            
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','group_name') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','group_name')=='0':
            dict_dataForAgentRegistration['gn'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','group_name')
        
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','threshold_profile') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','threshold_profile')=='0':
            dict_dataForAgentRegistration['tp'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','threshold_profile')
            
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','notification_profile') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','notification_profile')=='0':
            dict_dataForAgentRegistration['np'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','notification_profile')
        
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','resource_profile') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','resource_profile')=='0':
            dict_dataForAgentRegistration['rp'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','resource_profile')
        
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','installer') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','installer')=='0':
            dict_dataForAgentRegistration['installer'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','installer')
        
        if AgentUtil.AGENT_CONFIG.has_option('AGENT_INFO','configuration_template') and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO','configuration_template')=='0':
            dict_dataForAgentRegistration['ct'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO','configuration_template')
        
        if 'monagentDNS' in dict_dataForAgentRegistration and 'monagentID' in dict_dataForAgentRegistration and dict_dataForAgentRegistration['monagentDNS']=='localhost' and dict_dataForAgentRegistration['monagentID']!='localhost':
            dict_dataForAgentRegistration['monagentDNS'] = dict_dataForAgentRegistration['monagentID']
            
        if 'monagentDNS' in dict_dataForAgentRegistration and 'monagentID' in dict_dataForAgentRegistration and dict_dataForAgentRegistration['monagentDNS']=='localhost.localdomain' and dict_dataForAgentRegistration['monagentID']!='localhost.localdomain':
            dict_dataForAgentRegistration['monagentDNS'] = dict_dataForAgentRegistration['monagentID']
        
        if isInstance:
            bool_to_return,id = getInstanceId(instanceDict['cloudPlatform'],instanceDict)
            if bool_to_return and id is not None: 
                dict_dataForAgentRegistration['instanceId'] = id
            if 'cloudPlatform' in instanceDict.keys():
                dict_dataForAgentRegistration['cloudPlatform'] = instanceDict['cloudPlatform']

        dict_dataForAgentRegistration['OsArch'] = struct.calcsize('P') * 8   
            
        AgentLogger.log(AgentLogger.STDOUT,' Data For Registration ======> {0}'.format(json.dumps(dict_dataForAgentRegistration)))
        while not bool_isAgentRegistered and not AgentUtil.TERMINATE_AGENT:
            int_retryCount+=1
            bool_isAgentInfoModified = False
            if int_retryCount > AgentConstants.AGENT_REGISTRATION_RETRY_COUNT:
                bool_toReturn = False
                AgentLogger.log([AgentLogger.STDOUT, AgentLogger.MAIN],'************* Failed to register agent more than 10 times *************** \n' )
                break
            elif not bool_isFirstTime:
                AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.AGENT_REGISTRATION_RETRY_INTERVAL)
            elif bool_isFirstTime:
                bool_isFirstTime = False
            try:                
                AgentLogger.log(AgentLogger.STDOUT,'REGISTER AGENT : =============================== TRYING TO REGISTER AGENT =============================== \n')
                dict_dataForAgentRegistration['timeStamp'] = str(AgentUtil.getCurrentTimeInMillis())
                dict_processData = DataCollector.ProcessUtil.discoverProcessForRegisterAgent()
                if dict_processData:
                    str_jsonData = json.dumps(dict_processData)#python dictionary to json string
                else:
                    str_jsonData = ''
                AgentLogger.log(AgentLogger.STDOUT, 'Process details collected : '+repr(str_jsonData))
                str_url = None
                if not dict_dataForAgentRegistration == None:
                    str_requestParameters = urlencode(dict_dataForAgentRegistration)
                    str_url = str_servlet + str_requestParameters
                requestInfo = CommunicationHandler.RequestInfo()
                requestInfo.set_loggerName(AgentLogger.STDOUT)
                requestInfo.set_method(AgentConstants.HTTP_POST)
                requestInfo.set_url(str_url)
                requestInfo.set_data(str_jsonData)
                requestInfo.add_header("Content-Type", 'application/json')
                requestInfo.add_header("Accept", "text/plain")
                requestInfo.add_header("Connection", 'close')
                (isSuccess, int_errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
                AgentLogger.log(AgentLogger.STDOUT, 'dict_responseHeaders : '+repr(dict_responseHeaders))
                if not dict_responseHeaders == None and 'FREE_SERVICE_DETAILS' in dict_responseHeaders:
                    dict_freeProcessDetails = json.loads(dict_responseHeaders['FREE_SERVICE_DETAILS'])#String to python object (dictionary)
                    AgentLogger.log(AgentLogger.STDOUT, 'Process to be monitored : '+repr(dict_freeProcessDetails))       
                    DataCollector.FREE_PROCESS_LIST = dict_freeProcessDetails['FreeProcessDetails']   
                else:
                    AgentLogger.log(AgentLogger.STDOUT, 'Process to be monitored is empty in reponse header map : '+repr(dict_responseHeaders))
                CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'REGISTER AGENT')
                if not isSuccess:
                    AgentLogger.log(AgentLogger.MAIN,'\n\n *************************** Unable To Send Agent Registration Data To Server. Will Retry Registration After '+str(AgentConstants.AGENT_REGISTRATION_RETRY_INTERVAL)+' seconds *************************** \n\n')                    
                    continue
                elif isSuccess and dict_responseHeaders == None:
                    AgentLogger.log(AgentLogger.STDOUT,' *************************** Registration Response From The Server Is None. Will Retry Registration After '+str(AgentConstants.AGENT_REGISTRATION_RETRY_INTERVAL)+' seconds *************************** ')                    
                    continue
                elif ((dict_responseHeaders) and ('errorCode' in dict_responseHeaders) and (str(dict_responseHeaders['errorCode']) in dictErrorValues)):
                    if str(dict_responseHeaders['errorCode']) in dictErrorValues:
                        str_errorValue = dictErrorValues[dict_responseHeaders['errorCode']]
                        AgentLogger.log(AgentLogger.MAIN,'Unable to register agent due to : ' + str_errorValue + '\n\n')
                        continue
                else:
                    AgentLogger.log(AgentLogger.STDOUT,'Response Headers :'+repr(dict_responseHeaders))
                    if 'status' in dict_responseHeaders and dict_responseHeaders['status'] == 'failure' and 'errorCode' in dict_responseHeaders and dict_responseHeaders['errorcode'] == 'RETRY':
                        AgentLogger.log(AgentLogger.STDOUT,' *************************** Register Agent FAILED and Server Has Requested For RETRY *************************** ')                        
                        continue                    
                    elif 'status' in dict_responseHeaders and dict_responseHeaders['status'] == 'failure' and 'errorCode' in dict_responseHeaders and dict_responseHeaders['errorcode'] == 'TERMINATE_AGENT':
                        AgentLogger.log(AgentLogger.STDOUT,' *************************** Register Agent FAILED and Server Has Requested For TERMINATE_AGENT *************************** ')
                        AgentUtil.TerminateAgent()
                        return False
                    CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'REGISTER AGENT')
                    agentKey = None 
                    nsPort = None
                    timeDiff = None
                    customerId = None
                    customerName = None   
                    if 'agentKey' in dict_responseHeaders:
                        agentKey = dict_responseHeaders['agentKey']
                    if 'NSPORT' in dict_responseHeaders:
                        nsPort = dict_responseHeaders['NSPORT']
                    if 'timeDiff' in dict_responseHeaders:
                        timeDiff = dict_responseHeaders['timeDiff']
                    if 'customerid' in dict_responseHeaders:
                        customerId = dict_responseHeaders['customerid']
                    if 'customername' in dict_responseHeaders:
                        customerName = dict_responseHeaders['customername']
                    if not agentKey == '' and not agentKey == '0' and not agentKey == AgentConstants.AGENT_REGISTRATION_KEY and not agentKey == None:
                        AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_key', agentKey)                        
                        bool_isAgentRegistered = True
                        AgentLogger.log(AgentLogger.MAIN,'Agent Registration with Server | Status - Success \n')
                        AgentLogger.log(AgentLogger.MAIN,'Agent Unique Key from Server : '+repr(agentKey)+'\n')
                        bool_isAgentInfoModified = True
                        bool_toReturn = True
                        if not nsPort == '' and not nsPort == None:
                            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'ns_port', nsPort)                        
                            bool_isAgentInfoModified = True
                        if not timeDiff == '' and not timeDiff == None:
                            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'time_diff', timeDiff)                        
                            bool_isAgentInfoModified = True
                        if not customerId == '' and not customerId == None:
                            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'customer_id', customerId)                        
                            bool_isAgentInfoModified = True
                        if not customerName == '' and not customerName == None:
                            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'customer_name', customerName)                        
                            bool_isAgentInfoModified = True
                    if bool_isAgentInfoModified:
                        AgentUtil.persistAgentInfo()
            except Exception as e:
                AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],'*************************** Exception While Registering Agent *************************** '+ repr(e))
                traceback.print_exc()
                bool_toReturn = False       
    except Exception as e:
        AgentLogger.log(AgentLogger.CRITICAL,'*************************** Exception While Registering Agent *************************** '+ repr(e))
        traceback.print_exc()
        bool_toReturn = False
    return bool_toReturn    
