# $Id$
import traceback
import six.moves.urllib.request as urlconnection
from six.moves.urllib.parse import urlencode
from six.moves.urllib.error import URLError, HTTPError
try:
    from http.client import InvalidURL
except Exception as e:
    from httplib import InvalidURL
import json
import socket, errno
import ssl
import sys, os, time
import platform

import com
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentUtil, AgentBuffer
from com.manageengine.monagent.actions import ScriptHandler
from com.manageengine.monagent.plugins import PluginUtils
from com.manageengine.monagent.plugins import PluginMonitoring

SERVER_INFO = None
SECONDARY_SERVER_INFO = None
PROXY_INFO = None

SSL_TIMEOUT_ERROR = 'the read operation timed out'

NETWORK_STATUS_CHECK_TIME = time.time()

NETWORK_STATUS_CHECK_URLS = [('www.wikipedia.org', AgentConstants.HTTPS_PROTOCOL, 443, 0),
                             ('www.oracle.com', AgentConstants.HTTP_PROTOCOL, 80, 0),
                             ('www.python.org', AgentConstants.HTTP_PROTOCOL, 80, 0),
                             ('www.google.com', AgentConstants.HTTPS_PROTOCOL, 443, 0),
                             ('www.bing.com', AgentConstants.HTTPS_PROTOCOL, 443, 0),
                             ]

WMS_REQID_SERVED_BUFFER = None

NETWORK_STATUS_CHECK_REACHABLE_URLS = []

def initialize():
    global SERVER_INFO, SECONDARY_SERVER_INFO, PROXY_INFO, WMS_REQID_SERVED_BUFFER
    WMS_REQID_SERVED_BUFFER = AgentBuffer.getBuffer(AgentConstants.WMS_REQID_SERVED_BUFFER,AgentConstants.MAX_WMS_REQID_BUFFER)
    SERVER_INFO = ServerInfo()
    SERVER_INFO.set_host(AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name'))
    SERVER_INFO.set_port(AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port'))
    SERVER_INFO.set_protocol(AgentConstants.HTTPS_PROTOCOL)
    SERVER_INFO.set_timeout(AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_timeout'))
    SECONDARY_SERVER_INFO = ServerInfo()
    SECONDARY_SERVER_INFO.set_host(AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_name'))
    SECONDARY_SERVER_INFO.set_port(AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_port'))
    SECONDARY_SERVER_INFO.set_protocol(AgentConstants.HTTPS_PROTOCOL)
    SECONDARY_SERVER_INFO.set_timeout(AgentUtil.AGENT_CONFIG.get('SECONDARY_SERVER_INFO', 'server_timeout'))
    setProxy()
    AgentLogger.log(AgentLogger.MAIN,'========================== SERVER DETAILS ========================== \n')
    AgentLogger.log(AgentLogger.MAIN,'SERVER INFO : '+str(SERVER_INFO)+'SECONDARY SERVER INFO : '+str(SECONDARY_SERVER_INFO)+'PROXY INFO : '+str(PROXY_INFO))
    
    
def updateProxyDetails():
    bool_toReturn = True
    str_proxyUserName = AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_user_name')
    str_proxyPassword = AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_password')
    str_proxyHost = AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_name')
    str_proxyPort = AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_port')
    try:
        # returns a tuple
        def splitStringOnLastIndex(strToSplit, str_delimiter):
            if str_delimiter in strToSplit:
                int_index = strToSplit.rindex(str_delimiter)
                return (strToSplit[:int_index], strToSplit[int_index+1:])
        # returns a tuple
        def splitString(strToSplit, str_delimiter):
            if str_delimiter in strToSplit:
                int_index = strToSplit.index(str_delimiter)
                return (strToSplit[:int_index], strToSplit[int_index+1:])
        AgentLogger.log(AgentLogger.STDOUT,'Input arguments :'+ repr(sys.argv))
        if len(sys.argv) == 2:
            str_proxyDetails = sys.argv[1]
            if '@' in str_proxyDetails:
                str_authDetails, str_proxyHostDetails = splitStringOnLastIndex(str_proxyDetails, '@')
                if ':' in str_authDetails:
                    str_proxyUserName, str_proxyPassword = splitString(str_authDetails, ':')
                    str_proxyPassword = str_proxyPassword
                else:
                    str_proxyUserName = str_authDetails
                    str_proxyPassword = '0'
                if ':' in str_proxyHostDetails:
                    str_proxyHost, str_proxyPort = splitString(str_proxyHostDetails, ':')
            elif ':' in str_proxyDetails:
                str_proxyUserName = '0'
                str_proxyPassword = '0'
                str_proxyHost, str_proxyPort = splitString(str_proxyDetails, ':')
        AgentLogger.log(AgentLogger.MAIN,'Proxy username :'+ repr(str_proxyUserName)+'Proxy password :'+ repr(str_proxyPassword)+'Proxy host :'+ repr(str_proxyHost)+'Proxy port :'+ repr(str_proxyPort)+'\n')
        if str_proxyPassword and not str_proxyPassword == '0':
            AgentLogger.debug(AgentLogger.COLLECTOR,'PP :'+ repr(str_proxyPassword))
        #AgentLogger.debug(AgentLogger.COLLECTOR,'PP Encrypted :'+ repr(AgentCrypt.encrypt('Zohoco0212')))
        #AgentLogger.debug(AgentLogger.COLLECTOR,'PP Decrypted :'+ repr(AgentCrypt.decrypt(AgentCrypt.encrypt(str_proxyPassword))))
        AgentUtil.AGENT_CONFIG.set('PROXY_INFO', 'proxy_server_name', str(str_proxyHost))
        AgentUtil.AGENT_CONFIG.set('PROXY_INFO', 'proxy_server_port', str(str_proxyPort))
        AgentUtil.AGENT_CONFIG.set('PROXY_INFO', 'proxy_user_name', str(str_proxyUserName))
        AgentUtil.AGENT_CONFIG.set('PROXY_INFO', 'proxy_password', str(str_proxyPassword))
        AgentUtil.persistAgentInfo()
        setProxy()
    except Exception as e:
        AgentLogger.log(AgentLogger.MAIN,' ************************* Exception while creating proxy profile ************************* '+ repr(e) + '\n')
        traceback.print_exc()
        bool_toReturn = False
    return bool_toReturn
    
def setProxy():
    global PROXY_INFO
    if not AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_name') == '0':
        PROXY_INFO = ProxyInfo()
        PROXY_INFO.set_host(AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_name'))
        PROXY_INFO.set_port(AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_port'))
        if AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_protocol') != '0':
            PROXY_INFO.set_protocol(AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_server_protocol'))
        else:
            PROXY_INFO.set_protocol(AgentConstants.HTTP_PROTOCOL)
        PROXY_INFO.set_username(AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_user_name'))
        PROXY_INFO.set_password(AgentUtil.AGENT_CONFIG.get('PROXY_INFO', 'proxy_password'))

def pingServer(str_loggerName = AgentLogger.STDOUT):
    hostIpAddress = None
    sockConn = None
    isSuccess = True
    try:
        AgentLogger.log([str_loggerName],'========================== GET IP USING PING ==========================\n')
        AgentLogger.log(str_loggerName,'PING: Trying To Reach The Server : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name')+' : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port'))
        sockConn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)    
        sockConn.settimeout(5)
        connectResult = sockConn.connect_ex((AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name'), int(AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port'))))
        if connectResult == 0:
            AgentLogger.log(str_loggerName,'PING: Established Connection To The Server : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name')+' : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port'))
            AgentLogger.log(str_loggerName,'PING: Socket Used For Communicating With The Server : '+repr(sockConn.getsockname()))
            hostIpAddress = sockConn.getsockname()[0]
        else:
            AgentLogger.log(str_loggerName,'PING: Unable To Reach The Server : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name')+' : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port'))
            AgentLogger.log(str_loggerName,'PING: Socket Used For Communicating With The Server : '+repr(sockConn.getsockname()))
            hostIpAddress = sockConn.getsockname()[0]
            isSuccess = False
    except socket.error as e:
        if e.errno == errno.ECONNREFUSED:
            AgentLogger.log([str_loggerName,AgentLogger.MAIN, AgentLogger.STDERR],'PING: ++++++++++++++++++++++++++++++++++ Unable To Reach Server, Connection Refused ++++++++++++++++++++++++++++++++++ \n')         
            isSuccess = False
    except Exception as e:
        AgentLogger.log([str_loggerName,AgentLogger.STDERR],'PING: *************************** Exception While Trying To Establish Connection With The Server *************************** '+ repr(e))
        traceback.print_exc()
        isSuccess = False
    finally:
        if not sockConn == None:
            sockConn.close()
    return isSuccess, hostIpAddress

def isServerReachable(int_retryCount = 10, int_retryInterval = 60, str_loggerName = AgentLogger.STDOUT):
    isSuccess = False
    int_attempt = 1
    AgentLogger.log([str_loggerName],'========================== COMMUNICATION CHECK ==========================\n')
    while not AgentUtil.TERMINATE_AGENT and int_attempt <= int_retryCount:
        int_attempt += 1
        AgentLogger.log([str_loggerName],'Trying To Reach The Server : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name')+' : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port')+'\n')
        requestInfo = RequestInfo()
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_parseResponse(False)
        requestInfo.set_responseAction(dummy)
        requestInfo.set_method(AgentConstants.HTTP_GET)
        isSuccess, int_errorCode, dict_responseHeaders, dict_responseData = sendRequest(requestInfo)
        if isSuccess:
            AgentLogger.log([str_loggerName],'Established Connection To The Server '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name')+' : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port')+'\n')
            isSuccess = True
            break
        else:
            AgentLogger.log([str_loggerName,AgentLogger.MAIN],'Unable To Reach The Server '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name')+' : '+AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_port') + '\n')    
            isSuccess = False
            AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(int_retryInterval)            
    return isSuccess

def checkNetworkStatus(str_loggerName = AgentLogger.STDOUT):
    global NETWORK_STATUS_CHECK_TIME, NETWORK_STATUS_CHECK_REACHABLE_URLS
    bool_isSuccess = False
    networkStatusCheckTime = time.time()
    try:
        if NETWORK_STATUS_CHECK_REACHABLE_URLS != None:
            if not NETWORK_STATUS_CHECK_REACHABLE_URLS:
                for str_host, str_protocol, str_port, int_attemptCount in NETWORK_STATUS_CHECK_URLS:
                    if not AgentUtil.TERMINATE_AGENT:
                        AgentLogger.log([str_loggerName],'=============================== CHECK NETWORK STATUS ===============================')
                        AgentLogger.log(AgentLogger.STDOUT,'Trying to reach the host : '+repr(str_host))
                        requestInfo = RequestInfo()
                        requestInfo.set_loggerName(AgentLogger.STDOUT)
                        requestInfo.set_host(str_host)
                        requestInfo.set_port(str_port)
                        requestInfo.set_protocol(str_protocol)
                        requestInfo.set_responseAction(dummy)
                        requestInfo.set_parseResponse(False)
                        requestInfo.set_timeout(5)
                        requestInfo.set_method(AgentConstants.HTTP_GET)
                        isSuccess, int_errorCode, dict_responseHeaders, dict_responseData = sendRequest(requestInfo)
                        int_attemptCount+=1
                        if isSuccess:
                            AgentLogger.log([str_loggerName],'Established connection to the host '+repr(str_host))
                            bool_isSuccess = True
                            NETWORK_STATUS_CHECK_REACHABLE_URLS.append((str_host, str_protocol, str_port, int_attemptCount))
                            #break
                        else:
                            AgentLogger.log([str_loggerName],'Unable to reach the host : '+repr(str_host))
                if len(NETWORK_STATUS_CHECK_REACHABLE_URLS) == 0:
                    AgentLogger.log([AgentLogger.MAIN],'Unable to reach all network status check urls \n')
                    NETWORK_STATUS_CHECK_REACHABLE_URLS = None
            else:
                timeDiff = (networkStatusCheckTime - NETWORK_STATUS_CHECK_TIME)
                if timeDiff > AgentConstants.NETWORK_STATUS_CHECK_INTERVAL:
                    for str_host, str_protocol, str_port, int_attemptCount in NETWORK_STATUS_CHECK_REACHABLE_URLS:
                        if not AgentUtil.TERMINATE_AGENT:
                            AgentLogger.log([str_loggerName],'=============================== CHECK NETWORK STATUS ===============================')
                            AgentLogger.log(AgentLogger.STDOUT,'Trying to reach the host : '+repr(str_host))
                            requestInfo = RequestInfo()
                            requestInfo.set_loggerName(AgentLogger.STDOUT)
                            requestInfo.set_host(str_host)
                            requestInfo.set_port(str_port)
                            requestInfo.set_protocol(str_protocol)
                            requestInfo.set_responseAction(dummy)
                            requestInfo.set_parseResponse(False)
                            requestInfo.set_timeout(5)
                            requestInfo.set_method(AgentConstants.HTTP_GET)
                            isSuccess, int_errorCode, dict_responseHeaders, dict_responseData = sendRequest(requestInfo)
                            if isSuccess:
                                AgentLogger.log([str_loggerName],'Established connection to the host '+repr(str_host))
                                bool_isSuccess = True
                                break
                            else:
                                AgentLogger.log([str_loggerName],'Unable to reach the host : '+repr(str_host))
                    NETWORK_STATUS_CHECK_TIME = networkStatusCheckTime
                else:
                    AgentLogger.log([str_loggerName],'Network status check will be done after '+repr(AgentConstants.NETWORK_STATUS_CHECK_INTERVAL - timeDiff)+' seconds')
        else:
            AgentLogger.log([str_loggerName],'Reachable network status check urls is empty')
    except Exception as e:
        AgentLogger.log([str_loggerName, AgentLogger.STDERR], '*************************** Exception while checking network status ************************** '+ repr(e))
        traceback.print_exc()          
    return bool_isSuccess

def dummy():
    pass

class ServerInfo:
    def __init__(self):
        self.host = None
        self.port = None
        self.protocol = None
        self.timeout = None            
    def __str__(self):
        return 'SERVER INFO : Host : '+str(self.host)+' Port : '+str(self.port)+' Protocol : '+str(self.protocol)+' Timeout : '+str(self.timeout)    
    def set_host(self, host):
        self.host = host    
    def get_host(self):
        return self.host    
    def set_port(self, port):
        self.port = port        
    def get_port(self):
        return self.port        
    def set_protocol(self, protocol):
        self.protocol = protocol
    def get_protocol(self):
        return self.protocol
    def set_timeout(self, timeout):
        self.timeout = int(timeout)    
    def get_timeout(self):
        return self.timeout
         
class ProxyInfo:
    def __init__(self):
        self.host = None
        self.port = None
        self.protocol = AgentConstants.HTTP_PROTOCOL
        self.username = None
        self.password = None
    def __str__(self):
        return 'PROXY INFO : Host : '+str(self.host)+' Port : '+str(self.port)+' Protocol : '+str(self.protocol)+' User name : '+str(self.username)+' Password : '+str(self.password)      
    def set_host(self, host):
        self.host = host    
    def get_host(self):
        return self.host    
    def set_port(self, port):
        self.port = port        
    def get_port(self):
        return self.port        
    def set_protocol(self, protocol):
        self.protocol = protocol
    def get_protocol(self):
        return self.protocol
    def set_username(self, username):
        self.username = username
    def get_username(self):
        return self.username
    def set_password(self, password):
        self.password = password
    def get_password(self):
        return self.password
    def getUrl(self):
        str_urlToReturn = None
        if self.username:
            AgentLogger.log(AgentLogger.STDOUT,'Username : '+repr(self.username));
        if self.username != '0' and self.password == '0':
            str_urlToReturn = r''+self.protocol+'://'+self.username+'@'+self.host+':'+str(self.port)
        elif self.username != '0' and self.password != '0':
            str_urlToReturn = r''+self.protocol+'://'+self.username+':'+self.password+'@'+self.host+':'+str(self.port)
        else:
            str_urlToReturn = r''+self.protocol+'://'+self.host+':'+str(self.port)
        return str_urlToReturn
        

#
# Default request method is GET

class RequestInfo(object):
    def __init__(self):
        self.host = None
        self.port = None
        self.protocol = None
        self.timeout = None
        self.isSecondaryServer = False
        self.method = AgentConstants.HTTP_GET          
        self.url = ''
        self.data = ''
        self.dataType = None
        self.responseAction = None
        self.boolParseResponse = True
        self.headers = {}        
        self.customParams = {}    
        self.logger = AgentLogger
        self.loggerName = None
        self.str_uploadFilePath = None
        self.str_uploadFileName = None
        #proxy details    
        self.proxy = False
        self.proxy_host = None
        self.proxy_port = None
        self.proxy_user_name = None
        self.proxy_host = None
        self.byPassProxy = False
        if SERVER_INFO:
            self.host = SERVER_INFO.get_host()
            self.port = SERVER_INFO.get_port()
            self.protocol = SERVER_INFO.get_protocol()
            self.timeout = SERVER_INFO.get_timeout()            
        if PROXY_INFO:
            self.proxy = True
            self.proxy_host = PROXY_INFO.get_host()
            self.proxy_port = PROXY_INFO.get_port()
            self.proxy_user_name = PROXY_INFO.get_username()
            self.proxy_password = PROXY_INFO.get_password()
        self.add_header('User-Agent', AgentConstants.AGENT_NAME)
    def __str__(self):
        str_requestInfo = ''
        str_requestInfo += 'HOST : '+repr(self.host)
        str_requestInfo += ' PORT : '+repr(self.port)
        str_requestInfo += ' PROTOCOL : '+repr(self.protocol)
        str_requestInfo += ' TIMEOUT : '+repr(self.timeout)+'\n'
        str_requestInfo += ' IS SECONDARY SERVER : '+repr(self.isSecondaryServer)+'\n'
        str_requestInfo += 'METHOD : '+repr(self.method)
        str_requestInfo += ' URL : '+repr(self.url)+'\n'
        str_requestInfo += 'HEADERS : '+repr(self.headers)+'\n'
        str_requestInfo += 'RESPONSE ACTION : '+repr(self.responseAction)+'\n'
        str_requestInfo += 'CUSTOM PARAMETERS : '+repr(self.customParams)+'\n'
        if 'Content-Type' in self.headers and not self.headers['Content-Type'] == 'zip':            
            str_requestInfo += 'Request Body : '+repr(self.data)+'\n'
        return str_requestInfo    
    def set_method(self, str_method):
        self.method = str_method
    def get_method(self):
        return self.method
    def set_url(self, url):
        self.url = url        
    def get_url(self):
        return self.url    
    def set_data(self, data):
        self.data = data
    def set_parseResponse(self, boolParseResponse):
        self.boolParseResponse = boolParseResponse
    def get_parseResponse(self):
        return self.boolParseResponse
    def set_responseAction(self, responseAction):
        self.responseAction = responseAction
    def get_responseAction(self):
        return self.responseAction
    def get_data(self):
        return self.data
    def set_dataType(self, str_dataType):
        self.dataType = str_dataType
    def get_dataType(self):
        return self.dataType
    def get_host(self):        
        return self.host
    def set_host(self, str_host):        
        self.host = str_host
    def get_port(self):        
        return self.port
    def set_port(self, str_port):        
        self.port = str_port
    def get_protocol(self):        
        return self.protocol
    def set_protocol(self, str_protocol):        
        self.protocol = str_protocol
    def get_timeout(self):        
        return self.timeout
    def set_timeout(self, timeout):        
        self.timeout = int(timeout)
    def add_header(self, key, val):
        self.headers[key.capitalize()] = val
    def get_headers(self):
        return self.headers
    def useSecondaryServer(self):
        self.isSecondaryServer = True
        if SECONDARY_SERVER_INFO:
            self.host = SECONDARY_SERVER_INFO.get_host()
            self.port = SECONDARY_SERVER_INFO.get_port()
            self.protocol = SECONDARY_SERVER_INFO.get_protocol()
            self.timeout = SECONDARY_SERVER_INFO.get_timeout()
    def add_custom_param(self, key, val):
        self.customParams[key] = val
    def bypass_proxy(self):
        self.byPassProxy = True
    def get_custom_params(self):
        return self.customParams
    def get_logger(self):
        return self.logger
    def set_logger(self, logger):
        self.logger = logger
    def get_loggerName(self):
        return self.loggerName
    def set_loggerName(self, loggerName):
        self.loggerName = loggerName
    def get_uploadFilePath(self):
        return self.str_uploadFilePath
    def set_uploadFilePath(self, str_uploadFilePath):
        self.str_uploadFilePath = str_uploadFilePath
    def get_uploadFileName(self):
        return self.str_uploadFileName
    def set_uploadFileName(self, str_uploadFileName):
        self.str_uploadFileName = str_uploadFileName
    def preRequest(self):
        bool_toReturn = True
        if not self.get_uploadFileName() == None:
            bool_toReturn = self.getFileData()
        return bool_toReturn
    def postRequest(self):
        pass
    def getFileData(self):
        bool_toReturn = True        
        fileSysEncoding = sys.getfilesystemencoding()
        file_obj = None
        try:            
            if os.path.isfile(self.str_uploadFilePath):                
                file_obj = open(self.str_uploadFilePath,'rb')
                byte_data = file_obj.read()
                str_data = byte_data.decode(fileSysEncoding)
                my_dict = json.loads(str_data)#String to python object (dictionary)
                str_jsonData = json.dumps(my_dict)#python dictionary to json string
                #str_encodedJsonData = str_jsonData.encode('UTF-16LE')
                self.set_data(str_jsonData)
        except Exception as e:
            self.logger.log(self.loggerName, ' ************************* Exception while reading the file '+repr(self.str_uploadFilePath)+' ************************* '+ repr(e))
            traceback.print_exc()      
            bool_toReturn = False          
        finally:
            if file_obj:
                file_obj.close()
        return bool_toReturn
        
def sendRequest(requestInfo):
    if platform.system() == 'Darwin':
        ssl._create_default_https_context = ssl._create_unverified_context
    bool_toReturn = True
    int_errorCode = 0
    dict_responseHeaders = None
    dict_responseData = None
    conn = None
    bool_print = True
    str_url = None
    dataToSend = None
    bool_isTimeoutError = False
    str_host = None
    str_port = None
    str_protocol = None
    try:
        str_host = requestInfo.get_host()
        str_port = str(requestInfo.get_port())
        str_protocol = requestInfo.get_protocol()
        if requestInfo.get_host() != AgentConstants.DMS_SERVER and requestInfo.get_loggerName() != AgentLogger.STDOUT:
            AgentLogger.log(requestInfo.get_loggerName(),'================================= SEND REQUEST =================================')
        AgentLogger.debug(requestInfo.get_loggerName(),'PROXY_INFO : '+str(PROXY_INFO))
        if PROXY_INFO:
            proxy = None
            if str_host != SERVER_INFO.get_host() and str_host != AgentConstants.DMS_SERVER:
                proxy = urlconnection.ProxyHandler({str_protocol: PROXY_INFO.getUrl()})
            else:
                proxy = urlconnection.ProxyHandler({AgentConstants.HTTPS_PROTOCOL: PROXY_INFO.getUrl()})
            auth = urlconnection.HTTPBasicAuthHandler()
            opener = urlconnection.build_opener(proxy, auth, urlconnection.HTTPSHandler)
            urlconnection.install_opener(opener)
        AgentLogger.debug(requestInfo.get_loggerName(),'REQUEST INFO : '+str(requestInfo))
        if requestInfo.byPassProxy == True:
            proxy = urlconnection.ProxyHandler({})
            bypassOpener = urlconnection.build_opener(proxy)
            urlconnection.install_opener(bypassOpener)
        if requestInfo.preRequest():
            if requestInfo.get_data() and requestInfo.get_dataType() == 'application/zip':
                dataToSend = requestInfo.get_data()
            elif requestInfo.get_data():
                AgentLogger.debug(requestInfo.get_loggerName(),'Request data : '+repr(requestInfo.get_data()))
                AgentLogger.debug(requestInfo.get_loggerName(),'Request data type : '+repr(type(requestInfo.get_data())))
                dataToSend = requestInfo.get_data().encode('UTF-16LE')
            if str_host != SERVER_INFO.get_host() and str_host != AgentConstants.DMS_SERVER:
                str_url = str_protocol+'://'+str_host+':'+str_port+requestInfo.get_url()
            else:
                str_url = AgentConstants.HTTPS_PROTOCOL+'://'+str_host+':'+str_port+requestInfo.get_url()  
            AgentLogger.debug(requestInfo.get_loggerName(),'Data to send : '+repr(dataToSend))         
            AgentLogger.debug(requestInfo.get_loggerName(),'REQUEST URL : '+str(str_url)) 
            requestObj = urlconnection.Request(str_url, dataToSend, requestInfo.get_headers())          
            response = urlconnection.urlopen(requestObj, timeout=requestInfo.get_timeout())
            if response.status == 200: 
                byte_responseData = None
                str_responseData = None
                if requestInfo.get_host() != AgentConstants.DMS_SERVER and AgentConstants.AGENT_STATUS_UPDATE_SERVLET not in requestInfo.get_url() and AgentConstants.AGENT_FILE_COLLECTOR_SERVLET not in requestInfo.get_url():
                    AgentLogger.log(requestInfo.get_loggerName(),'Page found successfully')    
                dict_responseHeaders = dict(response.getheaders())
                if requestInfo.get_parseResponse():
                    byte_responseData = response.read() 
                    if requestInfo.get_host() != AgentConstants.DMS_SERVER and 'Content-Type' in dict_responseHeaders:
                        AgentLogger.log(requestInfo.get_loggerName(),'Response content type : '+repr(dict_responseHeaders['Content-Type']))
                    AgentLogger.debug(requestInfo.get_loggerName(),'Response data : '+repr(byte_responseData))
                    AgentLogger.debug(requestInfo.get_loggerName(),'Type of response data : '+repr(type(byte_responseData)))
                    if not byte_responseData == None:
                        if requestInfo.get_responseAction() == saveFile:
                            requestInfo.get_responseAction()(requestInfo, byte_responseData)
                        elif requestInfo.get_responseAction() == dummy:
                            pass
                        else:
                            if 'encoding' in dict_responseHeaders:
                                str_responseData = byte_responseData
                            elif 'Content-Type' in dict_responseHeaders and 'charset=UTF-16LE' in dict_responseHeaders['Content-Type']:
                                AgentLogger.log(requestInfo.get_loggerName(),'charset found in response')
                                str_responseData = byte_responseData.decode('UTF-16LE')
                            else:
                                str_responseData = byte_responseData.decode('UTF-8')
                            if not str_responseData == '':
                                if not requestInfo.get_responseAction() == None:
                                    requestInfo.get_responseAction()(requestInfo, str_responseData)
                                else:                  
                                    try:
                                        str_unicodeResponseData = str(str_responseData,'UTF-16LE')
                                        dict_responseData = json.loads(str_unicodeResponseData)
                                    except Exception as e:
                                        dict_responseData = str_responseData                    
            elif response.status == 404:
                AgentLogger.log(requestInfo.get_loggerName(),'Response Status : '+repr(response.status)+', Page Not Found')
                bool_toReturn = False
            else:
                AgentLogger.log(requestInfo.get_loggerName(),'Response Status : '+repr(response.status)+' Reason : '+repr(response.reason))
                bool_toReturn = False
        else:
            AgentLogger.log(requestInfo.get_loggerName(),'************************* PRE-REQUEST OPERATION FAILED **********************')
            bool_toReturn = False
    except socket.timeout as e:
        if requestInfo.get_host() != AgentConstants.DMS_SERVER:
            AgentLogger.log(requestInfo.get_loggerName(),'++++++++++++++++++++++++++++++++++ The read operation timed out ++++++++++++++++++++++++++++++++++ ')
            AgentLogger.log(requestInfo.get_loggerName(),'Reason : '+repr(e))
        int_errorCode = e
        bool_toReturn = False  
        bool_print = False
        bool_isTimeoutError = True
    except URLError as e:
        if isinstance(e.reason, ConnectionRefusedError):
            AgentLogger.log(requestInfo.get_loggerName(),'++++++++++++++++++++++++++++++++++ Unable To Reach Server, Connection Refused ++++++++++++++++++++++++++++++++++ ')
            AgentLogger.log(requestInfo.get_loggerName(),'Reason : '+repr(e.reason))
            int_errorCode = e.reason
            bool_toReturn = False
            bool_print = False
        elif isinstance(e.reason, socket.timeout):
            if requestInfo.get_host() != AgentConstants.DMS_SERVER:
                AgentLogger.log(requestInfo.get_loggerName(),'++++++++++++++++++++++++++++++++++ The read operation timed out ++++++++++++++++++++++++++++++++++ ')
                AgentLogger.log(requestInfo.get_loggerName(),'Reason : '+repr(e.reason))
            int_errorCode = e.reason
            bool_toReturn = False  
            bool_print = False
            bool_isTimeoutError = True
        elif isinstance(e.reason, OSError):
            AgentLogger.log([requestInfo.get_loggerName()],'++++++++++++++++++++++++++++++++++ OS error ++++++++++++++++++++++++++++++++++ '+repr(requestInfo.get_host()))
            AgentLogger.log([requestInfo.get_loggerName()],'Error No : '+str(e.reason.errno)+' Error Message : '+str(e.reason.strerror))
            int_errorCode = e.reason
            bool_toReturn = False  
            bool_print = False
        elif isinstance(e,HTTPError):
            AgentLogger.log([requestInfo.get_loggerName()],'++++++++++++++++++++++++++++++++++ HTTP Error raised ++++++++++++++')
            AgentLogger.log([requestInfo.get_loggerName()],'Reason : '+repr(e.reason)+'Code : '+ repr(e.code))
            int_errorCode = e.code
            bool_toReturn = False
            bool_print = False
        else:
            AgentLogger.log(requestInfo.get_loggerName(),'*************************** URLError While Sending Data To Server *************************** '+ repr(e))
            traceback.print_exc()
            AgentLogger.log(requestInfo.get_loggerName(),'Reason : '+repr(e.reason)+' Type : '+repr(type(e.reason)))
            bool_toReturn = False
    except InvalidURL as e:
        AgentLogger.log(requestInfo.get_loggerName(),'++++++++++++++++++++++++++++++++++ Invalid URL exception raised ++++++++++++++')
        AgentLogger.log(requestInfo.get_loggerName(),'Exception:' + repr(e) )
        int_errorCode = 404
        bool_toReturn = False
        bool_print = False 
    except ssl.SSLError as e:
        AgentLogger.log(requestInfo.get_loggerName(),'*************************** SSL Error While Sending Data To Server *************************** '+ repr(e))
        traceback.print_exc()
        AgentLogger.log(requestInfo.get_loggerName(),' Error Number : '+repr(e.errno))
        int_errorCode = e.errno
        bool_toReturn = False      
        AgentLogger.log(requestInfo.get_loggerName(),'REQUEST INFO : '+str(requestInfo))             
    except socket.error as e:
        if e.errno == errno.ECONNREFUSED:
            AgentLogger.log(requestInfo.get_loggerName(),'++++++++++++++++++++++++++++++++++ Unable To Reach Server, Connection Refused ++++++++++++++++++++++++++++++++++ ')
            int_errorCode = e.errno
            bool_toReturn = False
            bool_print = False
        else:
            AgentLogger.log(requestInfo.get_loggerName(),'*************************** Exception While Sending Data To Server *************************** '+ repr(e))
            traceback.print_exc()
            AgentLogger.log(requestInfo.get_loggerName(),' Error While trying to reach server : '+repr(e.errno))
            int_errorCode = e.errno
            bool_toReturn = False
        AgentLogger.log(requestInfo.get_loggerName(),'REQUEST INFO : '+str(requestInfo))
    except Exception as e:    
        AgentLogger.log(requestInfo.get_loggerName(),'*************************** Exception While Sending Data To Server *************************** '+ repr(e))
        traceback.print_exc()
        bool_toReturn = False
        AgentLogger.log(requestInfo.get_loggerName(),'REQUEST INFO : '+str(requestInfo)) 
    finally:
        if not conn == None:
            conn.close()
        if requestInfo.get_host() == AgentConstants.DMS_SERVER and not bool_isTimeoutError:
            AgentLogger.debug(requestInfo.get_loggerName(),'Return status : '+repr(bool_toReturn)+' Error code : '+repr(int_errorCode)+' Response Data : '+repr(dict_responseData))
            AgentLogger.debug(requestInfo.get_loggerName(),'Response Headers : '+repr(dict_responseHeaders))
        elif requestInfo.get_host() != AgentConstants.DMS_SERVER and AgentConstants.AGENT_STATUS_UPDATE_SERVLET not in requestInfo.get_url() and AgentConstants.AGENT_FILE_COLLECTOR_SERVLET not in requestInfo.get_url():
            AgentLogger.log(requestInfo.get_loggerName(),'Return status : '+repr(bool_toReturn)+' Error code : '+repr(int_errorCode)+' Response Data : '+repr(dict_responseData))
            AgentLogger.debug(requestInfo.get_loggerName(),'Response Headers : '+repr(dict_responseHeaders))
        requestInfo = None    
    return bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData

def handleResponseHeaders(dict_responseHeaders, dict_responseData, str_invoker):
    bool_isSuccess = True
    try:
        if dict_responseHeaders and AgentConstants.WMS_FAILED_REQ in dict_responseHeaders and dict_responseHeaders[AgentConstants.WMS_FAILED_REQ] == 'TRUE':
            AgentLogger.log(AgentLogger.STDOUT,' : Response headers from server : ' + repr(dict_responseHeaders))
            str_responseData = dict_responseData.replace("<WMSFAILEDREQ>", "")
            AgentLogger.log(AgentLogger.STDOUT,' : Type : '+repr(type(str_responseData))+'Response data from server : ' + repr(str_responseData))
            com.manageengine.monagent.communication.DMSHandler.DMS.parseDMSResponse(None, str_responseData)
        elif dict_responseHeaders and AgentConstants.SUSPEND_UPLOAD_FLAG in dict_responseHeaders:
            AgentLogger.log(AgentLogger.STDOUT,' Suspend upload flag received from server. Hence suspending upload for : ' + str(dict_responseHeaders['SUSPEND_UPLOAD_TIME']) + ' seconds')
            com.manageengine.monagent.collector.DataCollector.UPLOAD_PAUSE_FLAG = True
            com.manageengine.monagent.collector.DataCollector.UPLOAD_PAUSE_TIME = int(dict_responseHeaders['SUSPEND_UPLOAD_TIME'])
        elif dict_responseHeaders and AgentConstants.PEER_VALIDATE in dict_responseHeaders:
            AgentLogger.log(AgentLogger.PING,repr(str_invoker)+' : PEER VALIDATION ')
            com.manageengine.monagent.network.AgentPingHandler.PingUtil.handlePeerRequest(dict_responseData, AgentConstants.PEER_VALIDATE)
        elif dict_responseHeaders and AgentConstants.PEER_SCHEDULE in dict_responseHeaders:
            AgentLogger.log(AgentLogger.PING,repr(str_invoker)+' : PEER SCHEDULE')
            com.manageengine.monagent.network.AgentPingHandler.PingUtil.handlePeerRequest(dict_responseData, AgentConstants.PEER_SCHEDULE)        
        elif dict_responseHeaders and AgentConstants.DISABLE_AGENT_SERVICE in dict_responseHeaders and dict_responseHeaders[AgentConstants.DISABLE_AGENT_SERVICE] == 'true':
            AgentLogger.log(AgentLogger.STDOUT,' : ==================================== UNINSTALL AGENT ====================================')
            AgentLogger.log(AgentLogger.STDOUT,' : Response headers from server : ' + repr(dict_responseHeaders))
            AgentLogger.log(AgentLogger.STDOUT,' : Skipping uninstall process')
            #AgentUtil.UninstallAgent()
        elif dict_responseHeaders and AgentConstants.SUSPEND_MONITORING in dict_responseHeaders and dict_responseHeaders[AgentConstants.SUSPEND_MONITORING] == AgentConstants.SUSPEND_DATA_COLLECTION: 
            AgentLogger.log(AgentLogger.STDOUT,' : Response headers from server : ' + repr(dict_responseHeaders))
            com.manageengine.monagent.collector.DataCollector.COLLECTOR.stopDataCollection()
        elif dict_responseHeaders and AgentConstants.GENERATE_RCA in dict_responseHeaders: 
            AgentLogger.log([ AgentLogger.STDOUT,AgentLogger.MAIN], repr(str_invoker)+' : GENERATE_RCA request received in response headers : ' + str(dict_responseHeaders[AgentConstants.GENERATE_RCA])+'\n')
            rcaInfo = com.manageengine.monagent.util.rca.RcaHandler.RcaInfo()
            rcaInfo.requestType = AgentConstants.GENERATE_RCA
            rcaInfo.action = AgentConstants.UPLOAD_RCA
            rcaInfo.downTimeInServer = dict_responseHeaders[AgentConstants.GENERATE_RCA]
            rcaInfo.searchTime = AgentUtil.getCurrentTimeInMillis(float(dict_responseHeaders[AgentConstants.GENERATE_RCA]))
            com.manageengine.monagent.util.rca.RcaHandler.RcaUtil.uploadRca(rcaInfo)
        elif dict_responseHeaders and AgentConstants.GENERATE_NETWORK_RCA in dict_responseHeaders:
            AgentLogger.log([ AgentLogger.STDOUT,AgentLogger.MAIN], repr(str_invoker)+' : GENERATE_NETWORK_RCA request received in response headers : ' + str(dict_responseHeaders[AgentConstants.GENERATE_NETWORK_RCA])+'\n')
            rcaInfo = com.manageengine.monagent.util.rca.RcaHandler.RcaInfo()
            rcaInfo.requestType = AgentConstants.GENERATE_NETWORK_RCA
            rcaInfo.action = AgentConstants.UPLOAD_RCA
            rcaInfo.downTimeInServer = dict_responseHeaders[AgentConstants.GENERATE_NETWORK_RCA]
            rcaInfo.searchTime = AgentUtil.getCurrentTimeInMillis(float(dict_responseHeaders[AgentConstants.GENERATE_NETWORK_RCA]))
            com.manageengine.monagent.util.rca.RcaHandler.RcaUtil.uploadRca(rcaInfo)
        elif dict_responseHeaders and AgentConstants.INITIATE_AGENT_UPGRADE in dict_responseHeaders:
            com.manageengine.monagent.upgrade.AgentUpgrader.handleUpgrade()
            AgentUtil.startWatchdog()
        elif dict_responseHeaders and AgentConstants.INITIATE_PATCH_UPGRADE in dict_responseHeaders:
            com.manageengine.monagent.upgrade.AgentUpgrader.handleUpgrade(None, True)
            AgentUtil.startWatchdog()
        elif (dict_responseHeaders and (AgentConstants.UPDATE_AGENT_CONFIG in dict_responseHeaders)):
            if dict_responseHeaders[AgentConstants.UPDATE_AGENT_CONFIG] == "true":
                com.manageengine.monagent.collector.DataConsolidator.updateAgentConfig()
        elif dict_responseHeaders and AgentConstants.DOCKER_DATA_COLLECTOR_REPONSE in dict_responseHeaders :
            com.manageengine.monagent.docker.DockUtils.updateSite24X7Ids(dict_responseData) 
        elif dict_responseHeaders and 'pluginkey' in dict_responseHeaders:
            pluginDict=dict_responseHeaders['pluginkey']
            AgentLogger.log(AgentLogger.PLUGINS,' plugin response --- {0}'.format(pluginDict))
            PluginUtils.updatePluginJson(pluginDict)
            d = json.loads(pluginDict)
            for k in d:
                AgentLogger.log([AgentLogger.MAIN,AgentLogger.PLUGINS],'Plugin Registered Successfully =====>'+repr(k)+'\n')
                AgentConstants.UPDATE_PLUGIN_INVENTORY=True 
                plug_name = k
                PluginMonitoring.pluginUtil.removePluginFromIgnoreList(plug_name)
        elif dict_responseHeaders and 'error' in dict_responseHeaders:
            error_dict=json.loads(dict_responseHeaders['error'])
            AgentLogger.log([AgentLogger.MAIN,AgentLogger.PLUGINS],'Error For Plugin  : {} / msg  : {} '.format(error_dict['plugin_name'],error_dict['error_msg'])+'\n')
            e_dict={}
            e_dict[error_dict['plugin_name']]={}
            e_dict[error_dict['plugin_name']]['status']=2
            e_dict[error_dict['plugin_name']]['error_msg']=error_dict['error_msg']
            PluginMonitoring.pluginUtil.populateIgnorePluginsList(error_dict['plugin_name'],error_dict['error_msg'])
            PluginUtils.updatePluginJson(json.dumps(e_dict))
        elif dict_responseHeaders and 'GET_CONSOLIDATED_REQUESTS' in dict_responseHeaders and dict_responseHeaders['GET_CONSOLIDATED_REQUESTS']=='true':
            AgentLogger.log(AgentLogger.MAIN,'Received consolidated request from status updater '+'\n')
            getConsolidatedWMSData()
        if dict_responseHeaders and 'poll' in dict_responseHeaders:
            pollInterval = dict_responseHeaders['poll']
            if pollInterval != AgentConstants.POLL_INTERVAL:
                AgentConstants.POLL_INTERVAL = pollInterval
                AgentLogger.log(AgentLogger.COLLECTOR,'Monitoring Poll Interval - {0} '.format(pollInterval)+'\n')
                dict={}
                dict['INTERVAL']=pollInterval
                com.manageengine.monagent.collector.DataCollector.changeMonitoringInterval(dict)
            else:
                AgentLogger.log(AgentLogger.COLLECTOR,'No difference in poll values |  server value -- {0} agent value -- {1}'.format(pollInterval,AgentConstants.POLL_INTERVAL)+'\n')
        if dict_responseHeaders and 'UPTIME_MONITORING' in dict_responseHeaders:
            AgentLogger.log(AgentLogger.STDOUT,'Uptime Monitoring Request Received From Server'+'\n')
            AgentLogger.log(AgentLogger.STDOUT,'Uptime Monitoring Before Server Request : '+repr(AgentConstants.UPTIME_MONITORING)+'\n')
            AgentConstants.UPTIME_MONITORING=dict_responseHeaders['UPTIME_MONITORING']
            AgentLogger.log(AgentLogger.STDOUT,'Uptime Monitoring After Server Request : '+repr(AgentConstants.UPTIME_MONITORING)+'\n')
        if dict_responseHeaders and 's_v' in dict_responseHeaders:
            AgentLogger.log(AgentLogger.STDOUT,'Server Violated Threshold JSON : {0}'.format(dict_responseHeaders['s_v']))
            AgentConstants.S_V_DICT = json.loads(dict_responseHeaders['s_v'])
        if dict_responseHeaders:
            handleResponseData(dict_responseHeaders,dict_responseData,str_invoker)
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL], ' *************************** Exception while handling response headers *************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess

def getConsolidatedWMSData():
    try:
        str_url = None
        dict_requestParameters={}
        dict_requestParameters['agentKey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['action'] = AgentConstants.GCR
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        requestInfo = RequestInfo()
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_method(AgentConstants.GCR)
        requestInfo.set_url(str_url)
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        requestInfo.set_timeout(15)
        (bool_isSuccess, errorCode, dict_responseHeaders, dict_responseData) = sendRequest(requestInfo)
        if dict_responseHeaders:
            handleResponseData(dict_responseHeaders,dict_responseData,'GET_CONSOLIDATED_REQUESTS')
    except Exception as e:
        AgentLogger.log(AgentLogger.MAIN,' Exception in get consolidated wms')
        traceback.print_exc()

#Parse WMS failed requests data here
def handleResponseData(dict_responseHeaders,dict_responseData,str_invoker):
    from com.manageengine.monagent import AgentConstants
    try:
        if 'CONSOLIDATED_REQUESTS' in dict_responseHeaders and dict_responseData:
            listFailedReq = dict_responseData
            AgentLogger.log(AgentLogger.MAIN,repr(str_invoker) + ' Found failed WMS data in response: '+repr(dict_responseData)+'\n')
            com.manageengine.monagent.communication.DMSHandler.processTasks(listFailedReq)
    except Exception as e:
        AgentLogger.log([AgentLogger.STDERR], ' *************************** Exception while consolidating WMS Response Data *************************** '+ repr(e))
        traceback.print_exc()

def downloadFile(str_downloadUrl, str_destinationFilePath, str_loggerName = AgentLogger.STDOUT):
    bool_isSuccess = True    
    try:
        requestInfo = RequestInfo()
        requestInfo.set_loggerName(str_loggerName)
        requestInfo.set_method(AgentConstants.HTTP_POST)        
        requestInfo.add_header('Connection', 'close')
        requestInfo.set_url(str_downloadUrl)    
        requestInfo.set_responseAction(saveFile)
        requestInfo.add_custom_param('download_file_path', str_destinationFilePath)
        bool_isSuccess, int_errorCode, dict_responseHeaders, dict_responseData = sendRequest(requestInfo)
    except Exception as e:
        AgentLogger.log(str_loggerName, 'FILE DOWNLOAD : *************************** Exception While Downloading File From The Location :'+repr(str_downloadUrl)+' *************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess

# Use this method only for download activity. ( app log also uses this )
def downloadPlugin(str_downloadUrl, str_destinationFilePath,str_host,str_loggerName = AgentLogger.STDOUT):
    bool_isSuccess = True    
    try:
        requestInfo = RequestInfo()
        requestInfo.set_loggerName(str_loggerName)
        requestInfo.set_method(AgentConstants.HTTP_GET)        
        requestInfo.add_header('Connection', 'close')
        requestInfo.set_protocol(AgentConstants.HTTPS_PROTOCOL)
        requestInfo.set_host(str_host)
        requestInfo.set_url(str_downloadUrl)    
        requestInfo.set_responseAction(saveFile)
        if str_host==AgentConstants.STATIC_SERVER_HOST:
            requestInfo.set_port(AgentConstants.URL_HTTPS_PORT)
        requestInfo.add_custom_param('download_file_path', str_destinationFilePath)
        bool_isSuccess, int_errorCode, dict_responseHeaders, dict_responseData = sendRequest(requestInfo)
    except Exception as e:
        AgentLogger.log(str_loggerName, 'FILE DOWNLOAD : *************************** Exception While Downloading File From The Location :'+repr(str_downloadUrl)+' *************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess

def downloadCustomFile(str_servlet, str_destinationFilePath, str_loggerName = AgentLogger.STDOUT):
    bool_isSuccess = True
    dict_requestParameters = {}
    str_url = None
    try:
        if AgentConstants.OS_NAME == AgentConstants.FREEBSD_OS:
            dict_requestParameters['t'] = 'FreeBSD'
        elif AgentConstants.OS_NAME == AgentConstants.LINUX_OS:
            dict_requestParameters['t'] = 'LINUX'
        else:
            dict_requestParameters['t'] = 'OSX'
        dict_requestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        AgentLogger.log(str_loggerName, 'CUSTOM FILE DOWNLOAD from : ' + str_url + ' initiated' )
        requestInfo = RequestInfo()
        requestInfo.set_loggerName(str_loggerName)
        requestInfo.set_method(AgentConstants.HTTP_GET)        
        requestInfo.add_header('Connection', 'close')
        requestInfo.set_url(str_url)    
        requestInfo.set_responseAction(saveFile)
        requestInfo.add_custom_param('download_file_path', str_destinationFilePath)
        bool_isSuccess, int_errorCode, dict_responseHeaders, dict_responseData = sendRequest(requestInfo)
    except Exception as e:
        AgentLogger.log(str_loggerName, 'FILE DOWNLOAD : *************************** Exception While Downloading File From The Location :'+repr(str_url)+' *************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess

def saveFile(requestInfo, str_responseData):
    bool_success = True
    file_obj = None
    AgentLogger.log(requestInfo.get_loggerName(), 'Saving file from the server to the path '+repr(requestInfo.get_custom_params()['download_file_path']))
    try:            
        file_obj = open(requestInfo.get_custom_params()['download_file_path'],'wb')
        file_obj.write(str_responseData)
    except Exception as e:
        AgentLogger.log(requestInfo.get_loggerName(), 'FILE DOWNLOAD : *************************** Exception While Saving The File To The Path:'+repr(requestInfo.get_custom_params()['download_file_path'])+' *************************** '+ repr(e))
        traceback.print_exc()
        bool_success = False
    finally:
        if not file_obj == None:
            file_obj.close()
    return bool_success

#Sends Request to an URL Without Port
def sendrequesttoUrl(url):
    if platform.system() == 'Darwin':
        ssl._create_default_https_context = ssl._create_unverified_context
    bool_toReturn = True
    int_errorCode = 0
    dict_responseHeaders = None
    dict_responseData = None
    conn = None
    bool_print = True
    str_url = url
    bool_isTimeoutError = False
    try:
        AgentLogger.log(AgentLogger.STDOUT,'================================= SEND REQUEST =================================')
        AgentLogger.debug(AgentLogger.STDOUT,'PROXY_INFO : '+str(PROXY_INFO))
        if PROXY_INFO:
            proxy = None
            proxy = urlconnection.ProxyHandler({AgentConstants.HTTP_PROTOCOL: PROXY_INFO.getUrl()})
            auth = urlconnection.HTTPBasicAuthHandler()
            opener = urlconnection.build_opener(proxy, auth, urlconnection.HTTPSHandler)
            urlconnection.install_opener(opener)
        else:
            proxy = urlconnection.ProxyHandler({})
            bypassOpener = urlconnection.build_opener(proxy)
            urlconnection.install_opener(bypassOpener)

        AgentLogger.log(AgentLogger.STDOUT,'REQUEST URL : '+str(str_url)) 
        requestObj = urlconnection.Request(str_url)
        response = urlconnection.urlopen(requestObj, timeout=3)
        if response.status == 200: 
            byte_responseData = None
            str_responseData = None
            AgentLogger.log(AgentLogger.STDOUT,'Page found successfully')    
            dict_responseHeaders = dict(response.getheaders())
            byte_responseData = response.read() 
            AgentLogger.log(AgentLogger.STDOUT,'Response content type : '+repr(dict_responseHeaders['Content-Type']))
            AgentLogger.debug(AgentLogger.STDOUT,'Response data : '+repr(byte_responseData))
            AgentLogger.debug(AgentLogger.STDOUT,'Type of response data : '+repr(type(byte_responseData)))
            if not byte_responseData == None:
                if 'encoding' in dict_responseHeaders:
                    str_responseData = byte_responseData
                elif 'Content-Type' in dict_responseHeaders and 'charset=UTF-16LE' in dict_responseHeaders['Content-Type']:
                    AgentLogger.log(AgentLogger.STDOUT,'charset found in response')
                    str_responseData = byte_responseData.decode('UTF-16LE')
                else:
                    str_responseData = byte_responseData.decode('UTF-8')
                if not str_responseData == '':
                    try:
                        str_unicodeResponseData = str(str_responseData,'UTF-16LE')
                        dict_responseData = json.loads(str_unicodeResponseData)
                    except Exception as e:
                        dict_responseData = str_responseData                    
        elif response.status == 404:
            AgentLogger.log(AgentLogger.STDOUT,'Response Status : '+repr(response.status)+', Page Not Found')
            bool_toReturn = False
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Response Status : '+repr(response.status)+' Reason : '+repr(response.reason))
            bool_toReturn = False
    except socket.timeout as e:
        AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ The read operation timed out ++++++++++++++++++++++++++++++++++ ')
        AgentLogger.log(AgentLogger.STDOUT,'Reason : '+repr(e))
        int_errorCode = e
        bool_toReturn = False  
        bool_print = False
        bool_isTimeoutError = True
    except URLError as e:
        if isinstance(e.reason, ConnectionRefusedError):
            AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ Unable To Reach Server, Connection Refused ++++++++++++++++++++++++++++++++++ ')
            AgentLogger.log(AgentLogger.STDOUT,'Reason : '+repr(e.reason))
            int_errorCode = e.reason
            bool_toReturn = False
            bool_print = False
        elif isinstance(e.reason, socket.timeout):
            AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ The read operation timed out ++++++++++++++++++++++++++++++++++ ')
            AgentLogger.log(AgentLogger.STDOUT,'Reason : '+repr(e.reason))
            int_errorCode = e.reason
            bool_toReturn = False  
            bool_print = False
            bool_isTimeoutError = True
        elif isinstance(e.reason, OSError):
            AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ OS error ++++++++++++++++++++++++++++++++++ ')
            AgentLogger.log(AgentLogger.STDOUT,'Error No : '+str(e.reason.errno)+' Error Message : '+str(e.reason.strerror))
            int_errorCode = e.reason
            bool_toReturn = False  
            bool_print = False
        elif isinstance(e,HTTPError):
            AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ HTTP Error raised ++++++++++++++')
            AgentLogger.log(AgentLogger.STDOUT,'Reason : '+repr(e.reason)+'Code : '+ repr(e.code))
            int_errorCode = e.code
            bool_toReturn = False
            bool_print = False
        else:
            AgentLogger.log(AgentLogger.STDOUT,'*************************** URLError While Sending Data To Server *************************** '+ repr(e))
            traceback.print_exc()
            AgentLogger.log(AgentLogger.STDOUT,'Reason : '+repr(e.reason)+' Type : '+repr(type(e.reason)))
            bool_toReturn = False
    except InvalidURL as e:
        AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ Invalid URL exception raised ++++++++++++++')
        AgentLogger.log(AgentLogger.STDOUT,'Exception:' + repr(e) )
        int_errorCode = 404
        bool_toReturn = False
        bool_print = False 
    except ssl.SSLError as e:
        AgentLogger.log(AgentLogger.STDOUT,'*************************** SSL Error While Sending Data To Server *************************** '+ repr(e))
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,' Error Number : '+repr(e.errno))
        int_errorCode = e.errno
        bool_toReturn = False      
    except socket.error as e:
        if e.errno == errno.ECONNREFUSED:
            AgentLogger.log(AgentLogger.STDOUT,'++++++++++++++++++++++++++++++++++ Unable To Reach Server, Connection Refused ++++++++++++++++++++++++++++++++++ ')
            int_errorCode = e.errno
            bool_toReturn = False
            bool_print = False
        else:
            AgentLogger.log(AgentLogger.STDOUT,'*************************** Exception While Sending Data To Server *************************** '+ repr(e))
            traceback.print_exc()
            AgentLogger.log(AgentLogger.STDOUT,' Error While trying to reach server : '+repr(e.errno))
            int_errorCode = e.errno
            bool_toReturn = False
    except Exception as e:    
        AgentLogger.log(AgentLogger.STDOUT,'*************************** Exception While Sending Data To Server *************************** '+ repr(e))
        traceback.print_exc()
        bool_toReturn = False
    finally:
        if not conn == None:
            conn.close()
        AgentLogger.debug(AgentLogger.STDOUT,'Return status : '+repr(bool_toReturn)+' Error code : '+repr(int_errorCode)+' Response Data : '+repr(dict_responseData))
        AgentLogger.debug(AgentLogger.STDOUT,'Response Headers : '+repr(dict_responseHeaders))
        AgentLogger.log(AgentLogger.STDOUT,'Return status : '+repr(bool_toReturn)+' Error code : '+repr(int_errorCode)+' Response Data : '+repr(dict_responseData))
        AgentLogger.debug(AgentLogger.STDOUT,'Response Headers : '+repr(dict_responseHeaders))
    return bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData


