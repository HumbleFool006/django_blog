#$Id$
import traceback
import platform
import os
import zipfile
import json
import time
from urllib.parse import urlparse
from urllib.parse import urlencode

import com
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentBuffer
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.upgrade import AgentUpgrader
from com.manageengine.monagent.util.AgentUtil import ZipUtil, FileUtil, AGENT_CONFIG, FileZipAndUploadInfo
from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.plugins import PluginUtils
import shutil

COMMAND_EXCLUDE=['rm','apt-get','yum','del','sudo']

def executeTask(dict_task):
    '''Utility method to download and execute script'''
    
    dict_requestParameters = {}
    try:
        AgentLogger.log(AgentLogger.STDOUT,'============Initiatind script download from DFS path: '+dict_task['dfspath'] + ' block id :'+ dict_task['dfsblockid']+'===============')
        script_path = AgentConstants.AGENT_TEMP_DIR + '/' + dict_task['SCRIPT_NAME']
        if dict_task['dfspath'] and dict_task['dfsblockid']:
            dict_requestParameters['t'] = 'linuxserveragent'
            dict_requestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['agentUniqueID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
            dict_requestParameters['dfspath'] = dict_task['dfspath']
            dict_requestParameters['dfsblockid'] = dict_task['dfsblockid']
            str_servlet = AgentConstants.FILE_DOWNLOAD_SERVLET
            if not dict_requestParameters == None:
                str_requestParameters = urlencode(dict_requestParameters)
                str_url = str_servlet + str_requestParameters
            bool_DownloadStatus = CommunicationHandler.downloadFile(str_url,script_path, AgentLogger.STDOUT)
            if bool_DownloadStatus:
                os.chmod(script_path, 0o755)
                bool_isSuccess, str_CommandOutput = AgentUtil.executeCommand(script_path,AgentLogger.STDOUT)
                if bool_isSuccess:
                    AgentLogger.log(AgentLogger.STDOUT,' Executed script output is: ' + str_CommandOutput)
                    #Add Parse and upload code here
                    
                else:
                    AgentLogger.log(AgentLogger.STDOUT,' Script Execution Failed ')
                if os.path.exists(script_path):
                    AgentLogger.log(AgentLogger.STDOUT,' Script Removed')
                    os.remove(script_path)
            else:
                AgentLogger.log(AgentLogger.STDOUT,'Failed to download script ' )
        else:
            AgentLogger.log(AgentLogger.STDOUT,'DFS path and blockid not recieved ' )
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR], ' *************************** Exception while executing recieved task *************************** '+ repr(e))
        traceback.print_exc()
        
        
def getLogFiles(dictFileDetails , str_loggerName=AgentLogger.STDOUT):
    '''Utility method to get log files and upload'''
    listIgnoreFiles = ['stderr','stdout']
    dict_requestParameters = {}
    try:
        zipFileName = ZipUtil.getUniqueZipFileName(AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), 'ViewLinuxLogs_'+str(AgentUtil.getCurrentTimeInMillis()))
        zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipFileName
        zip_fileObj = zipfile.ZipFile(zipFilePath, 'w')        
        
        if 'path' in dictFileDetails:
            filePath = dictFileDetails['path']
            fileName = AgentConstants.AGENT_WORKING_DIR + '/' + filePath
            head,tail=os.path.split(fileName)
            listfiles= os.listdir(head)
            count=0
            for each_file in listfiles:
                if not str(each_file).find(tail) == -1:
                    zip_fileObj.write(head+'/'+each_file,'data/'+each_file)
                    AgentLogger.log(str_loggerName,'File :'+ each_file + ' added to the zip file :'+zipFilePath)
                    count = count+1
            if count==0:
                AgentLogger.log(str_loggerName,'File :' + each_file + ' does not exists')
        else:
            listFilesToZip = os.listdir(AgentConstants.AGENT_LOG_DETAIL_DIR)
            for each_file in listFilesToZip:
                filePath = AgentConstants.AGENT_LOG_DETAIL_DIR + '/' + each_file
                fileName = each_file
                zip_fileObj.write(filePath,'data/'+fileName)
                AgentLogger.log(str_loggerName,'File :' + filePath + ' added to zip file :'+zipFilePath)
            
            if platform.system() == 'Darwin':
                mainLogPath ='/var/log/Site24x7_Agent/main.txt'
                criticalLogPath ='/var/log/Site24x7_Agent/critical.txt' 
            else:
                mainLogPath = '/opt/site24x7/monagent/logs/main.txt'
                criticalLogPath = '/opt/site24x7/monagent/logs/critical.txt'
            mainLogName = 'main.txt'
            criticalLogName= 'critical.txt'
            if os.path.exists(mainLogPath):
                zip_fileObj.write(mainLogPath,'data/'+mainLogName)
                AgentLogger.log(str_loggerName,'File :' + mainLogPath + ' added to zip file :'+zipFilePath)
            else:
                AgentLogger.log(str_loggerName,'File :' + mainLogPath + ' does not exists in agent directory')
            if os.path.exists(criticalLogPath):
                zip_fileObj.write(criticalLogPath,'data/'+criticalLogName)
                AgentLogger.log(str_loggerName,'File :' + criticalLogPath + ' added to zip file :'+zipFilePath)
            else:
                AgentLogger.log(str_loggerName,'File :' + criticalLogPath + ' does not exists in agent directory')
        
        zip_fileObj.close()
        '''UPLOAD ZIP FILE'''
        str_url = None
        file_obj = open(zipFilePath,'rb')
        str_dataToSend = file_obj.read()
        str_contentType = 'application/zip'
        dict_requestParameters['agentUniqueId'] = AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['custID'] = AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['DFS_KEY'] = dictFileDetails['DFS_KEY']
        dict_requestParameters['action'] = AgentConstants.SHARE_LOGS_REQUEST
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        requestInfo = CommunicationHandler.RequestInfo()
        requestInfo.set_loggerName(str_loggerName)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_data(str_dataToSend)
        requestInfo.set_dataType(str_contentType)
        requestInfo.add_header("Content-Type", str_contentType)
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        (bool_isSuccess, errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
        if bool_isSuccess:
            AgentLogger.log(str_loggerName,'File :' + zipFileName + ' uploaded successfully. Now deleting the zip file from agent directory.')
            os.remove(zipFilePath)
        else:
            AgentLogger.log(str_loggerName,'Failed to upload the file: ' + zipFilePath)
    except Exception as e:
        AgentLogger.log(str_loggerName,'***************************** Exception while getting log files *****************************')
        traceback.print_exc()
        
def uploadPlugin(plugin_name):
    try:
        dict_requestParameters = {}
        zipFileName = plugin_name+'.zip'
        zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipFileName
        zip_fileObj = zipfile.ZipFile(zipFilePath, 'w')
        for dirname in os.listdir(AgentConstants.AGENT_PLUGINS_DIR):
            if os.path.isdir(os.path.join(AgentConstants.AGENT_PLUGINS_DIR,dirname)):
                if dirname == plugin_name:
                    filepath = AgentConstants.AGENT_PLUGINS_DIR + plugin_name
                    for eachfile in os.listdir(filepath):
                        zip_fileObj.write(filepath+'/'+eachfile,eachfile)
                        AgentLogger.log(AgentLogger.STDOUT,'Adding file '+eachfile+' to the zip.')
        zip_fileObj.close()
        str_url = None
        file_obj = open(zipFilePath,'rb')
        str_dataToSend = file_obj.read()
        str_contentType = 'application/zip'
        dict_requestParameters['agentUniqueID'] = AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['custID'] = AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['action'] = AgentConstants.UPLOAD_PLUGIN
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        requestInfo = CommunicationHandler.RequestInfo()
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_data(str_dataToSend)
        requestInfo.set_dataType(str_contentType)
        requestInfo.add_header("Content-Type", str_contentType)
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        (bool_isSuccess, errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
        if bool_isSuccess:
            AgentLogger.log(AgentLogger.STDOUT,'File :' + zipFileName + ' uploaded successfully. Now deleting the zip file from agent directory.')
            os.remove(zipFilePath)
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Failed to upload the file: ' + zipFilePath)
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'Exception while uploading the plugin.')
        traceback.print_exc()
        
def getApplicationStatistics(listApps):
    dictAppStatus = {}
    try:
        for strName in listApps:
            cmd = "ps aux | grep -i "+strName+" | grep -v grep | awk '{print $2}'"
            boolIsSuccess, cmdOutput = AgentUtil.executeCommand(cmd, AgentLogger.STDOUT)
            if cmdOutput:
                AgentLogger.log(AgentLogger.STDOUT,'Output for '+ strName + ' is ' +str(cmdOutput))
                strStatus = 'Installed and Running'
                dictAppStatus[strName] = strStatus
            else:
                boolReturned, cmdOutput = AgentUtil.executeCommand(AgentConstants.APP_STATS_SCRIPT_FILE + ' ' + strName, AgentLogger.STDOUT)
                scriptOutput = cmdOutput.rstrip('\n')
                AgentLogger.log(AgentLogger.STDOUT,'Script Output for '+ strName + ' is ' + scriptOutput)
                if scriptOutput:
                    if scriptOutput == '0' or scriptOutput == '3':
                        strStatus = 'Installed'
                    else:
                        strStatus = 'Not installed'
                else:
                    strStatus = 'Not Found error'
                dictAppStatus[strName] = strStatus
        
        AgentLogger.log(AgentLogger.STDOUT,'Final status is '+ str(dictAppStatus))
    except Exception as e:        
        AgentLogger.log([AgentLogger.STDOUT, AgentLogger.STDERR],' ************************* Exception while getting app statistics************************* '+ repr(e))
        traceback.print_exc()
        
def extractCompressedFiles(destination,fileName):
    try:
        bool_toDelete=False
        Name, file_extension = os.path.splitext(fileName)
        if file_extension=='.gz':
            if Name.split('.')[-1]=='tar':
                tarHandle = AgentArchiver.getArchiver(AgentArchiver.ZIP)
                tarHandle.setMode('r:gz')
                tarHandle.setFile(destination)
                tarHandle.setPath(untarDir)
                tarHandle.decompress()
                tarHandle.close()
                bool_toDelete=True
                
        elif file_extension=='.zip':
            zipHandler = zipfile.ZipFile(os.path.join(destination,fileName), 'r')
            zipHandler.extractall(destination)
            zipHandler.close()
            bool_toDelete=True
        if bool_toDelete:
            os.remove(os.path.join(destination,fileName))
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'Exception while uncompressing compressed files.')
        
def constructUrlAndDeploy(blockId,dfsPath,dict_task):
    try:
        str_requestParameters=None
        str_url=None
        dict_requestParameters = {}
        dict_requestParameters['filePath']=dfsPath
        dict_requestParameters['blockID']=blockId
        dict_requestParameters['CUSTOMERID']=AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['agentkey']=AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        str_servlet=AgentConstants.DOWNLOAD_FILE_SERVLET
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        bool_isSuccess = CommunicationHandler.downloadFile(str_url, os.path.join(dict_task['DESTINATION'],dict_task['FILE_NAME']), str_loggerName = AgentLogger.STDOUT)
        if bool_isSuccess:
            extractCompressedFiles(dict_task['DESTINATION'],dict_task['FILE_NAME'])
        
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'Exception while deploying the file for action script')


def deployFile(dict_task):
    try:
        if '$$' in dict_task['DESTINATION']:
            file = dict_task['DESTINATION'].split('$$')[2]
            dict_task['DESTINATION'] = AgentConstants.AGENT_WORKING_DIR + file
            
        if 'BLOCK_ID' in dict_task and (dict_task['BLOCK_ID'] is not None or dict_task['BLOCK_ID']!=''):
            destinationDir=dict_task['DESTINATION']
        else:
            destinationDir=os.path.split(dict_task['DESTINATION'])[0]
        
        if not os.path.exists(destinationDir):
            os.makedirs(destinationDir)
            
        AgentLogger.log(AgentLogger.MAIN,'Deploying file in the destination.')
        if 'BLOCK_ID' in dict_task and (dict_task['BLOCK_ID'] is not None or dict_task['BLOCK_ID']!='') and 'DFS_PATH' in dict_task and (dict_task['DFS_PATH'] is not None or dict_task['DFS_PATH']!=''):
            constructUrlAndDeploy(dict_task['BLOCK_ID'],dict_task['DFS_PATH'],dict_task)
        elif 'URL' in dict_task and (dict_task['URL'] is not None or dict_task['URL']!='') :
            parsed_url=urlparse(dict_task['URL'])
            CommunicationHandler.downloadPlugin(parsed_url.path,dict_task['DESTINATION'],parsed_url.netloc,AgentLogger.MAIN)
        else:
            bool_toReturn=AgentUpgrader.downloadPatch(dict_task['DESTINATION'],os.path.split(dict_task['DESTINATION'])[0])
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'Exception while deploying the file')

def deployPlugin(dict_task):
    try:
        deployment_success=False
        str_pluginName = dict_task['name']
        str_pluginName=str_pluginName.lower()
        plugin_config=PluginUtils.PLUGIN_CONF_DICT
        if str_pluginName not in plugin_config:
            static_plugin_url="//server//plugins//{0}".format(str_pluginName)+'.zip'
            file_path=AgentConstants.AGENT_PLUGINS_DIR+str_pluginName+'.zip'
            AgentLogger.log(AgentLogger.STDOUT,'Downloading {0} plugin From Static Server'.format(str_pluginName))
            bool_DownloadStatus = CommunicationHandler.downloadPlugin(static_plugin_url,file_path,AgentConstants.STATIC_SERVER_HOST, AgentLogger.STDOUT)
            if not bool_DownloadStatus:
                AgentLogger.log(AgentLogger.STDOUT,'Downloading {0} plugin From sagent'.format(str_pluginName))
                static_plugin_url="//sagent//plugins//{0}".format(str_pluginName)+'.zip'
                bool_DownloadStatus = CommunicationHandler.downloadPlugin(static_plugin_url,file_path,AgentUtil.AGENT_CONFIG.get('SERVER_INFO', 'server_name'),AgentLogger.STDOUT)
                if not bool_DownloadStatus:
                    AgentLogger.log(AgentLogger.STDOUT,'Plugin Deployment Failed')
                else:
                    AgentLogger.log(AgentLogger.STDOUT,'Plugin Deployed Successfully via sagent')
                    deployment_success=True
            else:
                AgentLogger.log(AgentLogger.STDOUT,'Plugin Deployed Successfully')
                deployment_success=True
            if deployment_success:
                bool_Unzip=True
                try:
                    from zipfile import ZipFile
                    zip = ZipFile(file_path)
                    zip.extractall(AgentConstants.AGENT_PLUGINS_DIR)
                except Exception as e:
                    bool_Unzip=False
                    AgentLogger.log(AgentLogger.STDOUT,'exception while unzipping plugin')
                    traceback.print_exc()
            if bool_Unzip:
                os.remove(file_path)
                AgentLogger.log(AgentLogger.STDOUT,'File Removed Successfully')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Plugin Already Deployed')
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'exception while deploy plugin')

#need to prevent alias commands && more than one commands.
def executeCommand(dict_task):
    dictToReturn={}
    output=[]
    dict={}
    dict_requestParameters={}
    try:
        command=dict_task['COMMAND']
        AgentLogger.log(AgentLogger.CHECKS, 'Command ======>' + repr(command))
        if command is not None:
            if any(command.startswith(x) for x in COMMAND_EXCLUDE):
                AgentLogger.log(AgentLogger.CHECKS, 'Command Validation Failed --> '+repr(command))
                return
            if any(x in command for x in COMMAND_EXCLUDE):
                 AgentLogger.log(AgentLogger.CHECKS, 'Command Validation Failed Level 2 --> '+repr(command))
                 return
            executorObj = AgentUtil.Executor()
            executorObj.setLogger(AgentLogger.STDOUT)
            executorObj.setTimeout(30)
            executorObj.setCommand(command)
            executorObj.executeCommand()
            dictToReturn['result'] = executorObj.isSuccess()
            cmdOutput = executorObj.getStdOut()
            AgentLogger.log(AgentLogger.CHECKS, 'Command Output ======>' + repr(cmdOutput))
            if not cmdOutput == None and cmdOutput!='':
                output=cmdOutput.strip().split("\n")
                dict['output']=output
            cmdError  = AgentUtil.getModifiedString(executorObj.getStdErr(), 100, 100)
            if cmdOutput=='' and cmdError!='':
                AgentLogger.log(AgentLogger.CHECKS, 'Command Error Output ======>' + repr(cmdError))
                dict['output']=cmdError.strip().split("\n")
        else:
            AgentLogger.log(AgentLogger.CHECKS, 'Command is None'.format(command))
            return
        
        AgentLogger.log(AgentLogger.CHECKS,'Command Final Output --> {0}'.format(dict))
        
        str_url = None
        str_contentType = 'application/json'
        dict_requestParameters['agentUniqueID'] = AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['custID'] = AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['action'] = AgentConstants.EXECUTE_COMMAND
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        dict_requestParameters['command'] = command
        dict_requestParameters['requestId'] = dict_task['AGENT_REQUEST_ID']
        str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        str_dataToSend = json.dumps(dict)
        requestInfo = CommunicationHandler.RequestInfo()
        requestInfo.set_loggerName(AgentLogger.MAIN)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_data(str_dataToSend)
        requestInfo.set_dataType(str_contentType)
        requestInfo.add_header("Content-Type", str_contentType)
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        requestInfo.set_timeout(30)
        (bool_isSuccess, errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
        if bool_isSuccess:
            AgentLogger.log(AgentLogger.CHECKS,'Command Output Uploaded Successfully')
        else:
            AgentLogger.log(AgentLogger.CHECKS,'Failed to upload the Command Output')
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.CHECKS,'exception while executing command')
        
def downloadPlugin(dict_task):
    try:
        deployment_success=False
        bool_Unzip=False
        str_pluginName = dict_task['PLUGIN_NAME']
        str_pluginName = str_pluginName.lower()
        str_downloadUrl = dict_task['URL']
        file_path=AgentConstants.AGENT_PLUGINS_DIR+os.path.splitext(str_pluginName)[0]+'.zip'
        AgentLogger.log(AgentLogger.PLUGINS,'Downloading {0} plugin from url {1}'.format(str_pluginName,str_downloadUrl))
        bool_DownloadStatus = CommunicationHandler.downloadPlugin(str_downloadUrl,file_path,AgentConstants.STATIC_SERVER_HOST, AgentLogger.PLUGINS)
        if not bool_DownloadStatus:
            AgentLogger.log(AgentLogger.PLUGINS,'Plugin Deployment Failed')
        else:
            AgentLogger.log(AgentLogger.PLUGINS,'Plugin Deployed Successfully')
            deployment_success=True
        if deployment_success:
            bool_Unzip=True
            try:
                from zipfile import ZipFile
                zip = ZipFile(file_path)
                zip.extractall(AgentConstants.AGENT_PLUGINS_DIR)
            except Exception as e:
                bool_Unzip=False
                AgentLogger.log(AgentLogger.PLUGINS,'exception while un zipping plugin')
                traceback.print_exc()
        if bool_Unzip:
            os.remove(file_path)
            AgentLogger.log(AgentLogger.PLUGINS,'File Removed Successfully')
        if deployment_success:
            e_dict={}
            e_dict[str_pluginName]={}
            e_dict[str_pluginName]['status']=9
            e_dict[str_pluginName]['version']=1
            e_dict[str_pluginName]['error_msg']='plugin downloaded successfully'
        else:
            e_dict={}
            e_dict[str_pluginName]={}
            e_dict[str_pluginName]['status']=10
            e_dict[str_pluginName]['version']=1
            e_dict[str_pluginName]['error_msg']='plugin download failed'
        PLUGIN_CONF_DICT = PluginUtils.getPluginConfDict()
        global PLUGIN_CONF_DICT
        PLUGIN_CONF_DICT.setdefault(str_pluginName,{})
        PLUGIN_CONF_DICT[str_pluginName]['version']=1
        PluginUtils.updatePluginJson(json.dumps(e_dict))
        com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.updateInventoryToServer()
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.PLUGINS,'exception while executing command')

def triggerReboot(dict_task):
    try:
        AgentLogger.log(AgentLogger.CHECKS,'reboot action invoked')
        sendRebootStatus(dict_task)
        createInitTimeFile(dict_task)
        dict_task['COMMAND'] = 'reboot'
        executeCommand(dict_task)
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.CHECKS,'exception while triggering reboot ')      
        
        
def createInitTimeFile(dict_task):
    try:
        if 'INIT_TIME' in dict_task:
            initTime = dict_task['INIT_TIME']
            scriptId = dict_task['SCRIPT_ID']
            str_rebootInitTime = 'reboot_'+initTime+'_'+scriptId
            file_obj = open(AgentConstants.AGENT_TEMP_DIR+'/'+str_rebootInitTime,'w')
            file_obj.write(str_rebootInitTime)
            if not file_obj == None:
                file_obj.close()
    except Exception as e:
        traceback.print_exc()
        
def sendRebootStatus(dict_task):
    dict_requestParameters = {}
    dictData={}
    try:
        zipAndUploadInfo = FileZipAndUploadInfo()
        zipAndUploadInfo.filesToZip = None
        dict_requestParameters['agentKey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['dc'] = AgentUtil.getCurrentTimeInMillis()
        dict_requestParameters['action'] = 'ACTION_SCRIPT_RESULT'
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        dictData['script_id']=dict_task['SCRIPT_ID']
        dictData['response']='initiated'
        dictData['status']='true'
        dictData['origin']=dict_task['ORIGIN']
        dictData['init_time']=dict_task['INIT_TIME']
        dictData['start_time']=AgentUtil.getTimeInMillis()
        dictData['duration']=0
        dictData['Error']=''
        zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
        zipAndUploadInfo.uploadServlet = AgentConstants.SCRIPT_RESULT_SERVLET
        zipAndUploadInfo.uploadData = json.dumps(dictData)
        AgentLogger.log(AgentLogger.STDOUT, 'reboot action data -- {0}'.format(dictData))
        AgentBuffer.getBuffer(AgentConstants.FILES_TO_UPLOAD_BUFFER).add(zipAndUploadInfo)
        time.sleep(2)
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR], ' *************************** Exception while sending reboot status *************************** '+ repr(e))
        traceback.print_exc()

def CleanUpActionScript(dict_task):
    try:
        if 'PATH' in dict_task:
            cleanUpFolders = dict_task['PATH']
            for each in cleanUpFolders:
                if '$$' in each:
                    file = each.split('$$')[2]
                    cleanUpFolder = AgentConstants.AGENT_WORKING_DIR + file
                    AgentLogger.log(AgentLogger.STDOUT,'cleaning up action script - {0}'.format(cleanUpFolder))
                    if os.path.exists(cleanUpFolder):
                        shutil.rmtree(cleanUpFolder)
                    else:
                        AgentLogger.log(AgentLogger.STDOUT,'folder not exist - {0}'.format(cleanUpFolder))
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR], ' *************************** Exception while cleaning up action script *************************** '+ repr(e))
        traceback.print_exc()