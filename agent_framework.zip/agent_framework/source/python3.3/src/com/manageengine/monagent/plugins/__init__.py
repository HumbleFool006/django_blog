#$Id$
import traceback
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.plugins.PluginMonitoring import PluginHandler 

def initialize():
    try:
        PluginMonitoring.pluginUtil = PluginHandler()
    except Exception as e:
        AgentLogger.log([AgentLogger.PLUGINS,AgentLogger.STDERR], ' *************************** Exception while initialising plugins module *************************** '+ repr(e))
        traceback.print_exc()

initialize()