#$Id$
import os
import sys
import time
import traceback
import threading
import errno
import shutil
import re
import json
import collections
import socket
from collections import deque, OrderedDict
import copy
from six.moves.urllib.parse import urlencode
from operator import itemgetter

from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util.AgentUtil import ZipUtil
from com.manageengine.monagent.util.AgentUtil import FileUtil
from com.manageengine.monagent.util.AgentUtil import FileZipAndUploadInfo
from com.manageengine.monagent.util.rca.RcaHandler import RcaUtil, RcaInfo
from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.docker.DockerAgent import DockerDataCollector
from com.manageengine.monagent.scheduler import AgentScheduler
from com.manageengine.monagent.util import AgentBuffer
from com.manageengine.monagent.util import AgentParser
import com.manageengine.monagent.network
from com.manageengine.monagent.actions import ScriptHandler

from com.manageengine.monagent.communication import UdpHandler
from com.manageengine.monagent.communication import BasicClientHandler
from com.manageengine.monagent.actions import ScriptMonitoring

from com.manageengine.monagent.collector import DataConsolidator
from com.manageengine.monagent.plugins import PluginMonitoring
from com.manageengine.monagent.plugins import PluginHandler
#from twisted.python.zippath import ZipArchive

COLLECTOR = None
CPU_UTIL_VALUES = deque([])
PROCESS_LIST = []
FREE_PROCESS_LIST = []
MONITORS_INFO = None
CUSTOM_MONITORS_INFO = None
PREVIOUS_COUNTER_VALUES = {}
COLLECTOR_IMPL = None
APP_IMPL = None

FILES_TO_ZIP_BUFFER = None
FILES_TO_UPLOAD_BUFFER = None
FILE_UPLOADER = None
FILE_ZIPPER = None
ACTIVATOR = None
UPLOAD_DETAILS = None
LIST_UPLOAD_CATEGORIES = None
UPLOAD_DATA_DIR_IMPL = None
FILES_UPLOADED = 0
LAST_UPLOADED_TIME = 0
UPLOAD_PAUSE_FLAG = False
UPLOAD_PAUSE_TIME = 0

def initialize():
    global FILES_TO_ZIP_BUFFER, FILE_UPLOADER, FILE_ZIPPER, COLLECTOR_IMPL, APP_IMPL, LIST_UPLOAD_CATEGORIES, UPLOAD_DATA_DIR_IMPL, ACTIVATOR
    if not loadQueryConf():
        return False
    DataConsolidator.initialize()
    loadProcessList()
    ProcessUtil.loadProcessStatusList()
    ProcessUtil.loadProcessDetailsList()
    LIST_UPLOAD_CATEGORIES = ['Upload','Statistics']
    FILES_TO_ZIP_BUFFER = AgentBuffer.getBuffer(AgentConstants.FILES_TO_ZIP_BUFFER,AgentConstants.MAX_SIZE_ZIP_BUFFER)
    FILES_TO_UPLOAD_BUFFER = AgentBuffer.getBuffer(AgentConstants.FILES_TO_UPLOAD_BUFFER, AgentConstants.MAX_SIZE_UPLOAD_BUFFER )
    initializeFileAndZipIds()
    FILE_ZIPPER = FileZipper()
    FILE_ZIPPER.start()
    #UPLOAD_PAUSE_FLAG = False
    UPLOADER = Uploader()
    UPLOADER.start()
    ACTIVATOR = Activator()
    UPLOAD_DATA_DIR_IMPL = {'Upload':UPLOADER.addFilesinDataDirectory,
                            'Statistics':UdpHandler.SysLogStatsUtil.addFilesinDataDirectory,
                            #'Custom':FILE_UPLOADER.addCustomFilesinDataDirectory
                           }
    COLLECTOR_IMPL = {
                      'ChecksMonitoring': BasicClientHandler.checksMonitor,
                      #'ScriptMonitoring' : ScriptMonitoring.checkScriptMonitor,
                      'EventLogMonitoring': UdpHandler.SysLogStatsUtil.collectSysLogData, 
                      'RootCauseAnalysis': RcaUtil.generateRca,
                      'ProcessMonitoring': ProcessUtil.processMonitor,
                      'PluginMonitoring': executePlugins,
                      'DockerMonitoring': fetchDockerMetrics
                     }
    
    APP_IMPL = {
                'Docker':collectDockerData
               }
    COLLECTOR.scheduleDataCollection()
    return True

def updateMonitoringInterval(dictData):
    AgentLogger.log(AgentLogger.STDOUT,'update dc monitoring interval \n')
    try:
        if 'INTERVAL' in dictData and dictData['INTERVAL']:
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(AgentConstants.AGENT_MONITORS_GROUP_FILE)
            fileObj.set_dataType('json')
            fileObj.set_mode('rb')
            fileObj.set_dataEncoding('UTF-8')
            fileObj.set_loggerName(AgentLogger.COLLECTOR)
            fileObj.set_logging(False)
            bool_toReturn, dictCustomMonitors = FileUtil.readData(fileObj)
            dictCustomMonitors['MonitorGroup']['Monitoring']['Interval'] = dictData['INTERVAL']
            AgentLogger.log(AgentLogger.STDOUT,' updated monitoring configuraton -- '+json.dumps(dictCustomMonitors)+'\n')
            fileObj.set_data(dictCustomMonitors)
            fileObj.set_mode('wb')
            bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
            COLLECTOR.loadMonitors()
        else:
            AgentLogger.log([AgentLogger.MAIN,AgentLogger.CRITICAL],' interval parameter not found in the dictionary -- {0}'.format(json.dumps(dictData)))
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' ************************** Exception while changing monitoring interval **************************** ')
        traceback.print_exc()

def changeMonitoringInterval(dictData):
    AgentLogger.log(AgentLogger.STDOUT,'update dc monitoring interval \n')
    try:
        if 'INTERVAL' in dictData and dictData['INTERVAL']:
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(AgentConstants.AGENT_MONITORS_GROUP_FILE)
            fileObj.set_dataType('json')
            fileObj.set_mode('rb')
            fileObj.set_dataEncoding('UTF-8')
            fileObj.set_loggerName(AgentLogger.COLLECTOR)
            fileObj.set_logging(False)
            bool_toReturn, dictCustomMonitors = FileUtil.readData(fileObj)
            dictCustomMonitors['MonitorGroup']['Monitoring']['Interval'] = dictData['INTERVAL']
            AgentLogger.log(AgentLogger.COLLECTOR,' updated monitoring configuraton -- '+repr(dictCustomMonitors)+'\n')
            fileObj.set_data(dictCustomMonitors)
            fileObj.set_mode('wb')
            bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
            COLLECTOR.loadMonitors()
            COLLECTOR.scheduleDataCollection()
        else:
            AgentLogger.log([AgentLogger.MAIN,AgentLogger.CRITICAL],' interval parameter not found in the dictionary -- {0}'.format(json.dumps(dictData)))
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' ************************** Exception while changing monitoring interval **************************** ')
        traceback.print_exc()


def changeCPU(dictData):
    try:
        fileObj = AgentUtil.FileObject()
        fileObj.set_filePath(AgentConstants.AGENT_CUSTOM_MONITORS_GROUP_FILE)
        fileObj.set_dataType('json')
        fileObj.set_mode('rb')
        fileObj.set_dataEncoding('UTF-8')
        fileObj.set_loggerName(AgentLogger.COLLECTOR)
        fileObj.set_logging(False)
        bool_toReturn, dictCustomMonitors = FileUtil.readData(fileObj)
        if 'CPUMonitoring' in dictCustomMonitors['MonitorGroup']:
            dictCustomMonitors['MonitorGroup']['CPUMonitoring']['Schedule'] = "True"
            dictCustomMonitors['MonitorGroup']['CPUMonitoring']['Interval'] = dictData['CPU_INTERVAL']
        else:
            dictCustomMonitors['MonitorGroup'].setdefault('CPUMonitoring',{})
            dictCustomMonitors['MonitorGroup']['CPUMonitoring']['Schedule'] = "True"
            dictCustomMonitors['MonitorGroup']['CPUMonitoring']['Interval'] = dictData['CPU_INTERVAL']
            dictCustomMonitors['MonitorGroup']['CPUMonitoring']['SaveFile'] = "False"
            listData = []
            listData.append('CPU Utilization')
            dictCustomMonitors['MonitorGroup']['CPUMonitoring'].setdefault('Monitors',listData)
        fileObj.set_data(dictCustomMonitors)
        fileObj.set_mode('wb')
        bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
        COLLECTOR.loadMonitors()
        COLLECTOR.scheduleDataCollection()
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR],' ************************** Exception while changing CPU utilization details **************************** ')
        traceback.print_exc()

def addAndFindAverage(float_cpu):
    floatAvgCPU = None
    try:
        if CPU_UTIL_VALUES:
            AgentLogger.log(AgentLogger.COLLECTOR,' Current CPU values : ' + str(CPU_UTIL_VALUES)) 
        else:
            AgentLogger.log(AgentLogger.COLLECTOR,' No current CPU values ')
        if len(CPU_UTIL_VALUES) >= AgentConstants.CPU_SAMPLE_VALUES:
            popped_cpu = CPU_UTIL_VALUES.popleft()
            AgentLogger.debug(AgentLogger.COLLECTOR,' Popped oldest CPU value : ' + str(popped_cpu))
            CPU_UTIL_VALUES.append(float_cpu)
            AgentLogger.debug(AgentLogger.COLLECTOR,' Appended new CPU value : ' + str(float_cpu))
        elif len(CPU_UTIL_VALUES) < AgentConstants.CPU_SAMPLE_VALUES:
            CPU_UTIL_VALUES.append(float_cpu)
            AgentLogger.debug(AgentLogger.COLLECTOR,' Added new CPU value : ' + str(float_cpu))
        floatAvgCPU = round(sum(CPU_UTIL_VALUES)/float(len(CPU_UTIL_VALUES)),1)
        AgentLogger.log(AgentLogger.COLLECTOR,' Calculated Average CPU Value : ' + str(floatAvgCPU))
    except ZeroDivisionError as e:
        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' ************************** Divide by zero Exception occured in avg cpu values **************************** \n')
        floatAvgCPU = float_cpu
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' ************************** Exception while finding avg CPU utilization **************************** \n')
        traceback.print_exc()
        floatAvgCPU = float_cpu
    finally:
        return floatAvgCPU


def collectDockerData():
    dictDataToSave = None
    if ((AgentConstants.AGENT_DOCKER_INSTALLED == 1) and (AgentConstants.AGENT_DOCKER_ENABLED == 1)):
        dictDataToSave = DockerDataCollector().collectDockerData()
        if ((dictDataToSave) and ('DOCKER' in dictDataToSave)):
            dictDataToSave['DOCKER'].setdefault('availability',1)
        else:
            tempDict = {}
            tempDict.setdefault('DOCKER',{}).setdefault('availability',0)
            tempDict['DOCKER'].setdefault('error_code', 19002)
            return tempDict
    return dictDataToSave

def fetchDockerMetrics():
    try:
        listofFiles = []
        dockerData = collectDockerData()
        if dockerData:
            bool_isSuccess, str_fileName = saveCollectedData(dockerData,'Docker')
            if bool_isSuccess:
                listofFiles.append(str_fileName)
                zipDockerData(listofFiles)
            else:
                AgentLogger.log(AgentLogger.MAIN,'Problem while saving docker performance metrics \n')
    except Exception as e:
        AgentLogger.log(AgentLogger.CRITICAL,'Exception in fetching docker performance metrics \n')
        traceback.print_exc()

def zipDockerData(listofFiles):
    dict_requestParameters = {}
    try:
        zipAndUploadInfo = FileZipAndUploadInfo()
        zipAndUploadInfo.filesToZip = listofFiles
        zipAndUploadInfo.zipFileName = ZipUtil.getUniqueZipFileName(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), 'Application_' +str(AgentUtil.getTimeInMillis()))
        zipAndUploadInfo.zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipAndUploadInfo.zipFileName
        dict_requestParameters['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['CUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['AGENTUNIQUEID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
        dict_requestParameters['FILENAME'] = zipAndUploadInfo.zipFilePath
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
        zipAndUploadInfo.uploadServlet = AgentConstants.APPLICATION_COLLECTOR_SERVLET
        FILES_TO_ZIP_BUFFER.add(zipAndUploadInfo)
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while setting zipanduploadinfo in collector *************************** '+ repr(e) + '\n')
        traceback.print_exc()

def executePlugins():
    try:
        #AgentLogger.log(AgentLogger.PLUGINS,'#### invoked successfully ####')
        if AgentConstants.UPTIME_MONITORING=="false":
            if not AgentUtil.AGENT_CONFIG.has_section(AgentConstants.PLUGINS_SECTION):
                PluginMonitoring.pluginUtil.loadPluginTask()
                PluginMonitoring.pluginUtil.initiateZipTask()
            else:
                AgentLogger.log(AgentLogger.PLUGINS,'#### plugins disabled ####')
        else:
            AgentLogger.log(AgentLogger.PLUGINS,'#### plugins disabled - up time monitoring ####')
    except Exception as e:
        AgentLogger.log(AgentLogger.CRITICAL,' Exception in plugin DC execution \n')
        traceback.print_exc()
    
def persistProcessList():
    if not PROCESS_LIST == None:  
        AgentLogger.log(AgentLogger.COLLECTOR,'================================= PERSISTING PROCESS LIST =================================')
        AgentLogger.log(AgentLogger.COLLECTOR,repr(PROCESS_LIST))      
        if not AgentUtil.writeDataToFile(AgentConstants.AGENT_PROCESS_LIST_FILE, PROCESS_LIST):
            AgentLogger.log(AgentLogger.CRITICAL,'************************* Problem while persisting process list ************************* \n') 
    else:
        AgentLogger.log(AgentLogger.CRITICAL,'************************* Process list to be persisted is empty ************************** \n')
        
def loadProcessList():
    global PROCESS_LIST
    AgentLogger.log(AgentLogger.COLLECTOR,'Loading process list')
    if os.path.exists(AgentConstants.AGENT_PROCESS_LIST_FILE):
        (bool_status, PROCESS_LIST) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PROCESS_LIST_FILE)
        if bool_status:        
            AgentLogger.log(AgentLogger.COLLECTOR,'Process list Loaded From '+AgentConstants.AGENT_PROCESS_LIST_FILE+' : '+repr(PROCESS_LIST))
        else:
            AgentLogger.log(AgentLogger.CRITICAL,'*********************** Problem while loading process list ************************ \n')
        if FREE_PROCESS_LIST:
            updateProcessList(FREE_PROCESS_LIST)
    else:
        if FREE_PROCESS_LIST:
            updateProcessList(FREE_PROCESS_LIST)
    
def updateProcessList(list_processDetails):
    AgentLogger.log(AgentLogger.COLLECTOR,'Process list to be updated : '+repr(list_processDetails))
    if list_processDetails:
        for processDetail in list_processDetails:
            #AgentLogger.log(AgentLogger.COLLECTOR,'Process detail : '+repr(processDetail))
            #AgentLogger.log(AgentLogger.COLLECTOR,'Process Name : '+repr(processDetail['Name']))
            if len(PROCESS_LIST) == 0:
                AgentLogger.debug(AgentLogger.COLLECTOR,'Appending the following process details for monitoring 1 : '+repr(processDetail))
                PROCESS_LIST.append(processDetail)
            else:
                for index, processMap in enumerate(PROCESS_LIST):
                    AgentLogger.debug(AgentLogger.COLLECTOR,'Index : '+repr(index)+' Length : '+repr(len(PROCESS_LIST)))
                    if 'PathName' in processDetail:
                        if len(PROCESS_LIST)-1 == index:
                            if 'PathName' not in processMap:                                
                                AgentLogger.debug(AgentLogger.COLLECTOR,'Appending the following process details for monitoring 2 : '+repr(processDetail))
                                PROCESS_LIST.append(processDetail)
                            elif processDetail['Name'] != processMap['Name'] or processDetail['PathName'] != processMap['PathName'] or processDetail['Arguments'] != processMap['Arguments']:
                                AgentLogger.debug(AgentLogger.COLLECTOR,'Appending the following process details for monitoring 3 : '+repr(processDetail))
                                PROCESS_LIST.append(processDetail)
                        else:
                            if 'PathName' not in processMap:
                                AgentLogger.debug(AgentLogger.COLLECTOR,'2 continue : '+repr(processMap))
                                continue
                            if processDetail['Name'] == processMap['Name'] and processDetail['PathName'] == processMap['PathName'] and processDetail['Arguments'] == processMap['Arguments']:
                                AgentLogger.debug(AgentLogger.COLLECTOR,'2 break : '+repr(processMap))
                                break
                    else:
                        if len(PROCESS_LIST)-1 == index:
                            if 'PathName' in processMap:                                
                                AgentLogger.debug(AgentLogger.COLLECTOR,'Appending the following process details for monitoring 4 : '+repr(processDetail))
                                PROCESS_LIST.append(processDetail)
                            elif not processDetail['Name'] == processMap['Name']:
                                AgentLogger.debug(AgentLogger.COLLECTOR,'Appending the following process details for monitoring 5 : '+repr(processDetail))
                                PROCESS_LIST.append(processDetail)
                        else:
                            if 'PathName' in processMap:
                                AgentLogger.debug(AgentLogger.COLLECTOR,'3 continue : '+repr(processMap))
                                continue
                            if processDetail['Name'] == processMap['Name']:
                                AgentLogger.debug(AgentLogger.COLLECTOR,'3 break : '+repr(processMap))
                                break
        persistProcessList()
        
def filterProcess(dict_processData):
    processList = dict_processData['Process Details']
    filteredProcessList = []
    for index, processMap in enumerate(PROCESS_LIST):
        if 'PathName' in processMap:
            for processDetail in processList:
                if processMap['Name'] ==  processDetail['PROCESS_NAME'] and processMap['PathName'] ==  processDetail['EXEUTABLE_PATH'] and processMap['Arguments'] ==  processDetail['COMMANDLINE']:
                    filteredProcessList.append(processDetail)
        else:
            for processDetail in processList:
                if processMap['Name'] ==  processDetail['PROCESS_NAME']:
                    filteredProcessList.append(processDetail)
    AgentLogger.log(AgentLogger.COLLECTOR,'Filtered process list : '+repr(filteredProcessList))
    dict_processData['Process Details'] = filteredProcessList
            
def getProcessNameList():
    list_toReturn = []
    AgentLogger.log(AgentLogger.COLLECTOR,'PROCESS_LIST 1 : '+repr(PROCESS_LIST))
    for dict_processDetails in PROCESS_LIST:
        list_toReturn.append(dict_processDetails['Name'])
    return list_toReturn

def synchronized(func):    
    func.__lock__ = threading.Lock()        
    def synced_func(*args, **kws):
        with func.__lock__:
            func(*args, **kws)
    return synced_func

class ProcessUtil:
    list_downNotifiedProcess = [] # Static variable
    dict_totalProcessDetails = {'Process Details':[]} # Static variable
    process_status_dict = {}    
    #process_details_dict = {'Process Details':[]}
    def __init__(self):
        pass
    
    @staticmethod
    def getRawProcessData(filePath=None):
        dict_processData = None
        str_agentDataCollFilePath = None
        try:
            if filePath:
                str_agentDataCollFilePath = filePath
            else:
                str_agentDataCollFileName = FileUtil.getUniqueFileName(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),'Temp_Raw_Data')
                str_agentDataCollFilePath = AgentConstants.AGENT_TEMP_RAW_DATA_DIR +'/'+str_agentDataCollFileName
                str_commandToExecute = '"'+AgentConstants.AGENT_SCRIPTS_DIR+'/script.sh" topCommand,psCommand'
                str_commandToExecute += ' > "'+str_agentDataCollFilePath+'"'
                isSuccess, str_output = AgentUtil.executeCommand(str_commandToExecute,AgentLogger.STDOUT, 14)
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(str_agentDataCollFilePath)
            fileObj.set_dataType('text')
            fileObj.set_mode('r')
            fileObj.set_loggerName(AgentLogger.COLLECTOR)
            fileObj.set_logging(False)
            bool_toReturn, str_collectedData = FileUtil.readData(fileObj)
            if not bool_toReturn:
                AgentLogger.log(AgentLogger.CRITICAL,'Exception while reading collected process data from the file : '+repr(str_agentDataCollFilePath) + '\n')
                return None
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], ' *************************** Exception while fetching raw process data by executing the command : '+repr(str_commandToExecute)+' *************************** '+ repr(e) + '\n')
            traceback.print_exc()
        return str_collectedData
    
    @staticmethod
    def discoverProcessForRegisterAgent():
        dict_processData = None
        try:
            if AgentConstants.OS_NAME == "AIX":
                AgentLogger.log(AgentLogger.MAIN, "arun da {}".format("aslsalsal"))
            else:
                dict_processData, list_psCommandOutput = ProcessUtil.getProcessDetails(AgentConstants.REGISTER_AGENT_DISCOVER_PROCESSES_AND_SERVICES)
                dict_processData['AGENT_REQUEST_ID'] = '1'
                dict_processData['REQUEST_TYPE'] = AgentConstants.DISCOVER_PROCESSES_AND_SERVICES
                dict_processData['DATACOLLECTTIME'] = str(AgentUtil.getTimeInMillis())
                dict_processData['ERRORMSG'] = 'NO ERROR'
                dict_processData['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        except Exception as e:
            AgentLogger.log([AgentLogger.STDOUT,AgentLogger.CRITICAL], ' *************************** Exception while discovering processes for register agent *************************** '+ repr(e) + '\n')
            traceback.print_exc()
        return dict_processData
    
    @staticmethod
    def updateProcessDetailsForAgentVersionsBelow11_0_0():
        dict_processData = None
        try:
            str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
            dict_requestParameters      =   {
            'agentKey'  :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),
            'action'  :   AgentConstants.UPDATE_PROCESS_DETAILS,
            'bno' : AgentConstants.AGENT_VERSION,
            'custID'  :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')        
            }
            dict_processData, list_psCommandOutput = ProcessUtil.getProcessDetails(AgentConstants.UPDATE_PROCESS_DETAILS)
            dict_processData['AGENT_REQUEST_ID'] = '1'
            dict_processData['REQUEST_TYPE'] = AgentConstants.UPDATE_PROCESS_DETAILS
            dict_processData['DATACOLLECTTIME'] = str(AgentUtil.getTimeInMillis())
            dict_processData['ERRORMSG'] = 'NO ERROR'
            dict_processData['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            str_jsonData = json.dumps(dict_processData)#python dictionary to json string
            AgentLogger.log(AgentLogger.COLLECTOR, 'Process details collected : '+repr(str_jsonData))
            str_url = None
            if not dict_requestParameters == None:
                str_requestParameters = urlencode(dict_requestParameters)
                str_url = str_servlet + str_requestParameters
            requestInfo = CommunicationHandler.RequestInfo()
            requestInfo.set_loggerName(AgentLogger.COLLECTOR)
            requestInfo.set_method(AgentConstants.HTTP_POST)
            requestInfo.set_url(str_url)
            requestInfo.set_data(str_jsonData)
            requestInfo.add_header("Content-Type", 'application/json')
            requestInfo.add_header("Accept", "text/plain")
            requestInfo.add_header("Connection", 'close')
            (isSuccess, int_errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.STDERR], ' *************************** Exception while discovering processes for updating agents below version 11.0.0 *************************** '+ repr(e))
            traceback.print_exc()
        return dict_processData

    @staticmethod
    def discoverAndUploadProcess(dict_task, str_loggerName = AgentLogger.STDOUT):
        bool_isSuccess = True
        str_agentDataCollFileName = None
        str_agentDataCollFilePath = None
        file_obj = None
        str_dataToSend = None
        try:
            #AgentLogger.log(str_loggerName, 'Request details : '+repr(dict_task))
            dict_processData, list_psCommandOutput = ProcessUtil.getProcessDetails(dict_task['REQUEST_TYPE'])            
            if dict_task['REQUEST_TYPE'] == AgentConstants.TEST_MONITOR:
                dict_processData['NAME'] = dict_task['REQUEST_TYPE']
                dict_processData['ACTION_TO_CALL'] = 'false'
            else:
                dict_processData['REQUEST_TYPE'] = dict_task['REQUEST_TYPE']
            dict_processData['AGENT_REQUEST_ID'] = dict_task['AGENT_REQUEST_ID']
            dict_processData['DATACOLLECTTIME'] = str(AgentUtil.getTimeInMillis())
            dict_processData['ERRORMSG'] = 'NO ERROR'
            dict_processData['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            str_jsonData = json.dumps(dict_processData)#python dictionary to json string
            AgentLogger.log(str_loggerName, 'Process details collected : '+repr(str_jsonData))
            str_url = None
            str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
            dict_requestParameters      =   {
            'action'   :   dict_task['REQUEST_TYPE'],
            'agentKey'  :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),
            'bno' : AgentConstants.AGENT_VERSION,
            'requestId'   :  str(dict_task['AGENT_REQUEST_ID'])           
            }
            if not dict_requestParameters == None:
                str_requestParameters = urlencode(dict_requestParameters)
                str_url = str_servlet + str_requestParameters
            requestInfo = CommunicationHandler.RequestInfo()
            requestInfo.set_loggerName(str_loggerName)
            requestInfo.set_method(AgentConstants.HTTP_POST)
            requestInfo.set_url(str_url)
            requestInfo.set_data(str_jsonData)
            requestInfo.add_header("Content-Type", 'application/json')
            requestInfo.add_header("Accept", "text/plain")
            requestInfo.add_header("Connection", 'close')
            bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData = CommunicationHandler.sendRequest(requestInfo)      
        except Exception as e:
            AgentLogger.log([str_loggerName,AgentLogger.CRITICAL], ' *************************** Exception while discovering processes *************************** '+ repr(e))
            traceback.print_exc()
            bool_isSuccess = False
        return bool_isSuccess
    
    @staticmethod
    def getProcessDetails(action=AgentConstants.DISCOVER_PROCESSES_AND_SERVICES, str_rawProcessData = None, str_loggerName = AgentLogger.COLLECTOR):
        dict_toReturn = None
        list_psCommandOutput = None
        try:
            if action != AgentConstants.PROCESS_AND_SERVICE_DETAILS:
                str_rawProcessData = ProcessUtil.getRawProcessData()
                if not str_rawProcessData:
                    AgentLogger.log(AgentLogger.COLLECTOR,'Unable to get raw process data for the action : '+repr(action))      
            if str_rawProcessData:
                if AgentConstants.OS_NAME == AgentConstants.FREEBSD_OS:
                    dict_toReturn, list_psCommandOutput = ProcessUtil.parseBSDRawProcessData(str_rawProcessData, action)
                elif AgentConstants.OS_NAME == AgentConstants.OS_X:
                    dict_toReturn, list_psCommandOutput = ProcessUtil.parseOSXRawProcessData(str_rawProcessData, action)
                else:
                    dict_toReturn, list_psCommandOutput = ProcessUtil.parseRawProcessData(str_rawProcessData, action)
        except Exception as e:
            AgentLogger.log([str_loggerName, AgentLogger.STDERR],' *************************** Exception while fetching process details *************************** '+ repr(e))
            traceback.print_exc()
        return dict_toReturn, list_psCommandOutput
    
    @staticmethod
    def getProcessMonitoringData(str_rawProcessData):
        dict_toReturn = None
        list_psCommandOutput = None
        try:
            dict_toReturn, list_psCommandOutput = ProcessUtil.parseProcessMonitoringData(str_rawProcessData)
        except Exception as e:
            AgentLogger.log([str_loggerName, AgentLogger.STDERR],' *************************** Exception while fetching process details *************************** '+ repr(e))
            traceback.print_exc()
        return dict_toReturn, list_psCommandOutput
    
    # psCommandList = [pid, processName, psCpu, psMem, nlwp, handleCount, path, CommandArgs]
    # psCommandListAfterMergingTopResults = [pid, processName, psCpu, psMem, nlwp, handleCount, path, CommandArgs, topCpu, topMem]
    
    @staticmethod
    def processMonitor():
        str_rawProcessData = None
        dict_toReturn = {}
        list_psCommandOutput = []
        dict_processStatus = {}
        try:
            AgentLogger.log(AgentLogger.COLLECTOR,"============================ Process Monitoring ============================")
            str_rawProcessData = ProcessUtil.getRawProcessData()
            AgentLogger.debug(AgentLogger.COLLECTOR,'String of raw processed data : '+str(str_rawProcessData))
            dict_toReturn, list_psCommandOutput = ProcessUtil.getProcessDetails(AgentConstants.PROCESS_AND_SERVICE_DETAILS,str_rawProcessData)
            AgentLogger.debug(AgentLogger.COLLECTOR,"Dictionary of process to monitor : "+str(dict_toReturn))
            ProcessUtil.updateProcessMonitorDictionary(dict_toReturn)
            dict_processStatus = ProcessUtil.processMonitorStatus(str_rawProcessData)
            AgentLogger.debug(AgentLogger.COLLECTOR,'Updated status of processes being monitored : '+str(dict_processStatus))
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL, AgentLogger.STDERR],' *************************** Exception while fetching process monitor details *************************** '+ repr(e) + '\n')
            traceback.print_exc()            
        return dict_processStatus,dict_toReturn
        
    @staticmethod
    def updateProcessMonitorDictionary(dict_processDetailsToMonitor):
        #bool_scheduleProcessMonitor = False
        try:
            #ProcessUtil.dict_totalProcessDetails = ProcessUtil.process_details_dict
            AgentLogger.log(AgentLogger.COLLECTOR,' ============================ Checking for any additions in list of processes to be monitored =========================')
            AgentLogger.log(AgentLogger.COLLECTOR,'PROCESS_LIST : '+str(PROCESS_LIST))
            if 'Process Details' in dict_processDetailsToMonitor:
                for eachProcessDetailToMonitor in dict_processDetailsToMonitor['Process Details']:
                    for  eachProcessAlreadyExisting in ProcessUtil.dict_totalProcessDetails['Process Details']:
                        #if re.sub(r' --channel=.*','',eachProcessDetailToMonitor['COMMANDLINE']) == re.sub(r' --channel=.*','',eachProcessAlreadyExisting['COMMANDLINE']):
                        if eachProcessDetailToMonitor['PROCESS_NAME'] == eachProcessAlreadyExisting['PROCESS_NAME']:
                            #eachProcessAlreadyExisting['COMMANDLINE'] = eachProcessDetailToMonitor['COMMANDLINE']  #Updating to latest parameters if there is a change
                            #AgentLogger.debug(AgentLogger.COLLECTOR,'Modified %s To %s :' %(str(eachProcessAlreadyExisting['COMMANDLINE']),str(eachProcessDetailToMonitor['COMMANDLINE'])))
                            AgentLogger.debug(AgentLogger.COLLECTOR," ==================== The process %s is already under monitor ======================" %(str(eachProcessAlreadyExisting['PROCESS_NAME'])))
                            break
                    else:
                        #if not ProcessUtil.dict_totalProcessDetails['Process Details']:
                            #bool_scheduleProcessMonitor = True
                        ProcessUtil.dict_totalProcessDetails['Process Details'].append(eachProcessDetailToMonitor)
                        AgentLogger.log(AgentLogger.COLLECTOR,"Incoming new process details to monitor: "+str(eachProcessDetailToMonitor))
            AgentLogger.debug(AgentLogger.COLLECTOR,"Updated details of processes to be monitored: "+str(ProcessUtil.dict_totalProcessDetails))
            #ProcessUtil.persistProcessDetailsList()
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' ************************** Exception while checking for any new additions in processes to be monitored **************************** \n')
            traceback.print_exc()
        #return bool_scheduleProcessMonitor
        
    @staticmethod
    def processMonitorStatus(str_rawProcessData):
        list_processDetails = None
        dict_processStatus = {}
        try:
            list_processDetails = []
            AgentLogger.log(AgentLogger.COLLECTOR,' ==================================== PROCESS MONITOR STATUS ==================================')
            AgentLogger.log(AgentLogger.COLLECTOR,"List of processes already down notified: "+str(ProcessUtil.list_downNotifiedProcess))
            AgentLogger.debug(AgentLogger.COLLECTOR,"Details of processes/process monitored : "+str(ProcessUtil.dict_totalProcessDetails['Process Details']))
            for eachProcessArgs in ProcessUtil.dict_totalProcessDetails['Process Details']:
                AgentLogger.debug(AgentLogger.COLLECTOR,"Command line argument of process %s is %s :" %(str(eachProcessArgs['PROCESS_NAME']),str(eachProcessArgs['COMMANDLINE'])))
                #list_processDetails.append(eachProcessArgs['COMMANDLINE'])
                if eachProcessArgs['PROCESS_NAME'] in str_rawProcessData:
                    AgentLogger.debug(AgentLogger.COLLECTOR,'Status of process/processes being monitored : '+str(ProcessUtil.process_status_dict))
                    if ProcessUtil.process_status_dict :
                        AgentLogger.debug(AgentLogger.COLLECTOR,'Process name : '+str(eachProcessArgs['PROCESS_NAME']))
                        if eachProcessArgs['PROCESS_NAME'] in ProcessUtil.process_status_dict.keys():
                            if ProcessUtil.process_status_dict[eachProcessArgs['PROCESS_NAME']] == 'false':
                                if eachProcessArgs['PROCESS_NAME'] not in ProcessUtil.list_downNotifiedProcess:
                                    ProcessUtil.list_downNotifiedProcess.append(eachProcessArgs['PROCESS_NAME'])
                                    #ProcessUtil.list_downNotifiedProcess.remove(eachProcessArgs['PROCESS_NAME'])
                                    AgentLogger.log(AgentLogger.COLLECTOR,"List of processes already down notified: "+str(ProcessUtil.list_downNotifiedProcess))
                    dict_processStatus[eachProcessArgs['PROCESS_NAME']] = 'true'
                else:
                    if ProcessUtil.process_status_dict:
                        if eachProcessArgs['PROCESS_NAME'] in ProcessUtil.process_status_dict.keys():
                            if ProcessUtil.process_status_dict[eachProcessArgs['PROCESS_NAME']] == 'false': 
                                if eachProcessArgs['PROCESS_NAME'] not in ProcessUtil.list_downNotifiedProcess:
                                    ProcessUtil.list_downNotifiedProcess.append(eachProcessArgs['PROCESS_NAME'])
                                AgentLogger.debug(AgentLogger.COLLECTOR,'List of processes already down notified : '+str(ProcessUtil.list_downNotifiedProcess))                                                
                    dict_processStatus[eachProcessArgs['PROCESS_NAME']] = 'false'
            ProcessUtil.persistProcessStatusList(dict_processStatus)
            ProcessUtil.persistProcessDetailsList()                   
            #dict_processStatus = ProcessUtil.checkProcessStatus(list_processDetails)
        except Exception as e:
            AgentLogger.log(AgentLogger.COLLECTOR,'************************************* Exception while extracting process details from dictionary ***********************')
            traceback.print_exc()
        return dict_processStatus
    
    @staticmethod
    def checkProcessStatus(list_procDetails):
        dict_processStatus = {}
        try:
            AgentLogger.log(AgentLogger.COLLECTOR,'============================== Checking process status ==============================')
            AgentLogger.log(AgentLogger.COLLECTOR,"List of process arguments :"+str(list_procDetails))
            for processargs in list_procDetails:
                escapedProcessargs = processargs.replace("/","\/").replace(".","\.").replace("*","\*").replace("[","\[").replace("]","\]").replace("(","\(").replace(")","\)").replace(":","\:").replace(";","\;").replace("@","\@").replace("#","\#").replace("$","\$")
                escapedProcessargs = '"{}"' .format(escapedProcessargs)
                AgentLogger.log(AgentLogger.COLLECTOR,"Command-line argument of process after escaping special characters: "+escapedProcessargs)
                command = AgentConstants.VIEW_PROCESSES_RUNNING_COMMAND+' '+escapedProcessargs
                AgentLogger.log(AgentLogger.COLLECTOR,"COMMAND: "+str(command))
                executorObj = AgentUtil.Executor()
                executorObj.setLogger(AgentLogger.COLLECTOR)
                executorObj.setTimeout(7)
                executorObj.setCommand(command)
                #executorObj.redirectToFile(True)
                executorObj.executeCommand()
                AgentLogger.log(AgentLogger.COLLECTOR,"Standard output from command-line executor: "+str(executorObj.getStdOut()))
                #AgentLogger.log(AgentLogger.COLLECTOR,"std_error: "+str(executorObj.getStdErr()))
                if executorObj.getStdOut():
                    dict_processStatus[processargs] = 'true'
                else:
                    dict_processStatus[processargs] = 'false'
            AgentLogger.debug(AgentLogger.COLLECTOR,"Process status dictionary: "+str(dict_processStatus))
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR],' *********************** Exception while checking for process status ************************')
            traceback.print_exc()
        return dict_processStatus
    
    @staticmethod
    def processCallback(tupleArgs):
        dict_processStatus = None
        dict_processTobeSentToServer = None
        toNotify = False
        boolToUpdate = True
        try:
            listSuspectedDown = []
            dict_processStatus,dict_processTobeSentToServer = tupleArgs
            AgentLogger.log(AgentLogger.COLLECTOR,"Status of process/processes monitored: "+str(dict_processStatus))
            for processArgs in dict_processStatus.keys():
                if ((dict_processStatus[processArgs] == 'false') and (processArgs in ProcessUtil.list_downNotifiedProcess)):
                    AgentLogger.log(AgentLogger.COLLECTOR,"The process %s is already notified to be down" %(processArgs))
                elif ((dict_processStatus[processArgs] == 'false') and (processArgs not in ProcessUtil.list_downNotifiedProcess)):
                    AgentLogger.log(AgentLogger.COLLECTOR,"The process %s is down and hence notifying to server" %(processArgs))
                    #ADDITIONAL CHECK STARTS HERE
                    AgentLogger.log(AgentLogger.COLLECTOR,"Will do Additional check for suspected down process: " + str(processArgs))
                    listSuspectedDown.append(str(processArgs))
                    toNotify = True
                    '''str_command = AgentConstants.PROCESS_STATUS_COMMAND + " \"" + processArgs + "\" | wc -l"
                    isSuccess, str_output = AgentUtil.executeCommand(str_command)
                    AgentLogger.log(AgentLogger.COLLECTOR," Printing output from additional check command " + str_command + " : " + str_output)
                    if isSuccess:
                        try:
                            if int(str_output) > 0:
                                AgentLogger.log(AgentLogger.COLLECTOR," Suspected down process is up. Hence skipping instant notification " )
                            else:
                                AgentLogger.log(AgentLogger.COLLECTOR," Suspected down process is confirmed. Hence uploading instant notification " )
                                toNotify = True
                                ProcessUtil.list_downNotifiedProcess.append(processArgs)
                        except Exception as e:
                            AgentLogger.log(AgentLogger.COLLECTOR," Exception in confirming down process status. Hence skipping instant notification " )'''
                    #ADDITIONAL CHECK ENDS HERE
                elif ((dict_processStatus[processArgs] == 'true') and (processArgs in ProcessUtil.list_downNotifiedProcess)):
                    AgentLogger.log(AgentLogger.COLLECTOR,"The down notified process %s just went up and hence notifying to server" %(processArgs))
                    #AgentLogger.log(AgentLogger.COLLECTOR,"Down notified process list : "+str(ProcessUtil.list_downNotifiedProcess))
                    ProcessUtil.list_downNotifiedProcess.remove(processArgs)
                    #AgentLogger.log(AgentLogger.COLLECTOR,"Down notified process list : "+str(ProcessUtil.list_downNotifiedProcess))
                    toNotify = True
                elif ((dict_processStatus[processArgs] == 'true') and (processArgs not in ProcessUtil.list_downNotifiedProcess)):
                    AgentLogger.debug(AgentLogger.COLLECTOR,"The process %s is running" %(processArgs))
            if toNotify:
                AgentLogger.debug(AgentLogger.COLLECTOR,'The dictionary of processes that are up and running : %s '%(str(dict_processTobeSentToServer)))
                dictProcessData = DataConsolidator.updateID(dict_processTobeSentToServer)
                if listSuspectedDown:
                    AgentLogger.log(AgentLogger.COLLECTOR,"Additional check for suspected down process: " + str(listSuspectedDown))
                    boolToUpdate = DataConsolidator.addDownProcCheck(listSuspectedDown)
                if boolToUpdate:
                    ProcessUtil.notfiyProcessStatus(AgentConstants.PROCESS_NOTIFY, dict_processTobeSentToServer)
            #AgentLogger.log(AgentLogger.COLLECTOR,'============================== Process Monitoring Ends ==============================')
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR],'*********************** Exception while executing process callback ****************************')
            traceback.print_exc()
            
    @staticmethod
    def deleteProcessSchedule(action=AgentConstants.PROCESS_AND_SERVICE_DETAILS):
        AgentLogger.log(AgentLogger.COLLECTOR,"Deleting schedule of action type: "+str(action))
        scheduleInfo = AgentScheduler.ScheduleInfo()
        scheduleInfo.setSchedulerName('AgentScheduler')
        scheduleInfo.setTaskName(AgentConstants.PROCESS_MONITOR)
        AgentScheduler.deleteSchedule(scheduleInfo)
        
    @staticmethod   
    def notfiyProcessStatus(action, dict_processInfo):
        bool_isSuccess = True
        AgentLogger.log(AgentLogger.CRITICAL, '================================= NOTIFYING PROCESS STATUS CHANGE =================================')
        AgentLogger.log(AgentLogger.CRITICAL,str(dict_processInfo)+' : '+str(action))
        try:
            str_url = None
            str_servlet = AgentConstants.PROCESS_MONITOR_SERVLET
            dict_requestParameters = {
                                        'action'    :   action,
                                        'agentKey'  :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),
                                        'custID'    :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id'),
                                        'dc'        :   str(AgentUtil.getTimeInMillis()),
                                        'bno' : AgentConstants.AGENT_VERSION
                                     }
            if not dict_requestParameters == None:
                str_requestParameters = urlencode(dict_requestParameters)
                str_url = str_servlet + str_requestParameters
            requestInfo = CommunicationHandler.RequestInfo()
            requestInfo.set_loggerName(AgentLogger.COLLECTOR)
            requestInfo.set_method(AgentConstants.HTTP_POST)
            requestInfo.set_url(str_url)
            requestInfo.set_timeout(30)
            str_jsonData = json.dumps(dict_processInfo)#python dictionary to json string
            AgentLogger.log(AgentLogger.COLLECTOR,'Json data to be sent : '+str(str_jsonData))
            requestInfo.set_data(str_jsonData)            
            requestInfo.add_header("Content-Type", 'application/json')
            requestInfo.add_header("Accept", "text/plain")
            requestInfo.add_header("Connection", 'close')
            bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData = CommunicationHandler.sendRequest(requestInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], ' *************************** Exception while notifying process status *************************** '+ repr(e) + '\n')
            traceback.print_exc()
            bool_isSuccess = False
        return bool_isSuccess
    
    @staticmethod    
    def persistProcessStatusList(dict_processStatus):
        if not PROCESS_LIST == None:
            ProcessUtil.process_status_dict = dict_processStatus  
            AgentLogger.debug(AgentLogger.COLLECTOR,'================================= PERSISTING PROCESS STATUS LIST =================================')
            AgentLogger.debug(AgentLogger.COLLECTOR,"Modified process status dictionary being persisted to file : "+str(ProcessUtil.process_status_dict))      
            if not AgentUtil.writeDataToFile(AgentConstants.AGENT_PROCESS_STATUS_LIST_FILE, dict_processStatus):
                AgentLogger.log(AgentLogger.COLLECTOR,'************************* Problem while persisting process status list *************************') 
        else:
            AgentLogger.log(AgentLogger.COLLECTOR,'************************* Process status list to be persisted is empty **************************')
    
    @staticmethod    
    def persistProcessDetailsList():
        if not PROCESS_LIST == None:  
            AgentLogger.debug(AgentLogger.COLLECTOR,'================================= PERSISTING PROCESS DETAILS LIST =================================')
            AgentLogger.debug(AgentLogger.COLLECTOR,str(ProcessUtil.dict_totalProcessDetails))      
            if not AgentUtil.writeDataToFile(AgentConstants.AGENT_PROCESS_DETAILS_LIST_FILE, ProcessUtil.dict_totalProcessDetails):
                AgentLogger.log(AgentLogger.COLLECTOR,'************************* Problem while persisting process details list *************************') 
        else:
            AgentLogger.log(AgentLogger.COLLECTOR,'************************* Process details list to be persisted is empty **************************')
    
    @staticmethod
    def loadProcessStatusList():
        AgentLogger.log(AgentLogger.COLLECTOR,'Loading process status list')
        if os.path.exists(AgentConstants.AGENT_PROCESS_STATUS_LIST_FILE):
            (bool_status, ProcessUtil.process_status_dict) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PROCESS_STATUS_LIST_FILE)
            if bool_status:        
                AgentLogger.log(AgentLogger.COLLECTOR,'Process status list Loaded From '+AgentConstants.AGENT_PROCESS_STATUS_LIST_FILE+' : '+str(ProcessUtil.process_status_dict))
            else:
                AgentLogger.log(AgentLogger.COLLECTOR,'*********************** Problem while loading process list ************************')
         
    @staticmethod
    def loadProcessDetailsList():
        AgentLogger.log(AgentLogger.COLLECTOR,'Loading process details list')
        if os.path.exists(AgentConstants.AGENT_PROCESS_DETAILS_LIST_FILE):
            (bool_status, ProcessUtil.dict_totalProcessDetails) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PROCESS_DETAILS_LIST_FILE)
            if bool_status:        
                AgentLogger.log(AgentLogger.COLLECTOR,'Process details list Loaded From '+AgentConstants.AGENT_PROCESS_DETAILS_LIST_FILE+' : '+str(ProcessUtil.dict_totalProcessDetails))
            else:
                AgentLogger.log(AgentLogger.COLLECTOR,'*********************** Problem while loading process list ************************')
    
    @staticmethod
    def parseOSXRawProcessData(str_rawProcessData, action = AgentConstants.DISCOVER_PROCESSES_AND_SERVICES):
        dict_toReturn = None
        try:
            int_topFirstSampleIndex = str_rawProcessData.find('Processes: ') + len('Processes: ')
            int_topSecondSampleIndex = str_rawProcessData.find('Processes: ', int_topFirstSampleIndex)
            
            int_topCommandIndex = str_rawProcessData.find('PID    %CPU', int_topSecondSampleIndex)
            int_psCommandIndex = str_rawProcessData.find('PID COMMAND', int_topSecondSampleIndex)
            
            str_topCommandOutput = str_rawProcessData[int_topCommandIndex:int_psCommandIndex]
            str_psCommandOutput = str_rawProcessData[int_psCommandIndex:]
            
            #tuple_topCommand = (pid, cpu, mem, time, command)
            #tuple_psCommand = (PID, PName, CPU, MEM, NLWP, HC, exe, args)
            
            dict_topCommandOutput = {}
            for topCommandline in str_topCommandOutput.split('\n'):
                tuple_topCommandLine = tuple(topCommandline.split())
                if tuple_topCommandLine:
                    dict_topCommandOutput[tuple_topCommandLine[0]] = tuple_topCommandLine
            
            list_psCommandOutput = []
            for psCommandline in str_psCommandOutput.split('\n'):
                list_psCommandLine = list(psCommandline.split(' :: '))
                if len(list_psCommandLine) < 8:
                    continue
                list_psCommandOutput.append(list_psCommandLine)
            
            if list_psCommandOutput:
                list_psCommandOutput.pop(0)
            
            list_site24x7ScriptProcessToBeDeleted = []
            for int_index, list_psCommandLine in enumerate(list_psCommandOutput):
                str_commandArgs = list_psCommandLine[7]
                if list_psCommandLine[0] in dict_topCommandOutput:
                    if str_commandArgs.find('/Contents/Resources/scripts/script.sh') > 0:
                        list_site24x7ScriptProcessToBeDeleted.append(int_index)
                        continue
                    tuple_topCommand = dict_topCommandOutput[list_psCommandLine[0]]
                    psCommandOldProcessArg = list_psCommandLine[7]
                    list_psCommandLine[1] = ' '.join(tuple_topCommand[4:])
                    list_psCommandLine.append(tuple_topCommand[1])
                    list_psCommandLine.append(list_psCommandLine[3])
                    list_psCommandLine.append(psCommandOldProcessArg)
                else:
                    AgentLogger.log(AgentLogger.COLLECTOR,'Deleting the following process missing in top command : '+repr(list_psCommandLine))
                    list_site24x7ScriptProcessToBeDeleted.append(int_index)
            
            for index, item in enumerate(list_site24x7ScriptProcessToBeDeleted):
                popItem = list_psCommandOutput.pop(item-index)
            
            dict_toReturn = ProcessUtil.convertProcessListToDictionary(list_psCommandOutput, action)
            
            dict_processIdVsProcessDetails = {}
            dict_tempRCADataToSave = {}
            for list_process in list_psCommandOutput:
                dict_processIdVsProcessDetails[list_process[0]] = list_process
            dict_tempRCADataToSave['Process Details'] = dict_processIdVsProcessDetails
            
            rcaInfo = RcaInfo()
            rcaInfo.action = AgentConstants.SAVE_RCA_RAW
            rcaInfo.data = dict_tempRCADataToSave
            RcaUtil.saveRca(rcaInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR],' *************************** Exception while parsing OSX raw process data : '+str(str_rawProcessData)+' *************************** '+ repr(e))
            traceback.print_exc()
        return dict_toReturn, list_psCommandOutput
    
    @staticmethod
    def parseBSDRawProcessData(str_rawProcessData, action = AgentConstants.DISCOVER_PROCESSES_AND_SERVICES):
        dict_toReturn = None
        try:
            #AgentLogger.debug(AgentLogger.COLLECTOR,'FreeBSD raw top,ps command data : '  + str_rawProcessData)
            int_topFirstSampleIndex = str_rawProcessData.find('last pid:') + len('last pid:')
            int_topSecondSampleIndex = str_rawProcessData.find('last pid:', int_topFirstSampleIndex)
            int_topCommandIndex = str_rawProcessData.find('PID USER', int_topSecondSampleIndex)
            int_psCommandIndex = str_rawProcessData.find('PID COMMAND')
            str_psCommandOutput = str_rawProcessData[int_psCommandIndex:]
            str_topCommandOutput = str_rawProcessData[int_topCommandIndex:int_psCommandIndex]
            dict_topCommandOutput = {}
            list_psCommandOutput = []
            list_site24x7ScriptProcessToBeDeleted = []
            for topCommandline in str_topCommandOutput.split('\n'):
                tuple_topCommandLine = tuple(topCommandline.split())
                if tuple_topCommandLine:
                    dict_topCommandOutput[tuple_topCommandLine[0]] = tuple_topCommandLine
            if dict_topCommandOutput:
                AgentLogger.debug(AgentLogger.COLLECTOR,'FreeBSD top command output dict : ' + repr(dict_topCommandOutput))
            for psCommandline in str_psCommandOutput.split('\n'):
                list_psCommandLine = list(psCommandline.split(' :: '))
                if len(list_psCommandLine) < 9:
                    continue
                list_psCommandOutput.append(list_psCommandLine)
            #if list_psCommandOutput:
                #list_psCommandOutput.pop(0)
            AgentLogger.debug(AgentLogger.COLLECTOR,'FreeBSD PS command output list : '+repr(len(list_psCommandOutput))+'  '+repr(list_psCommandOutput))
            for int_index, list_psCommandLine in enumerate(list_psCommandOutput):
                #AgentLogger.log(AgentLogger.COLLECTOR,'PS command line list : '+repr(list_psCommandLine))
                str_commandArgs = list_psCommandLine[7]
                #AgentLogger.debug(AgentLogger.COLLECTOR,repr(int_index)+'   str_commandArgs : '+repr(len(list_psCommandLine))+'  '+repr(str_commandArgs))
                if list_psCommandLine[0] in dict_topCommandOutput:
                    if str_commandArgs.find('/opt/site24x7/monagent/scripts/script.sh') > 0:
                        #AgentLogger.debug(AgentLogger.COLLECTOR,'str_commandArgssssssssssssssssss : '+repr(list_psCommandLine[0])+repr(int_index)+'   '+'    '+repr(str_commandArgs)+repr(str_commandArgs.find('/opt/site24x7/monagent/scripts/script.sh')))
                        list_site24x7ScriptProcessToBeDeleted.append(int_index)
                        continue
                    tuple_topCommand = dict_topCommandOutput[list_psCommandLine[0]]
                    #AgentLogger.debug(AgentLogger.COLLECTOR,'PS command output list : \n'+repr(list_psCommandLine)+'\n'+repr(tuple_topCommand))
                    psCommandOldProcessArg = list_psCommandLine[8]
                    list_psCommandLine[8] = list_psCommandLine[2]
                    str_topMem = "0"
                    list_psCommandLine.append(str_topMem) #appending top cpu
                    list_psCommandLine.append(psCommandOldProcessArg) #appending top memory
                else:
                    AgentLogger.log(AgentLogger.COLLECTOR,'Deleting the following process missing in top command : '+repr(list_psCommandLine))
                    list_site24x7ScriptProcessToBeDeleted.append(int_index)
                    #AgentLogger.debug(AgentLogger.COLLECTOR,'PS command output list : \n'+repr(list_psCommandLine)+'\n'+repr(tuple_topCommand))
            #AgentLogger.debug(AgentLogger.COLLECTOR,'list_site24x7ScriptProcessToBeDeleted : '+repr(list_site24x7ScriptProcessToBeDeleted))
            #AgentLogger.debug(AgentLogger.COLLECTOR,'list_site24x7ScriptProcessToBeDeleted : '+repr(len(list_psCommandOutput)))
            for index, item in enumerate(list_site24x7ScriptProcessToBeDeleted):
                popItem = list_psCommandOutput.pop(item-index)
                #AgentLogger.debug(AgentLogger.COLLECTOR,'list_site24x7ScriptProcessToBeDeleted : '+repr(popItem))
            #AgentLogger.debug(AgentLogger.COLLECTOR,'list_site24x7ScriptProcessToBeDeleted : '+repr(len(list_psCommandOutput)))
            #AgentLogger.debug(AgentLogger.COLLECTOR,'Top command output dictionary : \n'+repr(dict_topCommandOutput))
            AgentLogger.debug(AgentLogger.COLLECTOR,'Final FreeBSD PS command output list : \n'+repr(len(list_psCommandOutput))+ ' :: ' + repr(list_psCommandOutput))
            dict_toReturn = ProcessUtil.convertProcessListToDictionary(list_psCommandOutput, action)
            # Save temp data for RCA
            dict_processIdVsProcessDetails = {}
            dict_tempRCADataToSave = {}
            for list_process in list_psCommandOutput:
                dict_processIdVsProcessDetails[list_process[0]] = list_process
            dict_tempRCADataToSave['Process Details'] = dict_processIdVsProcessDetails
            rcaInfo = RcaInfo()
            rcaInfo.action = AgentConstants.SAVE_RCA_RAW
            rcaInfo.data = dict_tempRCADataToSave
            RcaUtil.saveRca(rcaInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' *************************** Exception while parsing raw process data : '+str(str_rawProcessData)+' *************************** '+ repr(e))
            traceback.print_exc()
        return dict_toReturn, list_psCommandOutput
        pass    
    
    @staticmethod
    def parseRawProcessData(str_rawProcessData, action = AgentConstants.DISCOVER_PROCESSES_AND_SERVICES):
        dict_toReturn = None
        try:
            int_topFirstSampleIndex = str_rawProcessData.find('top -') + len('top -')
            int_topSecondSampleIndex = str_rawProcessData.find('top -', int_topFirstSampleIndex)
            int_topCommandIndex = str_rawProcessData.find('PID USER', int_topSecondSampleIndex)
            int_psCommandIndex = str_rawProcessData.find('PID COMMAND', int_topSecondSampleIndex)
            str_cpuMetricsInTopOutput = str_rawProcessData[int_topSecondSampleIndex:int_topCommandIndex]
            str_topCommandOutput = str_rawProcessData[int_topCommandIndex:int_psCommandIndex]
            str_psCommandOutput = str_rawProcessData[int_psCommandIndex:]
            dict_topCommandOutput = {}
            list_psCommandOutput = []
            list_site24x7ScriptProcessToBeDeleted = []
            for topCommandline in str_topCommandOutput.split('\n'):
                tuple_topCommandLine = tuple(topCommandline.split())
                if tuple_topCommandLine:
                    dict_topCommandOutput[tuple_topCommandLine[0]] = tuple_topCommandLine
            for psCommandline in str_psCommandOutput.split('\n'):
                list_psCommandLine = list(psCommandline.split(' :: '))
                #AgentLogger.log(AgentLogger.COLLECTOR,' ps list command :: {0}'.format(list_psCommandLine))
                if len(list_psCommandLine) < 11:
                    continue
                list_psCommandOutput.append(list_psCommandLine)
            if list_psCommandOutput:
                list_psCommandOutput.pop(0)
            #AgentLogger.debug(AgentLogger.COLLECTOR,'PS command output list : '+repr(len(list_psCommandOutput))+'  '+repr(list_psCommandOutput))
            
            #['31713', 'root', '19', 'kworker/', '0.0', '0.0', '1', '0', '[kworker/1:2]', '[kworker/1:2]', '[kworker/1:2]']
            
            for int_index, list_psCommandLine in enumerate(list_psCommandOutput):
                #AgentLogger.log(AgentLogger.COLLECTOR,'PS command line list : '+repr(list_psCommandLine))
                str_commandArgs = list_psCommandLine[9]
                #AgentLogger.debug(AgentLogger.COLLECTOR,repr(int_index)+'   str_commandArgs : '+repr(len(list_psCommandLine))+'  '+repr(str_commandArgs))
                if list_psCommandLine[0] in dict_topCommandOutput:
                    if str_commandArgs.find('/opt/site24x7/monagent/scripts/script.sh') > 0:
                        #AgentLogger.debug(AgentLogger.COLLECTOR,'str_commandArgssssssssssssssssss : '+repr(list_psCommandLine[0])+repr(int_index)+'   '+'    '+repr(str_commandArgs)+repr(str_commandArgs.find('/opt/site24x7/monagent/scripts/script.sh')))
                        list_site24x7ScriptProcessToBeDeleted.append(int_index)
                        continue
                    tuple_topCommand = dict_topCommandOutput[list_psCommandLine[0]]
                    #AgentLogger.debug(AgentLogger.COLLECTOR,'PS command output list : \n'+repr(list_psCommandLine)+'\n'+repr(tuple_topCommand))
                    psCommandOldProcessArg = list_psCommandLine[10]
                    #AgentLogger.log(AgentLogger.COLLECTOR,' ps command :: {0}'.format(list_psCommandLine))
                    #AgentLogger.log(AgentLogger.COLLECTOR,' top tuple :: {0}'.format(tuple_topCommand))
                    list_psCommandLine[10] = tuple_topCommand[8]
                    list_psCommandLine.append(tuple_topCommand[9]) #appending top cpu
                    list_psCommandLine.append(psCommandOldProcessArg) #appending top memory
                else:
                    AgentLogger.log(AgentLogger.COLLECTOR,'Deleting the following process missing in top command : '+repr(list_psCommandLine))
                    list_site24x7ScriptProcessToBeDeleted.append(int_index)
                    #AgentLogger.debug(AgentLogger.COLLECTOR,'PS command output list : \n'+repr(list_psCommandLine)+'\n'+repr(tuple_topCommand))
            for index, item in enumerate(list_site24x7ScriptProcessToBeDeleted):
                popItem = list_psCommandOutput.pop(item-index)
            dict_toReturn = ProcessUtil.convertProcessListToDictionary(list_psCommandOutput, action)
            # Save temp data for RCA
            dict_processIdVsProcessDetails = {}
            dict_tempRCADataToSave = {}
            for list_process in list_psCommandOutput:
                dict_processIdVsProcessDetails[list_process[0]] = list_process
            dict_tempRCADataToSave['Process Details'] = dict_processIdVsProcessDetails
            rcaInfo = RcaInfo()
            rcaInfo.action = AgentConstants.SAVE_RCA_RAW
            rcaInfo.data = dict_tempRCADataToSave
            RcaUtil.saveRca(rcaInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' *************************** Exception while parsing raw process data : '+str(str_rawProcessData)+' *************************** '+ repr(e) + '\n')
            traceback.print_exc()
        return dict_toReturn, list_psCommandOutput
    
    @staticmethod
    def parseProcessMonitoringData(str_rawProcessData):
        dict_toReturn = {}
        try:
            list_psCommandOutput = []
            list_psCommandLine=[]
            for psCommandline in str_rawProcessData.split('\n'):
                #AgentLogger.log(AgentLogger.COLLECTOR,' ps command line output --- {0}'.format(list_psCommandLine))
                if psCommandline.strip()=='' or psCommandline.startswith('PID'):
                    continue
                else:
                    list_psCommandLine = list(psCommandline.split(' :: '))
                    if len(list_psCommandLine) < 10:
                        continue
                    list_psCommandOutput.append(list_psCommandLine)
            
            finaleProcessList = []
            #AgentLogger.log(AgentLogger.COLLECTOR,' ps command output --- {0}'.format(list_psCommandLine))
            for int_index, ps_list in enumerate(list_psCommandOutput):
                #AgentLogger.log(AgentLogger.COLLECTOR,' list and ps == {0}{1}'.format(int_index,ps_list))
                processDict = {}
                #['1137', 'nagios', '0.0', '0.0', '1', '5', '/usr/local/nagios/bin/nagio', '/usr/local/nagios/bin/nagios --worker /usr/local/nagios/var/rw/nagios.qh', '/usr/local/nagios/bin/nagios']
                #['457', '19', 'apache2', '0.0', '0.0', '1', '10', '/usr/sbin/apache2', '/usr/sbin/apache2 -k start', '-k']
                # 1010 root      19 sshd      0.0  0.0    1 /usr/sbin/sshd -D           /usr/sbin/sshd -D
                processDict['pid']=ps_list[0]
                processDict['user']=ps_list[1]
                processDict['priority']=ps_list[2]
                processDict['pname']=ps_list[3]
                if not AgentConstants.NO_OF_CPU_CORES  == None or not AgentConstants.NO_OF_CPU_CORES  == '':
                    processDict['pcpu']= (float(ps_list[4]) / AgentConstants.NO_OF_CPU_CORES)
                else:
                    processDict['pcpu']=ps_list[4]
                processDict['pmem']=ps_list[5]
                processDict['pthread']=ps_list[6]
                processDict['phandle']=ps_list[7]
                processDict['path']=ps_list[8]
                processDict['pargs']=ps_list[9]
                processDict['AVAILABILITY']=1
                if processDict['pargs'].find('/opt/site24x7/monagent/scripts/script.sh') > 0:
                    continue
                finaleProcessList.append(processDict)
            
            dict_toReturn['Process Details'] = finaleProcessList
            #AgentLogger.log(AgentLogger.COLLECTOR,' process dict -- {0}'.format(json.dumps(dict_toReturn)))
#                 if list_psCommandLine[0] in dict_topCommandOutput:
#                     psCommandOldProcessArg = list_psCommandLine[8]
#                     list_psCommandLine[8] = tuple_topCommand[8]
#                     list_psCommandLine.append(tuple_topCommand[9]) #appending top cpu
#                     list_psCommandLine.append(psCommandOldProcessArg) #appending top memory
#                 else:
#                     AgentLogger.log(AgentLogger.COLLECTOR,'Deleting the following process missing in top command : '+repr(list_psCommandLine))
#                     list_site24x7ScriptProcessToBeDeleted.append(int_index)
#             for index, item in enumerate(list_site24x7ScriptProcessToBeDeleted):
#                 popItem = list_psCommandOutput.pop(item-index)
#                
#             dict_toReturn = ProcessUtil.convertProcessListToDictionary(list_psCommandOutput, action)
#             # Save temp data for RCA
#             dict_processIdVsProcessDetails = {}
#             dict_tempRCADataToSave = {}
#             for list_process in list_psCommandOutput:
#                 dict_processIdVsProcessDetails[list_process[0]] = list_process
#             dict_tempRCADataToSave['Process Details'] = dict_processIdVsProcessDetails
#             rcaInfo = RcaInfo()
#             rcaInfo.action = AgentConstants.SAVE_RCA_RAW
#             rcaInfo.data = dict_tempRCADataToSave
#             RcaUtil.saveRca(rcaInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' *************************** Exception while parsing raw process data : '+str(str_rawProcessData)+' *************************** '+ repr(e) + '\n')
            traceback.print_exc()
        return dict_toReturn, list_psCommandOutput
    
    @staticmethod
    def convertProcessListToDictionary(list_psCommandOutput, action):
        dict_toReturn = {}
        list_processDetails = []
        list_processNamesToBeFiltered = []
        dict_processNamesToBeFiltered = {}
        try:
            if action == AgentConstants.PROCESS_AND_SERVICE_DETAILS or action == AgentConstants.UPDATE_PROCESS_DETAILS:
                #dict_processMonDetails = COLLECTOR.getMonitors()[AgentConstants.PROCESS_AND_SERVICE_DETAILS]['Attributes']
                # 'searchValues' value will be present when at least one process is monitored in the server.
                # Below check just prevents huge process data from being sent to the server when no process is being monitored.
                list_processNamesToBeFiltered = getProcessNameList()
                '''for each_proc in list_processNamesToBeFiltered:
                    dict_processNamesToBeFiltered[each_proc] = False
                    AgentLogger.debug(AgentLogger.COLLECTOR,' Set all Process List as False ')'''
            AgentLogger.log(AgentLogger.COLLECTOR,'Action : '+repr(action)+', List of process names to be filtered : '+repr(list_processNamesToBeFiltered))
            AgentLogger.debug(AgentLogger.COLLECTOR,'Process list collected : '+repr(list_psCommandOutput))
            for list_process in list_psCommandOutput:
                dict_processMap = {}
                AgentLogger.debug(AgentLogger.COLLECTOR,'Process list : '+repr(list_process))
                if (action == AgentConstants.PROCESS_AND_SERVICE_DETAILS or action == AgentConstants.UPDATE_PROCESS_DETAILS) and list_process[1] not in list_processNamesToBeFiltered:
                    AgentLogger.debug(AgentLogger.COLLECTOR,'Process name : '+repr(list_process[1]))
                    AgentLogger.debug(AgentLogger.COLLECTOR,'continue : '+repr(list_process[1] not in list_processNamesToBeFiltered))
                    continue
                
                #['32345', 'root', '19', 'kworker/', '0.0', '0.0', '1', '0', '[kworker/2:1]', '[kworker/2:1]', '0.0', '0.0', '[kworker/2:1]'] 
                #AgentLogger.log(AgentLogger.COLLECTOR,'### Process List : '+repr(list_process))
                if action == AgentConstants.UPDATE_PROCESS_DETAILS:
                    dict_processMap['PROCESS_ID'] = list_process[0]
                    dict_processMap['Name'] = list_process[3]
                    dict_processMap['PathName'] = list_process[8]
                    dict_processMap['Arguments'] = list_process[9]
                    dict_processMap['OldPath'] = list_process[6]
                    dict_processMap['OldArguments'] = list_process[10]
                elif action == AgentConstants.REGISTER_AGENT_DISCOVER_PROCESSES_AND_SERVICES:
                    dict_processMap['PROCESS_ID'] = list_process[0]
                    dict_processMap['Name'] = list_process[3]
                    dict_processMap['PathName'] = list_process[8]
                    dict_processMap['Arguments'] = list_process[9]
                elif action == AgentConstants.TEST_MONITOR:
                    dict_processMap['ProcessId'] = list_process[0]
                    dict_processMap['Name'] = list_process[3]
                    dict_processMap['User'] = list_process[1]
                    dict_processMap['ExecutablePath'] = list_process[8]
                    dict_processMap['CommandLine'] = list_process[9]
                else:
                    dict_processMap['PROCESS_ID'] = list_process[0]
                    dict_processMap['PROCESS_NAME'] = list_process[3]
                    dict_processMap['EXEUTABLE_PATH'] = list_process[8]
                    dict_processMap['COMMANDLINE'] = list_process[9]
                if action == AgentConstants.PROCESS_AND_SERVICE_DETAILS:
                    dict_processMap['CPU_UTILIZATION'] = list_process[10]
                    if AgentConstants.OS_NAME == AgentConstants.FREEBSD_OS:
                        dict_processMap['MEMORY_UTILIZATION'] = list_process[3]
                    else:
                        dict_processMap['MEMORY_UTILIZATION'] = list_process[11]
                    dict_processMap['THREAD_COUNT'] = list_process[6]
                    dict_processMap['HANDLE_COUNT'] = list_process[7]
                    dict_processMap['PS_CPU_UTILIZATION'] = list_process[4]
                    dict_processMap['PS_MEMORY_UTILIZATION'] = list_process[5]
                    dict_processMap['AVAILABILITY'] = 1
                    '''dict_processNamesToBeFiltered[list_process[1]] = True
                    AgentLogger.debug(AgentLogger.COLLECTOR,' Set dict as true for process : ' + str(list_process[1]))'''
                elif action == AgentConstants.TEST_MONITOR:
                    dict_processMap['CPU_UTILIZATION'] = list_process[4]
                    dict_processMap['MEMORY_UTILIZATION'] = list_process[5]
                    dict_processMap['ThreadCount'] = list_process[6]
                    dict_processMap['HandleCount'] = list_process[7]
                list_processDetails.append(dict_processMap)
            if action == AgentConstants.TEST_MONITOR:
                dict_toReturn['PROCESS_LOG_DATA'] = list_processDetails
            else:
                dict_toReturn['Process Details'] = list_processDetails
            #AgentLogger.log(AgentLogger.COLLECTOR,'List of process details : '+repr(list_processDetails))
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' *************************** Exception while converting process list to dictionary for action : '+repr(action)+' \n'+repr(list_psCommandOutput)+' *************************** '+ repr(e) + '\n')
            traceback.print_exc()
        return dict_toReturn
            
    def sortProcessListAndConvertToDict(list_processDetails, sortKey='cpu', noOfSamples=5):
        list_sortedProcessMetrics = []
        try:
            #AgentLogger.log(AgentLogger.COLLECTOR,' list process -- {0}'.format(list_processDetails))
            if sortKey == 'cpu':
                list_sortedProcessDetails = sorted(list_processDetails, key=itemgetter(8,2), reverse=True)[:noOfSamples]
            elif sortKey == 'mem':
                list_sortedProcessDetails = sorted(list_processDetails, key=itemgetter(9,3), reverse=True)[:noOfSamples]
            for list_processDet in list_sortedProcessDetails:
                #AgentLogger.log(AgentLogger.COLLECTOR,' sorted process -- {0}'.format(list_processDet))
               # ['2214', 'sriram-+', '19', 'upstart-', '0.0', '0.0', '1', '10', 'upstart-file-bridge', 'upstart-file-bridge --daemon --user', '0.0', '0.0', '--daemo']
                dict_processDetail = OrderedDict()
                dict_processDetail['Process Id'] = list_processDet[0]
                dict_processDetail['Process Name'] = list_processDet[3]
                dict_processDetail['CPU Usage(%)'] = list_processDet[4]
                dict_processDetail['Avg. CPU Usage(%)'] = list_processDet[10]
                dict_processDetail['Memory Usage(MB)'] = list_processDet[5]
                dict_processDetail['Avg. Memory Usage(MB)'] = list_processDet[11]
                dict_processDetail['Thread Count'] = list_processDet[6]
                dict_processDetail['Handle Count'] = list_processDet[7]
                dict_processDetail['Path'] = list_processDet[8]
                dict_processDetail['Command Line Arguments'] = list_processDet[9]
                list_sortedProcessMetrics.append(dict_processDetail)
        except Exception as e:
            AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' *************************** Exception while sorting process metrics for RCA : '+repr(list_processDetails)+' *************************** '+ repr(e))
            traceback.print_exc()
        return list_sortedProcessMetrics

class MonitorInfo:
    def __init__(self):
        self.__str_name = None
        self.__dict_monitorInfo = None
        self.__logger = AgentLogger.STDOUT
        self.__func_monitorImpl = self.setMonitorImpl()
    def __str__(self):
        str_monitorInfo = ''
        str_monitorInfo += 'MONITOR NAME : '+repr(self.__str_name)
        str_monitorInfo += ' MONITOR LOGGER : '+repr(self.__logger)
        str_monitorInfo += ' MONITOR IMPL : '+repr(self.__func_monitorImpl)
        str_monitorInfo += ' MONITOR INFO : '+repr(self.__dict_monitorInfo)
        return str_monitorInfo
    def setName(self, str_monitorName):
        self.__str_name = str_monitorName
    def getName(self):
        return self.__str_name
    def setProps(self, dict_props):
        self.__dict_monitorInfo = dict_props
    def getProps(self):
        return self.__dict_monitorInfo
    def setMonitorImpl(self, func_monitorImpl = None):
        if func_monitorImpl:
            self.__monitorImpl = func_monitorImpl
        else:
            pass
    def getMonitorImpl(self):
        return self.__func_monitorImpl
        
class Activator:
    def __init__(self):
        self.state = False
        self.name = 'Activatormodule'
    
    def getActivatorState(self):
        return self.state
    
    def setActivatorState(self,boolState):
        self.state = boolState
    
    def scheduleActivator(self):
        try:
            if self.state == False:
                AgentLogger.log(AgentLogger.COLLECTOR,'================================= SCHEDULING FOR ACTIVATION LISTENER =================================')
                scheduleInfo = AgentScheduler.ScheduleInfo()
                scheduleInfo.setSchedulerName('AgentScheduler')
                scheduleInfo.setTaskName('ListenAct')
                scheduleInfo.setTime(time.time())
                task = self.listenActivation
                scheduleInfo.setTask(task)
                scheduleInfo.setIsPeriodic(True)
                scheduleInfo.setInterval(180)
                scheduleInfo.setLogger(AgentLogger.COLLECTOR)
                AgentScheduler.schedule(scheduleInfo)
                self.setActivatorState(True)
            else:
                AgentLogger.log(AgentLogger.COLLECTOR,'******************************** Activator Listener already scheduled *********************************')
        except Exception as e:
            AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' *************************** Exception while scheduling activator for stop_monitoring *************************** '+ repr(e))
            traceback.print_exc()

    def listenActivation(self):
        dictRequestParameters = {}
        str_servlet = AgentConstants.AGENT_LISTEN_ACTIVATION_SERVLET
        try:
            AgentLogger.log(AgentLogger.COLLECTOR,'================ Contacting Activation servlet =================' )
            dictRequestParameters['bno'] = AgentConstants.AGENT_VERSION
            dictRequestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dictRequestParameters['agentKey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            str_url = None
            if not dictRequestParameters == None:
                str_requestParameters = urlencode(dictRequestParameters)
                str_url = str_servlet + str_requestParameters
            requestInfo = CommunicationHandler.RequestInfo()
            requestInfo.set_loggerName(AgentLogger.STDOUT)
            requestInfo.set_method(AgentConstants.HTTP_POST)
            requestInfo.set_url(str_url)
            requestInfo.set_timeout(10)
            bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData = CommunicationHandler.sendRequest(requestInfo)
            if bool_toReturn:
                CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'ACTIVATOR LISTENER MODULE')
            elif int_errorCode == 404:
                AgentLogger.log([AgentLogger.COLLECTOR],' ACTIVATOR LISTENER SERVLET Servlet not found ' ) 
            else:
                AgentLogger.log([AgentLogger.COLLECTOR],' Failed to receive response from ACTIVATOR LISTENER SERVLET ' )
        except Exception as e:
            AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' *************************** Exception while listening for activation response from server *************************** '+ repr(e))
            traceback.print_exc()
    
    def stopActivator(self):
        try:
            if self.state == True:
                AgentLogger.log([AgentLogger.COLLECTOR],'================================= STOPPING SCHEDULE FOR ACTIVATION LISTENER =================================')
                scheduleInfo = AgentScheduler.ScheduleInfo()
                scheduleInfo.setSchedulerName('AgentScheduler')
                scheduleInfo.setTaskName('ListenAct')
                AgentScheduler.deleteSchedule(scheduleInfo)
                self.setActivatorState(False)
            else:
                AgentLogger.log([AgentLogger.COLLECTOR],'******************************** Activator Listener already stopped *********************************')
        except Exception as e:
            AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' *************************** Exception while stopping activator in start_monitoring *************************** '+ repr(e))
            traceback.print_exc()

class Collector:
    def __init__(self, name = 'Collector'):
        self.__name = name
        self.__bool_dataCollectionStopped = False
        self.__dict_monitors = None
        self.__dict_customMonitors = None
        self.__dict_monitorsgroup = None
        self.__dict_customMonitorsGroup = None
        self.__scheduler = None
        self.__colDataBuffer = {}
        self.__dict_scheduleInfo = {} 
        self.loadMonitors()
    
    def loadMonitors(self):
        AgentLogger.log(AgentLogger.COLLECTOR,'======================================= INITIALIZING COLLECTOR =======================================')        
        dict_monitorsInfo = AgentUtil.loadMonitorsXml(AgentConstants.AGENT_MONITORS_FILE)
        dict_customMonitorsInfo = AgentUtil.loadMonitorsXml(AgentConstants.AGENT_CUSTOM_MONITORS_FILE)
        (bool_isSuccess, dict_monitorsGroup) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_MONITORS_GROUP_FILE)
        (bool_isSuccess2, dict_customMonitorsGroup) = AgentUtil.loadDataFromFile(AgentConstants.AGENT_CUSTOM_MONITORS_GROUP_FILE)
        if bool_isSuccess:
            self.__dict_monitorsgroup = collections.OrderedDict(dict_monitorsGroup)
            AgentLogger.log(AgentLogger.COLLECTOR,'Monitor group Loaded From '+AgentConstants.AGENT_MONITORS_GROUP_FILE+' : '+json.dumps(dict_monitorsGroup))
        else:
            AgentLogger.log(AgentLogger.CRITICAL,' ********************** Failed to load the monitor group conf file : '+AgentConstants.AGENT_MONITORS_GROUP_FILE+' ********************** \n')
            raise Exception
        if bool_isSuccess2:
            self.__dict_customMonitorsGroup = collections.OrderedDict(dict_customMonitorsGroup)
            AgentLogger.debug(AgentLogger.COLLECTOR,'Custom Monitor group Loaded From '+AgentConstants.AGENT_CUSTOM_MONITORS_GROUP_FILE+' : '+repr(dict_customMonitorsGroup))
        else:
            AgentLogger.log(AgentLogger.CRITICAL,' ********************** Failed to load the custom monitor group conf file : '+AgentConstants.AGENT_CUSTOM_MONITORS_GROUP_FILE+' ********************** \n')
            raise Exception
        if dict_monitorsInfo:
            if AgentConstants.OS_NAME == AgentConstants.OS_X:
                self.__dict_monitors = dict_monitorsInfo['MonitorsXml']['OSXMonitors']
            else:
                strDictKey = AgentConstants.OS_NAME + 'Monitors'
                self.__dict_monitors = dict_monitorsInfo['MonitorsXml'][strDictKey]
            #AgentLogger.log(AgentLogger.COLLECTOR,'Monitors Info Loaded From '+AgentConstants.AGENT_MONITORS_FILE+' : '+repr(dict_monitorsInfo))
        else:
            AgentLogger.log(AgentLogger.CRITICAL,' ********************** Failed To Load The Monitors Conf File : '+AgentConstants.AGENT_MONITORS_FILE+' ********************** \n')
            raise Exception
        AgentLogger.log(AgentLogger.COLLECTOR,'Custom monitors Info Loaded From '+AgentConstants.AGENT_CUSTOM_MONITORS_FILE+' : '+repr(dict_customMonitorsInfo))         
        if dict_customMonitorsInfo and 'MonitorsXml' in dict_customMonitorsInfo and 'LinuxMonitors' in dict_customMonitorsInfo['MonitorsXml']:
            self.__dict_customMonitors = dict_customMonitorsInfo['MonitorsXml']['LinuxMonitors']
        if dict_monitorsGroup and 'Monitoring' in dict_monitorsGroup['MonitorGroup']:
            AgentConstants.POLL_INTERVAL = dict_monitorsGroup['MonitorGroup']['Monitoring']['Interval']
            AgentLogger.log(AgentLogger.COLLECTOR,'monitoring poll interval frequency from monitorsgroup.json - {0}'.format(dict_monitorsGroup['MonitorGroup']['Monitoring']['Interval']))
            
    def setDataCollectionStopped(self, bool_dataCollectionStopped):
        self.__bool_dataCollectionStopped = bool_dataCollectionStopped
    
    def isDataCollectionStopped(self):
        return self.__bool_dataCollectionStopped
    
    def addMonitor(self):
        pass
    
    def removeMonitor(self):
        pass
    
    def updateMonitor(self):
        pass
    
    def getMonitors(self):
        return self.__dict_monitors
    
    def getMonitorsGroup(self):
        return self.__dict_monitorsgroup
    
    def getCustomMonitors(self):
        return self.__dict_customMonitors
    
    def __getCommandsToExecute(self, dict_groupVsMonitorList):
        dict_scriptVsArgs = {}
        list_scriptCommandsToExecute = []
        AgentLogger.debug(AgentLogger.COLLECTOR,'Collecting data for the group : '+repr(dict_groupVsMonitorList['GroupName'])+' with details : '+repr(dict_groupVsMonitorList))
        for monitorName in dict_groupVsMonitorList['Monitors']:
            #AgentLogger.log(AgentLogger.COLLECTOR,'Collecting data for the monitor : '+repr(monitorName))
            str_commandArgs = self.__dict_monitors[monitorName]['Attributes']['commandArgs']
            if monitorName == "Network Data":
                if AgentConstants.BONDING_INTERFACE_STATUS == True:
                    str_commandArgs = 'if_bond_data'
            if monitorName == "Process_Monitoring":
                if AgentConstants.PROCESS_MONITORING_NAMES==None or AgentConstants.PROCESS_MONITORING_NAMES=='':
                    continue
                else:
                    commandArgs = 'pcheck::'+AgentConstants.PROCESS_MONITORING_NAMES
                    str_commandArgs = "'{}'".format(commandArgs)
            if self.__dict_monitors[monitorName]['Attributes']['command'] not in dict_scriptVsArgs:
                list_commandArgs = []
                for commandArg in str_commandArgs.split(','):
                    if commandArg not in list_commandArgs:
                        list_commandArgs.append(commandArg)
                dict_scriptVsArgs[self.__dict_monitors[monitorName]['Attributes']['command']] = list_commandArgs
            elif self.__dict_monitors[monitorName]['Attributes']['commandArgs'] not in dict_scriptVsArgs[self.__dict_monitors[monitorName]['Attributes']['command']]:
                list_commandArgs = dict_scriptVsArgs[self.__dict_monitors[monitorName]['Attributes']['command']]
                for commandArg in str_commandArgs.split(','):
                    if commandArg not in list_commandArgs:
                        list_commandArgs.append(commandArg)
        AgentLogger.debug(AgentLogger.COLLECTOR,'Script vs argument map for group : '+repr(dict_groupVsMonitorList['GroupName'])+' are : '+repr(dict_scriptVsArgs))
        for key in dict_scriptVsArgs.keys():
            #str_agentDataCollFileName = FileUtil.getUniqueFileName(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),'Temp_Raw_Data')
            #str_agentDataCollFilePath = AgentConstants.AGENT_TEMP_DIR +'/'+str_agentDataCollFileName
            str_commandToExecute = '"'+AgentConstants.AGENT_SCRIPTS_DIR+'/'+key+'" '
            str_commandToExecute += ','.join(dict_scriptVsArgs[key])
#             if len(list_scriptCommandsToExecute) == 0:
#                 str_commandToExecute += ' > '+str_agentDataCollFilePath
#             else:
#                 str_commandToExecute += ' >> '+str_agentDataCollFilePath
            list_scriptCommandsToExecute.append(str_commandToExecute)
        #AgentLogger.log(AgentLogger.MAIN,'scripts command list -- '+repr(list_scriptCommandsToExecute))
        return list_scriptCommandsToExecute
    
    def collectData(self, dict_groupVsMonitorList):
        dict_collectedData = {}
        try:
            AgentLogger.debug(AgentLogger.COLLECTOR,'================================= COLLECTING DATA FOR THE GROUP : '+repr(dict_groupVsMonitorList['GroupName'])+'=================================')
            dict_collectedData = copy.deepcopy(dict_groupVsMonitorList)
            list_scriptCommandsToExecute = self.__getCommandsToExecute(dict_groupVsMonitorList)
            AgentLogger.debug(AgentLogger.COLLECTOR,'Script command(s) to be executed for group : '+repr(dict_groupVsMonitorList['GroupName'])+' are : '+repr(list_scriptCommandsToExecute))
            for command in list_scriptCommandsToExecute:
                executorObj = AgentUtil.Executor()
                executorObj.setLogger(AgentLogger.COLLECTOR)
                executorObj.setTimeout(14)
                executorObj.setCommand(command)
                executorObj.redirectToFile(True)
                executorObj.executeCommand()
                #AgentUtil.executeCommand(command, AgentLogger.COLLECTOR, 7)
                AgentLogger.debug(AgentLogger.MAIN,'command -- {0}'.format(command))
                dict_collectedData['CollectedData'] = self.__parseCollectedData(executorObj.getOutputFilePath(), dict_groupVsMonitorList)
            
            if 'AppMonitors' in dict_groupVsMonitorList:
                appList = dict_groupVsMonitorList['AppMonitors']
                dict_collectedData.setdefault('AppData',{})
                for each_app in appList:
                    task = APP_IMPL[each_app]
                    appData = task()
                    #AgentLogger.debug(AgentLogger.COLLECTOR,' APP data for : ' + each_app + ' is \n' + repr(appData))
                    dict_collectedData['AppData'].setdefault(each_app,appData)
            #AgentLogger.debug(AgentLogger.COLLECTOR,' COLLECTED DATA IN CD : ' + repr(dict_collectedData))
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], ' *************************** Exception while collecting data for the group : '+repr(dict_groupVsMonitorList['GroupName'])+'*************************** '+ repr(e) + '\n')
            traceback.print_exc()
            bool_isSuccess = False
        return dict_collectedData
    
    def __parseCollectedData(self, str_agentDataCollFilePath, dict_groupVsMonitorList):
        dict_collectedData = OrderedDict()
        file_obj = None
        try:
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(str_agentDataCollFilePath)
            fileObj.set_dataType('text')
            fileObj.set_mode('r')
            fileObj.set_loggerName(AgentLogger.COLLECTOR)
            fileObj.set_logging(False)
            bool_toReturn, str_collectedData = FileUtil.readData(fileObj)
            if not bool_toReturn:
                AgentLogger.log(AgentLogger.CRITICAL,'Exception while reading collected data from the file : '+repr(str_agentDataCollFilePath) + '\n')
                return None
            #AgentLogger.log(AgentLogger.COLLECTOR,'Collected data from the file '+str_agentDataCollFilePath+' is '+str_agentDataCollFilePath+str(str_collectedData))
            for monitorName in dict_groupVsMonitorList['Monitors']:
                bool_isSuccess = True
                list_parseTags = self.__dict_monitors[monitorName]['Attributes']['parseTag'].split(',')
                AgentLogger.debug(AgentLogger.COLLECTOR,'================================= '+str(monitorName)+' =================================')
                #AgentLogger.log(AgentLogger.COLLECTOR,'Parse tag for the monitor '+monitorName+' is '+repr(list_parseTags))
                str_data = self.__getData(list_parseTags, str_collectedData) 
                if str_data == None or str_data == '':
                    bool_isSuccess = False
                    AgentLogger.debug(AgentLogger.CRITICAL,'No data from script - for the monitor : '+repr(monitorName)+' in the group : '+repr(dict_groupVsMonitorList['GroupName']) + '\n')
                else:
                    bool_isSuccess = True
                if 'logOutput' in self.__dict_monitors[monitorName]['Attributes'] and self.__dict_monitors[monitorName]['Attributes']['logOutput'] == "false":
                    pass
                else:
                    AgentLogger.log(AgentLogger.COLLECTOR,'Data collected for the monitor : '+repr(monitorName)+' in the group : '+repr(dict_groupVsMonitorList['GroupName']))
                    AgentLogger.log(AgentLogger.COLLECTOR,str(str_data))
                dict_parsedData = AgentParser.parse(self.__dict_monitors[monitorName]['Attributes'], (bool_isSuccess, str_data))
                dict_collectedData[monitorName] = dict_parsedData
                AgentLogger.debug(AgentLogger.COLLECTOR,'Parsed data : '+repr(dict_parsedData))
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' ************************* Exception while reading collected data from the file '+str_agentDataCollFilePath+' ************************* '+repr(e) + '\n')
            traceback.print_exc()
        finally:
            if not file_obj == None:
                file_obj.close()
        return dict_collectedData
    
    def __getData(self, list_parseTags, str_collectedData):
        str_data = None
        for parseTag in list_parseTags:
            try:
                str_searchString = '<<'+parseTag+'>>'
                int_tagIndex = str_collectedData.find(str_searchString) + len(str_searchString)
                int_nextTagIndex = str_collectedData.find('<<', int_tagIndex)
                AgentLogger.debug(AgentLogger.COLLECTOR,'Parse tag : '+repr(str_searchString)+' Tag index : '+repr(int_tagIndex)+' Next tag index : '+repr(int_nextTagIndex))
                if str_data:
                    str_data += '\n'
                    str_data += str_collectedData[int_tagIndex:int_nextTagIndex].strip()
                else:
                    str_data = str_collectedData[int_tagIndex:int_nextTagIndex].strip()
            except Exception as e:
                AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],' ************************* Exception while searching collected data using parseTags '+repr(list_parseTags)+' ************************* '+ repr(e) + '\n')
                traceback.print_exc()
        return str_data

    # This method can be called multiple times. It just adds the schedule and the scheduler removes existing
    # schedules for a task and replaces them with the new one based on schedule creation time.
    def scheduleDataCollection(self):
        AgentLogger.log(AgentLogger.COLLECTOR,'================================= SCHEDULING FOR DATA COLLECTION =================================')
        self.setDataCollectionStopped(False)
        if not self.__dict_monitorsgroup == None:
            dict_monitorsGroup = self.__dict_monitorsgroup['MonitorGroup']
            dict_customMonitorsGroup = self.__dict_customMonitorsGroup['MonitorGroup']
            for key in list(dict_monitorsGroup.keys()):
                try: 
                    if 'Schedule' in dict_monitorsGroup[key] and dict_monitorsGroup[key]['Schedule'] == 'false':
                        AgentLogger.log([AgentLogger.COLLECTOR],'SKIPPING DATA COLLECTION FOR : '+repr(key)+' : '+ json.dumps(dict_monitorsGroup[key]))
                        continue
                    elif ((key in dict_customMonitorsGroup) and ('Schedule' in dict_customMonitorsGroup[key]) and (dict_customMonitorsGroup[key]['Schedule'] == 'false')):
                        AgentLogger.log([AgentLogger.COLLECTOR],'SKIPPING DATA COLLECTION FOR : '+repr(key)+' : '+ repr(dict_customMonitorsGroup[key]))
                        continue
                    AgentLogger.log([AgentLogger.COLLECTOR],'SCHEDULE FOR DATA COLLECTION : '+repr(key)+' : '+ json.dumps(dict_monitorsGroup[key]))
                    scheduleInfo = AgentScheduler.ScheduleInfo()
                    if not AgentScheduler.SCHEDULERS:
                        continue
                    task = self.collectData
                    callback = self.processCollectedData
                    taskArgs = dict_monitorsGroup[key]
                    if 'Interval' in dict_monitorsGroup[key]:
                        interval = int(dict_monitorsGroup[key]['Interval'])
                        scheduleInfo.setIsPeriodic(True)
                    elif key in dict_customMonitorsGroup and 'Interval' in dict_customMonitorsGroup[key]:
                        interval = int(dict_customMonitorsGroup[key]['Interval'])
                        if key == 'CPUMonitoring':
                            AgentConstants.CPU_SAMPLE_VALUES = int(300/interval)
                        scheduleInfo.setIsPeriodic(True)
                    else:
                        interval = 0
                        scheduleInfo.setIsPeriodic(False) 
                    if 'Impl' in dict_monitorsGroup[key]:
                        #AgentLogger.log(AgentLogger.COLLECTOR,'Impl found in ' + str(COLLECTOR_IMPL[key]))
                        task = COLLECTOR_IMPL[key]
                        callback = None
                        if key == 'RootCauseAnalysis' :
                            rcaInfo = RcaInfo()
                            rcaInfo.requestType = AgentConstants.GENERATE_RCA
                            rcaInfo.action = AgentConstants.SAVE_RCA_REPORT
                            AgentLogger.log(AgentLogger.COLLECTOR, 'RootCauseAnalysis')
                            taskArgs = rcaInfo
                        elif key == 'ProcessMonitoring':
                            callback = ProcessUtil.processCallback
                            taskArgs = None
                        else:
                            taskArgs = None
                    scheduleInfo.setSchedulerName('AgentScheduler')
                    scheduleInfo.setTaskName(key)
                    scheduleInfo.setTime(time.time())
                    scheduleInfo.setTask(task)
                    scheduleInfo.setTaskArgs(taskArgs)
                    scheduleInfo.setCallback(callback)
                    #scheduleInfo.setCallbackArgs(dict_monitorsGroup[key]   
                    scheduleInfo.setInterval(interval)
                    scheduleInfo.setLogger(AgentLogger.COLLECTOR)
                    AgentScheduler.schedule(scheduleInfo)
                    self.__dict_scheduleInfo[key] = scheduleInfo
                except Exception as e:
                    AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while scheduling '+repr(key)+' for data collection : *************************** '+ repr(e))
                    traceback.print_exc()
        else:
            AgentLogger.log(AgentLogger.CRITICAL, '*************************** Unable to schedule monitors for data collection since monitors group is empty : '+repr(self.__dict_monitorsgroup)+' *************************** \n')
        
    def processCollectedData(self, dict_groupVsMonitorList):
        list_fileNames = []
        list_appFileNames = []
        bool_thresholdCheck= False
        bool_dcTimeCheck=False
        try:
            AgentLogger.log(AgentLogger.COLLECTOR,'Processing collected data : ')
            dict_collectedData = dict_groupVsMonitorList['CollectedData']
            if dict_groupVsMonitorList['GroupName'] == 'Monitoring':
                fh = DataConsolidator.DataHandler()
                dictDataToSave = fh.createUploadData(dict_collectedData)
                if AgentConstants.POLL_INTERVAL != AgentConstants.FIVE_MIN_POLLING_INTERVAL:
                    bool_ThresholdViolated,violated_Param = self.checkForThresholdViolation(dictDataToSave)
                    if bool_ThresholdViolated:
                        AgentLogger.log(AgentLogger.COLLECTOR,'threshold violated  -- {0} attribute -- {1}'.format(bool_ThresholdViolated,violated_Param))
                        bool_thresholdCheck=True
                bool_isSuccess, str_fileName = saveCollectedData(dictDataToSave, "SMData")
                if bool_isSuccess:
                    list_fileNames.append(str_fileName)
            if 'AppData' in dict_groupVsMonitorList:
                dict_appData = dict_groupVsMonitorList['AppData']
                for key in dict_appData.keys():
                    dict_dataToSave = dict_appData[key]
                    if dict_groupVsMonitorList['GroupName'] == 'Realtime':
                        dict_dataToSave['REAL_TIME'] = 'True'
                    AgentLogger.debug(AgentLogger.COLLECTOR,'Saving app data : '+ repr(dict_dataToSave))
                    if dict_dataToSave:
                        bool_isSuccess, str_fileName = saveCollectedData(dict_dataToSave,key)
                        if bool_isSuccess:
                            list_appFileNames.append(str_fileName)
            if dict_groupVsMonitorList['SaveFile'] != 'False':
                for key in dict_collectedData.keys():
                    dict_dataToSave = dict_collectedData[key]
                    if dict_groupVsMonitorList['GroupName'] == 'Realtime':
                        dict_dataToSave['REAL_TIME'] = 'True'
                    AgentLogger.debug(AgentLogger.COLLECTOR,'Saving collected data : '+ repr(dict_dataToSave))
                    if dict_dataToSave:
                        bool_isSuccess, str_fileName = saveCollectedData(dict_dataToSave)
                        if bool_isSuccess:
                            list_fileNames.append(str_fileName)
                #FILES_TO_ZIP_BUFFER.add(list_fileNames)
            
            # Agent_5983972240318813010_Upload_1501061459566.zip
            if list_appFileNames:
                    self.setAppUploadInfo(list_appFileNames)
            
            if dict_groupVsMonitorList['GroupName'] != 'Monitoring':
                #AgentLogger.log(AgentLogger.COLLECTOR,'negative check  : '+ repr(dict_groupVsMonitorList['GroupName']))
                if list_fileNames:
                    self.setZipAndUploadInfo(list_fileNames)
             
            if AgentConstants.POLL_INTERVAL == AgentConstants.FIVE_MIN_POLLING_INTERVAL:
                if list_fileNames:
                    self.setZipAndUploadInfo(list_fileNames)
            else:
                if dict_groupVsMonitorList['GroupName'] == 'Monitoring':
                    bool_dcTimeCheck= self.checkForZipTask()
                if bool_thresholdCheck or bool_dcTimeCheck:
                    self.doZipTask()
            
            if AgentConstants.UPDATE_PLUGIN_INVENTORY:
                AgentLogger.log(AgentLogger.COLLECTOR,'-- plugin inventory update --')
                PluginMonitoring.pluginUtil.updateInventoryToServer()
                AgentConstants.UPDATE_PLUGIN_INVENTORY=False
                AgentLogger.log(AgentLogger.COLLECTOR, 'Inventory Update Reset -- {0}'.format(AgentConstants.UPDATE_PLUGIN_INVENTORY))
            
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while processing collected data : '+repr(dict_groupVsMonitorList)+' *************************** '+ repr(e))
            traceback.print_exc()
    
    def checkForZipTask(self):
        bool_toReturn=False
        if AgentConstants.CURRENT_DC_TIME==None:
            AgentConstants.CURRENT_DC_TIME=time.time()
            AgentConstants.PREVIOUS_DC_TIME=AgentConstants.CURRENT_DC_TIME
            bool_toReturn = True
        else:
            AgentConstants.CURRENT_DC_TIME=time.time()
            if (AgentConstants.CURRENT_DC_TIME - AgentConstants.PREVIOUS_DC_TIME) >= int(AgentConstants.UPLOAD_CHECK_INTERVAL):
                bool_toReturn = True
                AgentConstants.PREVIOUS_DC_TIME=AgentConstants.CURRENT_DC_TIME
            else:
                bool_toReturn = False
        return bool_toReturn
    
    
    def evaluateThreshold(self,perf_Value,condition,threshold):
        eval_Check = False
        try:
            perf_Value=str(perf_Value)
            condition=str(condition)
            threshold=str(threshold)
            math_String = perf_Value+condition+threshold
            eval_Check = eval(math_String)
        except Exception as e:
            traceback.print_exc()
        return eval_Check
    
    def checkForThresholdViolation(self,dictDataToSave):
        bool_ToReturn=False
        violated_Param=None
        try:
            if DataConsolidator.THRESHOLD_DICT:
                for metric in DataConsolidator.THRESHOLD_DICT.keys():
                    dictValue = DataConsolidator.THRESHOLD_DICT[metric]
                    condition=None
                    threshold=None
                    if 'con' in dictValue:
                        condition = dictValue['con']
                        threshold = dictValue['val']
                        if metric in dictDataToSave:
                            perf_Value = dictDataToSave[metric]
                            eval_Check = self.evaluateThreshold(perf_Value,condition,threshold)
                        if eval_Check==True and (AgentConstants.S_V_DICT is not None and metric not in AgentConstants.S_V_DICT):
                            AgentLogger.log(AgentLogger.COLLECTOR,'threshold violated  -- metric  - {0}'.format(metric))
                            bool_ToReturn=True
                            violated_Param=metric
                            break
                    elif ((metric in dictDataToSave) and type(dictDataToSave[metric]) is list):
                        for innerkey , innerval in dictValue.items():
                            if innerkey=="global":
                                for key in innerval:
                                    perf_check = key
                                    perf_criteria = innerval[key]
                                    condition = perf_criteria['con']
                                    threshold = perf_criteria['val']
                                    list_Values=dictDataToSave[metric]
                                    for item in list_Values:
                                        id =item['id']
                                        perf_Value = str(item[perf_check])
                                        eval_Check = self.evaluateThreshold(perf_Value,condition,threshold)
                                        if eval_Check:
                                            if (AgentConstants.S_V_DICT is not None) and ((metric not in AgentConstants.S_V_DICT) or (id not in AgentConstants.S_V_DICT[metric]) or (perf_check not in AgentConstants.S_V_DICT[metric][id])):
                                                AgentLogger.log(AgentLogger.COLLECTOR,'threshold violated -- metric  - {0}, child key - {1}, resource id - {2}'.format(metric,perf_check,id))
                                                bool_ToReturn=True
                                                violated_Param=perf_check
                                                return bool_ToReturn,violated_Param
                                        else:
                                            AgentLogger.debug(AgentLogger.COLLECTOR,' else case ')
                            else:
                                list_Values=dictDataToSave[metric]
                                for item in list_Values:
                                    id = item['id']
                                    if id == innerkey:
                                        child_Dict = dictValue[id]
                                        for innerChildKey,innerChildVal in child_Dict.items():
                                            if innerChildKey in item:
                                                perf_Value = item[innerChildKey]
                                                condition = dictValue[id][innerChildKey]['con']
                                                threshold = dictValue[id][innerChildKey]['val']
                                                if isinstance(perf_Value, int):
                                                    perf_Value = str(perf_Value)
                                                eval_Check = self.evaluateThreshold(perf_Value,condition,threshold)
                                                if eval_Check:
                                                    if (AgentConstants.S_V_DICT is not None) and ( (metric not in AgentConstants.S_V_DICT) or (id not in AgentConstants.S_V_DICT[metric]) or (innerChildKey not in AgentConstants.S_V_DICT[metric][id])):
                                                        AgentLogger.log(AgentLogger.COLLECTOR,'threshold violated -- metric  - {0}, child key - {1}, resource id - {2}'.format(metric,innerChildKey,id))
                                                        bool_ToReturn=True
                                                        violated_Param=innerChildKey
                                                        return bool_ToReturn,violated_Param
                                                else:
                                                    AgentLogger.debug(AgentLogger.COLLECTOR,' eval check failed :: {0}{1}'.format(violated_Param,innerChildKey))
                    else:
                        for secondLevelKey in dictValue.keys():
                            if secondLevelKey in  DataConsolidator.THRESHOLD_DICT[metric]:
                                if 'con' in DataConsolidator.THRESHOLD_DICT[metric][secondLevelKey]:
                                    condition = DataConsolidator.THRESHOLD_DICT[metric][secondLevelKey]['con']
                                    threshold = DataConsolidator.THRESHOLD_DICT[metric][secondLevelKey]['val']
                                    perf_Value = dictDataToSave[metric][secondLevelKey]
                                    perf_Value = str(perf_Value)
                                    eval_Check = self.evaluateThreshold(perf_Value,condition,threshold)
                                    if eval_Check==True:
                                        if AgentConstants.S_V_DICT is not None and ( ( metric not in AgentConstants.S_V_DICT ) or ( metric in AgentConstants.S_V_DICT and secondLevelKey not in AgentConstants.S_V_DICT[metric])):
                                            AgentLogger.log(AgentLogger.COLLECTOR,'threshold violated -- metric  - {0}, child key - {1}'.format(metric,secondLevelKey))
                                            bool_ToReturn=True
                                            violated_Param=secondLevelKey
                                            return bool_ToReturn,violated_Param
            else:
                bool_ToReturn=False
        except Exception as e:
            traceback.print_exc()
        
        return bool_ToReturn,violated_Param
    
    def doZipTask(self):
        dict_requestParameters = {}
        listOfFiles=[]
        try:
            list_files = FileUtil.getSortedFileList(AgentConstants.AGENT_DATA_DIR, str_loggerName=AgentLogger.COLLECTOR)
            for fileName in list_files:
                if "SMData" not in fileName:
                    continue
                listOfFiles.append(fileName)
                if len(listOfFiles) == AgentConstants.NO_OF_DC_FILES:
                    AgentLogger.log(AgentLogger.COLLECTOR,' DC file size matches constant value --- '+repr(len(listOfFiles)))
                    self.setZipAndUploadInfo(listOfFiles)
                    listOfFiles=[]
            if len(listOfFiles) > 0:
                #AgentLogger.log(AgentLogger.COLLECTOR,' No of files zipped --- '+repr(len(listOfFiles)))
                self.setZipAndUploadInfo(listOfFiles)
        except Exception as e:
            traceback.print_exc()
    
    #Setting the upload and zipping parameters of predifined metrics
    def setZipAndUploadInfo(self, listOfFiles):
        dict_requestParameters = {}
        try:
            zipAndUploadInfo = FileZipAndUploadInfo()
            zipAndUploadInfo.filesToZip = listOfFiles
            zipAndUploadInfo.zipFileName = ZipUtil.getUniqueZipFileName(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), 'Upload_' +str(AgentUtil.getTimeInMillis()))
            zipAndUploadInfo.zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipAndUploadInfo.zipFileName
            #AgentLogger.log(AgentLogger.COLLECTOR,' dc zip file name --- {0}{1}'.format(zipAndUploadInfo.zipFileName,zipAndUploadInfo.zipFilePath))
            dict_requestParameters['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            dict_requestParameters['CUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['AGENTUNIQUEID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
            dict_requestParameters['FILENAME'] = zipAndUploadInfo.zipFilePath
            dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
            zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
            zipAndUploadInfo.uploadServlet = AgentConstants.AGENT_FILE_COLLECTOR_SERVLET
            FILES_TO_ZIP_BUFFER.add(zipAndUploadInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while setting zipanduploadinfo in collector *************************** '+ repr(e))
            traceback.print_exc()
            
    #Setting the upload and zipping parameters of application metrics
    def setAppUploadInfo(self, listOfFiles):
        dict_requestParameters = {}
        try:
            zipAndUploadInfo = FileZipAndUploadInfo()
            zipAndUploadInfo.filesToZip = listOfFiles
            zipAndUploadInfo.zipFileName = ZipUtil.getUniqueZipFileName(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), 'Application_' +str(AgentUtil.getTimeInMillis()))
            zipAndUploadInfo.zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipAndUploadInfo.zipFileName
            dict_requestParameters['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            dict_requestParameters['CUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['AGENTUNIQUEID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
            dict_requestParameters['FILENAME'] = zipAndUploadInfo.zipFilePath
            dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
            zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
            zipAndUploadInfo.uploadServlet = AgentConstants.APPLICATION_COLLECTOR_SERVLET
            FILES_TO_ZIP_BUFFER.add(zipAndUploadInfo)
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while setting zipanduploadinfo in collector *************************** '+ repr(e) + '\n')
            traceback.print_exc()

    def stopDataCollection(self):
        try:
            if not self.isDataCollectionStopped():
                AgentLogger.log([ AgentLogger.COLLECTOR],'================================= STOPPING DATA COLLECTION =================================')
                dict_monitorsGroup = self.__dict_monitorsgroup['MonitorGroup']
                AgentLogger.log([ AgentLogger.COLLECTOR],'Deleting schedules for : '+ repr(list(dict_monitorsGroup.keys())))
                for key in list(dict_monitorsGroup.keys()):
                    try:  
                        scheduleInfo = AgentScheduler.ScheduleInfo()
                        scheduleInfo.setSchedulerName('AgentScheduler')
                        scheduleInfo.setTaskName(key)
                        AgentScheduler.deleteSchedule(scheduleInfo)
                    except Exception as e:
                        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while stopping data collection *************************** '+ repr(e))
                        traceback.print_exc()
                self.setDataCollectionStopped(True)
                ACTIVATOR.scheduleActivator()
            else:
                AgentLogger.log([ AgentLogger.COLLECTOR],'Data collection is already stopped')
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while setting zipanduploadinfo in collector *************************** '+ repr(e) + '\n')
            traceback.print_exc()

    def startDataCollection(self):
        try:
            AgentLogger.log([ AgentLogger.COLLECTOR],'================================= RE-STARTING DATA COLLECTION =================================')
            COLLECTOR.scheduleDataCollection()
            ACTIVATOR.stopActivator()
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while starting data collection *************************** '+ repr(e) + '\n')
            traceback.print_exc()
    
    
class LinuxCollector(Collector):
    def __init__(self, name = 'Linux Collector', distro = None):
        Collector.__init__(self, name)
        self.__distro = distro
        
class UbuntuCollector(LinuxCollector):
    def __init__(self, name = 'Ubuntu Collector', distro = None):
        LinuxCollector.__init__(self, name, distro)


class FileZipper(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.name = 'File Zipper'
    def run(self):
        try:
            while not AgentUtil.TERMINATE_AGENT:                                
                ZipUtil.zipFilesInBuffer()
                AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.FILE_ZIPPER_INTERVAL)           
        except Exception as e:
            AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception while executing the FileZipper thread *************************** '+ repr(e) + '\n')
            traceback.print_exc()            

class Uploader(threading.Thread):
    __serverNotReachableStartTime = 0            
    def __init__(self):
        threading.Thread.__init__(self)
        self.name = 'UploaderThread'
    def run(self):
        try:
            int_prevFileCleanUpTime = time.time()
            # sleep for 7 seconds and upload files assuming data will be collected after scheduling.
            #time.sleep(7)
            self.__addFilesInUploadDirectoryToBuffer()
            #ZipUtil.zipFilesInDataDirectory()
            while not AgentUtil.TERMINATE_AGENT: 
                try:
                    int_currentTime = time.time()                          
                    Uploader.upload()
                    if (int_currentTime - int_prevFileCleanUpTime) >= AgentConstants.FILE_CLEAN_UP_INTERVAL:
                        FileUtil.cleanUpFiles()
                        int_prevFileCleanUpTime = int_currentTime
                    #Wait for a large interval if it is not the first data collection
                    if FILES_UPLOADED <= 5:
                        #AgentLogger.log(AgentLogger.STDOUT,'Value of files uploaded is : ' + str(FILES_UPLOADED) + '. Hence wait interval is default')
                        AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.FILE_UPLOAD_INTERVAL)
                    else:
                        AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.FILE_UPLOAD_NEW_INTERVAL)
                except Exception as e:
                    AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception while executing the uploader thread *************************** '+ repr(e) + '\n')
                    traceback.print_exc()   
        except Exception as e:
            AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception while executing the uploader thread *************************** '+ repr(e) + '\n')
            traceback.print_exc()
            
    def __addFilesInUploadDirectoryToBuffer(self):
        try:
            AgentLogger.log(AgentLogger.STDOUT,'===================== ADDING FILES IN UPLOAD DIRECTORY TO UPLOAD BUFFER ======================')
            for zipFileName in sorted(os.listdir(AgentConstants.AGENT_UPLOAD_DIR)):
                for upload_category in UPLOAD_DATA_DIR_IMPL:
                    if upload_category in zipFileName:
                        task = UPLOAD_DATA_DIR_IMPL[upload_category]
                        taskArgs =  zipFileName
                        #AgentLogger.log(AgentLogger.STDOUT, ' ***************************Executing task : ' + str(task) + '*****************************')
                        task(taskArgs)
                        AgentLogger.log(AgentLogger.STDOUT, ' *************************** Found upload_category : ' + upload_category + ' in upload directory file: ' +  zipFileName)
                        #self.setUploadInfo(zipFileName,upload_category)    
        except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT, ' *************************** Exception while adding files in upload directory to upload buffer *************************** '+ repr(e))
            traceback.print_exc()

    def addFilesinDataDirectory(self,zipFileName):
        dict_requestParameters = {}
        try:
            zipAndUploadInfo = FileZipAndUploadInfo()
            zipAndUploadInfo.zipFileName = zipFileName
            zipAndUploadInfo.zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipAndUploadInfo.zipFileName
            dict_requestParameters['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            dict_requestParameters['CUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['AGENTUNIQUEID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
            dict_requestParameters['FILENAME'] = zipAndUploadInfo.zipFilePath
            dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
            zipAndUploadInfo.uploadServlet = AgentConstants.AGENT_FILE_COLLECTOR_SERVLET
            zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
            AgentBuffer.getBuffer('FILES_TO_UPLOAD_BUFFER').add(zipAndUploadInfo)
        except Exception as e:
            AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception while adding files in upload directory to upload buffer *************************** '+ repr(e) + '\n')
            traceback.print_exc()
            
    def addCustomFilesinDataDirectory(self,zipFileName):
        dict_requestParameters = {}
        try:
            zipAndUploadInfo = FileZipAndUploadInfo()
            zipAndUploadInfo.zipFileName = zipFileName
            zipAndUploadInfo.zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipAndUploadInfo.zipFileName
            dict_requestParameters['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            dict_requestParameters['CUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['AGENTUNIQUEID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id')
            dict_requestParameters['FILENAME'] = zipAndUploadInfo.zipFilePath
            dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
            zipAndUploadInfo.uploadServlet = AgentConstants.AGENT_FILE_COLLECTOR_SERVLET # Change to custom metric later
            zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
            AgentBuffer.getBuffer('FILES_TO_UPLOAD_BUFFER').add(zipAndUploadInfo)
        except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT, ' *************************** Exception while adding  custom files in upload directory to upload buffer *************************** '+ repr(e))
            traceback.print_exc()
    
    def getUploadData(zipAndUploadInfo):
        str_dataToReturn = None
        try:
            bool_zipFileCorrupted = False
            if zipAndUploadInfo.zipFilePath and os.path.isfile(zipAndUploadInfo.zipFilePath):
                try:
                    file_obj = open(zipAndUploadInfo.zipFilePath,'rb')
                    str_dataToReturn = file_obj.read()
                    zipAndUploadInfo.isZipFile = True
                except Exception as e:
                    AgentLogger.log(AgentLogger.CRITICAL,' ************************* Exception while reading the zip file '+repr(full_path)+' ************************* '+ repr(e) + '\n')
                    traceback.print_exc()
                    bool_zipFileCorrupted = True
                finally:
                    if file_obj:
                        file_obj.close()       
                if bool_zipFileCorrupted:
                    os.remove(full_path)
            elif zipAndUploadInfo.uploadData:
                str_dataToReturn = zipAndUploadInfo.uploadData
                zipAndUploadInfo.isZipFile = False
        except Exception as e:
            AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception while fetching data for uploading *************************** '+ repr(e) + '\n')
            traceback.print_exc()
        return str_dataToReturn
            
    @synchronized
    def upload():
        file_obj = None
        dict_requestParameters = {}
        global FILES_UPLOADED, LAST_UPLOADED_TIME, UPLOAD_PAUSE_TIME, UPLOAD_PAUSE_FLAG
        try:
            buffer_UploadInfoObjects = AgentBuffer.getBuffer('FILES_TO_UPLOAD_BUFFER')
            while buffer_UploadInfoObjects.size() > 0 and not AgentUtil.TERMINATE_AGENT:
                if UPLOAD_PAUSE_FLAG:
                    ct = time.time()
                    if ((ct - LAST_UPLOADED_TIME) > UPLOAD_PAUSE_TIME):
                        AgentLogger.log(AgentLogger.STDOUT,' Upload pause time requested by server completed. Hence switching to normal upload mode')
                        UPLOAD_PAUSE_FLAG = False
                        UPLOAD_PAUSE_TIME = 0
                    else:
                        break
                AgentLogger.log(AgentLogger.STDOUT,'================================= UPLOAD FILES AND DATA =================================')
                str_url = None
                str_dataToSend = None
                str_contentType = None
                zipAndUploadInfo = buffer_UploadInfoObjects.pop()
                AgentLogger.log(AgentLogger.STDOUT,'One object removed from the upload buffer with a total of : ' + str(len(buffer_UploadInfoObjects)) + 'zips')
                if AgentConstants.UPTIME_MONITORING=="true":
                    AgentLogger.log(AgentLogger.STDOUT,'##### Deleting collected data [uptime monitoring] #####')
                    os.remove(zipAndUploadInfo.zipFilePath)
                else:
                    try:
                        dict_requestParameters = zipAndUploadInfo.uploadRequestParameters
                        str_dataToSend = Uploader.getUploadData(zipAndUploadInfo)
                        if zipAndUploadInfo.isZipFile == True:
                            fileName = zipAndUploadInfo.zipFileName
                            str_contentType = 'application/zip'
                        else:
                            str_contentType = 'application/json'
                        if not str_dataToSend:
                            AgentLogger.log(AgentLogger.CRITICAL,'Unable to get data for the zipAndUploadInfo object : '+repr(zipAndUploadInfo)+' hence skipping upload\n')
                            continue
                        str_servlet = zipAndUploadInfo.uploadServlet
                        if not dict_requestParameters == None:
                            if str_servlet in [AgentConstants.PLUGIN_DATA_POST_SERVLET,AgentConstants.AGENT_FILE_COLLECTOR_SERVLET,AgentConstants.APPLICATION_COLLECTOR_SERVLET]:
                                dict_requestParameters['ZIPS_IN_BUFFER'] = int(len(buffer_UploadInfoObjects))
                            str_requestParameters = urlencode(dict_requestParameters)
                            str_url = str_servlet + str_requestParameters
                        requestInfo = CommunicationHandler.RequestInfo()
                        requestInfo.set_loggerName(AgentLogger.STDOUT)
                        requestInfo.set_method(AgentConstants.HTTP_POST)
                        requestInfo.set_url(str_url)
                        requestInfo.set_data(str_dataToSend)
                        requestInfo.set_dataType(str_contentType)
                        requestInfo.add_header("Content-Type", str_contentType)
                        requestInfo.add_header("Accept", "text/plain")
                        requestInfo.add_header("Connection", 'close')
                        (bool_isSuccess, errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
                        CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'FILE UPLOADER')
                        if bool_isSuccess:
                            if ((dict_responseHeaders) and ('UPLOAD_FAILED' in dict_responseHeaders) and (str(dict_responseHeaders['UPLOAD_FAILED'] == "True"))):
                                buffer_UploadInfoObjects.appendleft(zipAndUploadInfo)
                                AgentLogger.log(AgentLogger.STDOUT,'Zip readded to upload buffer due to server side error. Total zips in buffer : ' + str(len(buffer_UploadInfoObjects)))
                                continue
                            LAST_UPLOADED_TIME = time.time()
                            FILES_UPLOADED = FILES_UPLOADED + 1
                            if FILES_UPLOADED > 100 :
                                FILES_UPLOADED = int(FILES_UPLOADED/10)
                            AgentLogger.log(AgentLogger.STDOUT,'Value of files uploaded changed to : ' + str(FILES_UPLOADED))
                            if zipAndUploadInfo.isZipFile == True:
                                AgentLogger.log(AgentLogger.STDOUT, 'Successfully posted the zip file :'+fileName+' to the server \n')
                            else:
                                AgentLogger.log([AgentLogger.STDOUT], 'Successfully posted the JSON data to the server \n')
                                dictUploadedData = json.loads(str_dataToSend)
                                if AgentConstants.CHECKS_VERIFY_TEXT in dictUploadedData:
                                    AgentLogger.debug(AgentLogger.STDOUT, 'Changing status after instant notification')
                                    BasicClientHandler.URLUtil.updateURLStatus(dictUploadedData)
                                    BasicClientHandler.PortUtil.updatePortStatus(dictUploadedData)
                                    if 'logrule' in dictUploadedData:
                                        UdpHandler.SysLogUtil.updateSyslogData(dictUploadedData)
                                '''elif AgentConstants.PORT_VERIFY_TEXT in dictUploadedData:
                                    BasicClientHandler.PortUtil.updatePortStatus(dictUploadedData)'''
                            if Uploader.__serverNotReachableStartTime != 0:
                                Uploader.__serverNotReachableStartTime = 0
                                COLLECTOR.scheduleDataCollection()
                            if zipAndUploadInfo.isZipFile == True:
                                os.remove(zipAndUploadInfo.zipFilePath)
                        else:
                            buffer_UploadInfoObjects.appendleft(zipAndUploadInfo)
                            AgentLogger.log(AgentLogger.STDOUT,'Zip readded to upload buffer because upload did not recieve successful flag. Total zips in buffer : ' + str(len(buffer_UploadInfoObjects)))
                            if zipAndUploadInfo.isZipFile == True:
                                AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDOUT], '************************* Unable to post the zip file :'+fileName+' to the server. Added its uploadinfo object to upload buffer ************************* \n')
                            else:
                                AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDOUT], '************************* Unable to post the JSON data to the server. Added its uploadinfo object to upload buffer ************************* \n')
                            CommunicationHandler.checkNetworkStatus(AgentLogger.STDOUT)
                            AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.FILE_UPLOAD_EXCEPTION_INTERVAL)
                            if isinstance(errorCode, OSError):
                                if Uploader.__serverNotReachableStartTime == 0:
                                    Uploader.__serverNotReachableStartTime = time.time()
                                    break
                                elif (time.time() - Uploader.__serverNotReachableStartTime) > AgentConstants.STOP_DATA_COLLECTION_INTERVAL:
                                    AgentLogger.log([ AgentLogger.CRITICAL],'Agent is not able to reach server for '+repr(time.time() - Uploader.__serverNotReachableStartTime)+' seconds > STOP_DATA_COLLECTION_INTERVAL = '+repr(AgentConstants.STOP_DATA_COLLECTION_INTERVAL)+'\n')
                                    COLLECTOR.stopDataCollection()
                                    break
                                else:
                                    break
                    except Exception as e:
                        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], ' *************************** Exception while uploading files/JSON data *************************** '+ repr(e) + '\n')
                        traceback.print_exc()
                        buffer_UploadInfoObjects.appendleft(zipAndUploadInfo) # Make sure that zipAndUploadInfo is back in buffer when exception occurs.
                        AgentLogger.log(AgentLogger.STDOUT,'Zip readded to upload buffer due to exception. Total memory occupied by it is now with a total of : ' + str(len(buffer_UploadInfoObjects)) + 'zips')
        except Exception as e:
            AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], ' *************************** Exception while uploading files/JSON data *************************** '+ repr(e) + '\n')
            traceback.print_exc()

def saveCollectedData(dict_dataToSave, custom = None):
    bool_toReturn = True
    str_fileName = None
    try:
        dict_dataToSave['MSPCUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_dataToSave['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        if custom and custom=="SMData":
            custom=AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')+"_"+custom+"_"+"millis"+"_"+str(AgentUtil.getTimeInMillis())
            str_fileName = FileUtil.getUniqueFileName(dict_dataToSave['AGENTKEY'],custom,True)
        else:
            dict_dataToSave['DATACOLLECTTIME'] = str(AgentUtil.getTimeInMillis())
            str_fileName = FileUtil.getUniqueFileName(dict_dataToSave['AGENTKEY'])
        str_filePath = AgentConstants.AGENT_DATA_DIR +'/'+ str_fileName
        fileObj = AgentUtil.FileObject()
        fileObj.set_fileName(str_fileName)
        fileObj.set_filePath(str_filePath)
        fileObj.set_data(dict_dataToSave)
        fileObj.set_dataType('json')
        fileObj.set_mode('wb')
        fileObj.set_dataEncoding('UTF-16LE')
        fileObj.set_loggerName(AgentLogger.COLLECTOR)
        bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR], '*************************** Exception while saving collected data : '+repr(dict_dataToSave)+'*************************** '+ repr(e) + '\n')
        traceback.print_exc()
        bool_toReturn = False
    return bool_toReturn, str_fileName

    
def loadQueryConf():    
    global PROCESS_LIST
    bool_isSuccess = True
    str_queryConfDir = AgentConstants.AGENT_QUERY_CONF_DIR+'/'+AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
    str_queryConfPath = str_queryConfDir+'/queryconf.txt'
    try:
        appendCustomMonitorsToMonitorsInfo()
        if not os.path.exists(str_queryConfDir):
            os.makedirs(str_queryConfDir)
        if not os.path.exists(str_queryConfPath):#copying default queryconf.txt
            shutil.copy(AgentConstants.AGENT_QUERY_CONF_DIR+'/queryconf.txt', str_queryConfPath)   
        if os.path.exists(str_queryConfPath):            
            isSuccess, dict_queryConfData = AgentUtil.loadUnicodeDataFromFile(str_queryConfPath)
            AgentLogger.debug(AgentLogger.STDOUT, 'LOAD QUERYCONF : Monitors Info Loaded From XML :'+repr(MONITORS_INFO))
            AgentLogger.debug(AgentLogger.STDOUT, 'LOAD QUERYCONF : Custom Monitors Info Loaded From XML :'+repr(CUSTOM_MONITORS_INFO))
            if isSuccess:
                list_dataCollParams = dict_queryConfData['WorkFlows']                
                for dict_dataCollParam in list_dataCollParams:
                    list_searchStrings = []
                    if 'Name' in dict_dataCollParam['recordSetName'][0]:
                        monitorDetails = dict_dataCollParam['recordSetName'][0]
                        monitorName = monitorDetails['Name']
                        monitoringInterval = dict_dataCollParam['interval']
                        AgentLogger.debug(AgentLogger.STDOUT, 'LOAD QUERYCONF : MONITOR :'+repr(monitorName)+repr(dict_dataCollParam)) 
                        #check for parsing search variables from wmiQuery for PROCESS_AND_SERVICE_DETAILS
                        if monitorName == 'PROCESS_AND_SERVICE_DETAILS':                            
                            params = monitorDetails['params']
                            AgentLogger.debug(AgentLogger.STDOUT, 'LOAD QUERYCONF : params :'+repr(params)+repr(type(params))) 
                            list_strings = re.findall(r'\'[\w\s\d,<\.\>\?\/\!\@\#\$\%\^\&\*\(\)\_\-\+\=\`\~\"\;\:]+\'',params)
                            for str_temp in list_strings:
                                list_searchStrings.append(str_temp[1:-1])                                                                                                      
                    if not COLLECTOR.getMonitors() == None and monitorName in COLLECTOR.getMonitors():     
                        dict_monitorAttributes = COLLECTOR.getMonitors()[monitorName]['Attributes']
                        if list_searchStrings:
                            dict_monitorAttributes['searchValues'] = list_searchStrings
                            AgentLogger.log(AgentLogger.STDOUT, 'Process to be filtered : '+repr(list_searchStrings))
                            dict_processToBeMonitored = {} 
                            list_processToBeMonitored = []
                            for processName in list_searchStrings:
                                dict_processToBeMonitored = {}
                                dict_processToBeMonitored['Name'] = processName
                                list_processToBeMonitored.append(dict_processToBeMonitored)
                            updateProcessList(list_processToBeMonitored)
                        AgentLogger.debug(AgentLogger.STDOUT, 'LOAD QUERYCONF : '+repr(monitorName)+' : Attributes : '+repr(dict_monitorAttributes))                 
            else:
                AgentLogger.log(AgentLogger.STDOUT, 'Failed To load the QueryConf.txt in the path :'+str_queryConfPath)
                bool_isSuccess = False
            AgentLogger.debug(AgentLogger.STDOUT,'MONITORS_INFO Data :'+repr(COLLECTOR.getMonitors()))
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT, '*************************** Exception While loading Query Conf In The Path : '+str_queryConfPath+'*************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess

def appendCustomMonitorsToMonitorsInfo():
    if COLLECTOR.getCustomMonitors():
        for monitorName in list(COLLECTOR.getCustomMonitors().keys()):            
            if not COLLECTOR.getMonitors() == None:     
                COLLECTOR.getMonitors()[monitorName] = COLLECTOR.getCustomMonitors()[monitorName]

def updateQueryConf(dict_updateQueryInfo, str_loggerName=AgentLogger.STDOUT):
    bool_isSuccess = True
    list_queryConf = []
    int_monitorCount = 0
    int_updateMonitorIndex = None
    str_agentQueryConfDir = AgentConstants.AGENT_QUERY_CONF_DIR+'/'+AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
    str_queryConfPath = str_agentQueryConfDir+'/queryconf.txt'
    try:
        if os.path.exists(str_queryConfPath):            
            isSuccess, dict_queryConfData = AgentUtil.loadUnicodeDataFromFile(str_queryConfPath)
            AgentLogger.log(str_loggerName, 'Monitor details to be updated in the query conf :'+repr(type(dict_updateQueryInfo))+repr(dict_updateQueryInfo))
            updateMonitorName = dict_updateQueryInfo['recordSetName'][0]['Name']#monitor details from server
            if isSuccess:
                list_dataCollParams = dict_queryConfData['WorkFlows']#list of monitors in query conf
                for dict_dataCollParam in list_dataCollParams:                                     
                    if 'Name' in dict_dataCollParam['recordSetName'][0]:
                        monitorName = dict_dataCollParam['recordSetName'][0]['Name']
                        if monitorName == 'PROCESS_AND_SERVICE_DETAILS':              
                            list_searchStrings = []              
                            params = dict_updateQueryInfo['recordSetName'][0]['params']
                            AgentLogger.log(str_loggerName, 'UPDATE QUERYCONF : params :'+repr(params)+repr(type(params))) 
                            list_strings = re.findall(r'\'[\w\s\d,<\.\>\?\/\!\@\#\$\%\^\&\*\(\)\_\-\+\=\`\~\"\;\:]+\'',params)
                            for str_temp in list_strings:
                                list_searchStrings.append(str_temp[1:-1])
                            AgentLogger.log(str_loggerName, 'Process to be filtered in update query conf : '+repr(list_searchStrings))
                            dict_processToBeMonitored = {} 
                            list_processToBeMonitored = []
                            for processName in list_searchStrings:
                                dict_processToBeMonitored = {}
                                dict_processToBeMonitored['Name'] = processName
                                list_processToBeMonitored.append(dict_processToBeMonitored)
                            updateProcessList(list_processToBeMonitored)
                        if updateMonitorName == monitorName:
                            int_updateMonitorIndex = int_monitorCount
                    int_monitorCount+=1
                if not int_updateMonitorIndex == None:
                    list_dataCollParams.pop(int_updateMonitorIndex)
                #by default append the monitor details from the server to the query conf list
                list_dataCollParams.append(dict_updateQueryInfo)    
                AgentLogger.log(str_loggerName, 'Query Conf data collection list :'+repr(list_dataCollParams))
                AgentUtil.writeUnicodeDataToFile(str_queryConfPath, json.dumps(dict_queryConfData))
                loadQueryConf()
                #COLLECTOR.scheduleDataCollection()
            else:
                AgentLogger.log(str_loggerName, 'Error while loading the QueryConf.txt in the path :'+str_queryConfPath)
                bool_isSuccess = False
        else:            
            AgentLogger.log(str_loggerName,'Failed to update query conf since '+repr(str_queryConfPath)+' does not exist!!')
            bool_isSuccess = False
    except Exception as e:
        AgentLogger.log(str_loggerName, '*************************** Exception while updating query conf in the path : '+str_queryConfPath+'*************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess    

def initializeFileAndZipIds():
    if int(AgentUtil.AGENT_PARAMS['AGENT_FILE_ID']) >= AgentConstants.MAX_FILE_ID - 100:
        AgentUtil.AGENT_PARAMS['AGENT_FILE_ID'] = 0
        AgentUtil.persistAgentParams()
    if int(AgentUtil.AGENT_PARAMS['AGENT_ZIP_ID']) >= AgentConstants.MAX_FILE_ID - 100:
        AgentUtil.AGENT_PARAMS['AGENT_ZIP_ID'] = 0
        AgentUtil.persistAgentParams()
    AgentUtil.AGENT_PARAMS['AGENT_FILE_ID'] = int(AgentUtil.AGENT_PARAMS['AGENT_FILE_ID']) +100
    AgentUtil.AGENT_PARAMS['AGENT_ZIP_ID'] = int(AgentUtil.AGENT_PARAMS['AGENT_ZIP_ID']) +100
    FileUtil.setFileId(AgentUtil.AGENT_PARAMS['AGENT_FILE_ID'])
    ZipUtil.setZipId(AgentUtil.AGENT_PARAMS['AGENT_ZIP_ID'])
    AgentUtil.persistAgentParams()
