#$Id$
import json
import os
import time
import traceback
import threading
from urllib.parse import urlencode
from com.manageengine.monagent import AgentConstants
#from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentBuffer
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util import DesignUtils
from com.manageengine.monagent.util.AgentUtil import ZipUtil, FileUtil, FileZipAndUploadInfo, Executor

NFSUtil = None

class NFS():
    def __init__(self):
        self.id = None
        self.path = None
        self.timeout = AgentConstants.DEFAULT_SCRIPT_TIMEOUT
        #self.er = None
        #self.cmd = None
    
    def setNFSDetails(self,dictDetails):
        try:
            self.id = dictDetails['id']
            self.path=dictDetails['nfspath'].rstrip('/')
            if 'timeout' in dictDetails:
                self.timeout = dictDetails['timeout']
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR],' *************************** Exception while setting NFS monitor details *************************** '+ repr(e))
            traceback.print_exc()
    
    def executeScript(self):
        dictToReturn = {}
        try:
            executorObj = AgentUtil.Executor()
            executorObj.setLogger(AgentLogger.CHECKS)
            executorObj.setTimeout(self.timeout)
            command = AgentConstants.AGENT_NFS_MONITORING_SCRIPT + " " + self.path
            AgentLogger.log(AgentLogger.CHECKS,'NFS Command is '+repr(command))
            executorObj.setCommand(command)
            executorObj.executeCommand()
            dictToReturn['status'] = executorObj.isSuccess()
            retVal = executorObj.getReturnCode()
            if not ((retVal == 0) or (retVal is not None)):
                dictToReturn['timeout'] = True
            dictToReturn['output'] = executorObj.getStdOut()
            dictToReturn['error'] = AgentUtil.getModifiedString(executorObj.getStdErr(),100,100)
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR],'*************************** Exception while NFS monitor execution *************************** '+ repr(e))
            traceback.print_exc()
        finally:
            AgentLogger.log(AgentLogger.CHECKS,'data collection after script execution for NFS'+repr(dictToReturn))
            return dictToReturn
    
    def parseStatsFile(self,filename):
        ms_dict = dict()
        key = ''
    
        #f = file(filename)
        f = open(filename)
        for line in f.readlines():
        #print line
            words = line.split()
            if len(words) == 0:
                continue
            if words[0] == 'device':
                key = words[4]
                new = [ line.strip() ]
            elif 'nfs' in words or 'nfs4' in words:
                key = words[3]
                new = [ line.strip() ]
            else:
                new += [ line.strip() ]
            ms_dict[key] = new
        f.close
        return ms_dict
    
    def nfsDC(self):#to be called from script handler
        dcData = {}
        io_list=[]
        read = 0.0
        write = 0.0
        try:
            dcData = self.executeScript()
            try:
                if os.path.exists(AgentConstants.NFS_IO_FILE):
                    fileDt=self.parseStatsFile(AgentConstants.NFS_IO_FILE)
                    if self.path in fileDt:
                        json_arr=fileDt[self.path]
                        for data in json_arr:
                            if 'bytes:' in data:
                                ele=data
                                io_list=ele.split(' ')
                                break
                    if not io_list==[]:
                        firstEntry = io_list[0];
                        tempList = firstEntry.split(':')
                        io_list.pop(0)
                        io_list.insert(0,(str(tempList[1]).strip()))
                        read=float(io_list[0])+float(io_list[2])+float(io_list[4])+float(io_list[6])
                        write=float(io_list[1])+float(io_list[3])+float(io_list[5])+float(io_list[7])
            except Exception as e1:
                    AgentLogger.log(AgentLogger.CHECKS,'[ Exception While Manipulating IO Read / Write ] '+repr(e1))
                    traceback.print_exc()
            if dcData and dcData['status'] == True:
                if dcData['output'] != '-1\n':
                    parsedData = self.parseData(dcData['output'])
                    dcData['output'] = parsedData
                else:
                    dcData['output'] = 'No Mounting'
                    dcData['status'] = False
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR],'**********Exception while DC of NFS Monitoring********** '+repr(e))
            traceback.print_exc()
        finally:
            AgentLogger.log(AgentLogger.CHECKS,'[ DC Data after parsing ] '+repr(dcData))
            return dcData
    
    def parseData(self,dataToParse):
        listLineData = []
        parsedData = {}
        try:
            listLineData = dataToParse.split('\n')
            for eachLine in listLineData:
                temp = []
                temp = eachLine.split('%%')
                if len(temp) > 1:
                    parsedData[temp[0]] = int(temp[1])
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR],'********Exception while parsing NFS DC*****'+repr(e))
            traceback.print_exc()
        finally:
            AgentLogger.log(AgentLogger.CHECKS,'only parsed data '+repr(parsedData))
            return parsedData

class NFSHandler(DesignUtils.Singleton):
    _nfs = {}
    _lock = threading.Lock()
    
    def __init__(self):
        self._loadCustomNFS()
    
    def _loadCustomNFS(self):
        try:
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(AgentConstants.AGENT_CUSTOM_MONITORS_GROUP_FILE)
            fileObj.set_dataType('json')
            fileObj.set_mode('rb')
            fileObj.set_dataEncoding('UTF-8')
            fileObj.set_loggerName(AgentLogger.CHECKS)
            fileObj.set_logging(False)
            bool_toReturn, dict_monitorsInfo = FileUtil.readData(fileObj)
            with self._lock:
                for each_nfs in dict_monitorsInfo['MonitorGroup']['ChecksMonitoring']['NFSMonitoring']:
                    nfs = NFS()
                    nfs.setNFSDetails(each_nfs)
                    self.__class__._nfs[each_nfs['id']] = nfs
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR], ' *************************** Exception while loading custom nfs for NFS monitoring  *************************** '+ repr(e))
            traceback.print_exc()
            
    def deleteAllNFS(self):
        try:
            for each_nfs in self.__class__._nfs:
                nfs = self.__class__._nfs[each_nfs]
                AgentLogger.log(AgentLogger.CHECKS,'Deleting NFS check with NFS id : '+repr(nfs.id))
            self.__class__._nfs.clear()
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR], ' CheckError | *************************** Exception while deleting NFS checks *************************** '+ repr(e))
            traceback.print_exc()
    
    def reloadNFS(self):
        with self._lock:
            self.deleteAllNFS()
        self._loadCustomNFS()
    
    def checkNFSDC(self):
        dictDataToSend = {}
        try:
            with self._lock:
                for nfsId, nfs in self.__class__._nfs.items():
                    tempDict = {}
                    AgentLogger.log(AgentLogger.CHECKS,'Start DC for NFS id:'+repr(nfsId))
                    tempDict = nfs.nfsDC()
                    dictDataToSend.setdefault(nfsId,tempDict)
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR],'************* Exception while DC of NFS****'+repr(e))
            traceback.print_exc()
        finally:
            return dictDataToSend