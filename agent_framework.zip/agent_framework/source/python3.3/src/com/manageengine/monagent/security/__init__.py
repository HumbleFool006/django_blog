#$Id$
BLOCK_SIZE = 32

CRYPT = None
SECRET_KEY = '123456789bcdefgha1b2c3d123ff.1ab' #32 characters
IV = '1ab2cd345ef..@@1' #16 characters

INTERRUPT = '\u0001'
PAD = '\u0000'