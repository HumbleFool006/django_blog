# $Id$
# Command To Fetch IpAddress From eth0 - /sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'
import os
import platform
import socket
import traceback
import subprocess

from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent import ifaddrs
from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.collector import DataCollector

def fetchDomainNameForLinux():
    try:
        executorObj = AgentUtil.Executor()
        executorObj.setTimeout(2)
        executorObj.setCommand('dnsdomainname')
        executorObj.executeCommand()
        output = executorObj.getStdOut()
        AgentLogger.log(AgentLogger.STDOUT,'Domain Name '+repr(output))
        if not output == None and output!='':
            AgentConstants.DOMAIN_NAME = output.rstrip("\n")
        else:
            AgentLogger.log(AgentLogger.CRITICAL,'Domain Name not found '+repr(output))
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.STDERR],'Exception Occured while fetching dns domain name ')
        traceback.print_exc()
    
def populateHostInfo():
    str_macAddress = '00:00:00:00:00:00'
    str_hostIpAddress = '127.0.0.1'
    computerNameWithDNS = None
    isDummyHostName = False
    try:
        (computerNameWithDNS, aliasList, ipList) = socket.gethostbyaddr(socket.gethostname())
    except Exception as e:
        AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception While fetching host name in HostHandler *************************** '+ repr(e))
        traceback.print_exc()
        isDummyHostName = True
        try:
            computerNameWithDNS=str(subprocess.check_output("hostname",timeout=5).decode('UTF-8').rstrip('\n'))
        except:
            AgentLogger.log(AgentLogger.CRITICAL, ' *************************** Exception While fetching host name in command execution ************************')
            traceback.print_exc()
            import random
            computerNameWithDNS=str(random.randint(1,99999))
    if not isDummyHostName: 
        AgentConstants.HOST_NAME = platform.node()
    else:
        AgentConstants.HOST_NAME = computerNameWithDNS
    AgentConstants.HOST_FQDN_NAME = computerNameWithDNS
    dict_hostIntfDetails = ifaddrs.getifaddrs()
    #AgentLogger.log(AgentLogger.MAIN,'Host Details Obtained From Native Library :'+repr(dict_hostIntfDetails))
    str_hostIpAddress = getHostIpAddress()
    if str_hostIpAddress == None and AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '0' and AgentUtil.AGENT_CONFIG.defaults().get('discover_host') == 'false':
        AgentConstants.IP_ADDRESS = str_hostIpAddress
        AgentConstants.MAC_ADDRESS = str_macAddress
        return True        
    elif str_hostIpAddress == None and AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '0':
        AgentLogger.log(AgentLogger.CRITICAL,' ********************* Unable To Populate Host Info Since Ip Address Is None ********************** ')
        return False
    elif not AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '0':
        AgentConstants.IP_ADDRESS = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address')
        str_hostIpAddress = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address')
    for str_intfName in dict_hostIntfDetails:
        dict_addressDetails = dict_hostIntfDetails[str_intfName]
        if 2 in dict_addressDetails and 'addr' in dict_addressDetails[int('2')] and dict_addressDetails[int('2')]['addr'] == str_hostIpAddress:
            if 17 in dict_addressDetails and 'addr' in dict_addressDetails[int('17')]:
                str_macAddress = dict_addressDetails[int('17')]['addr']
            AgentLogger.log(AgentLogger.STDOUT,'Host Primary Interface :'+str_intfName+', Ip Address : '+str_hostIpAddress+', MAC Address : '+str_macAddress)
            break
    if str_macAddress == None and AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address') == '0' and AgentUtil.AGENT_CONFIG.defaults().get('discover_host') == 'false':
        AgentConstants.MAC_ADDRESS = None
        return True
    elif str_macAddress == None and AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address') == '0':
        AgentLogger.log(AgentLogger.CRITICAL,' ********************* Unable To Populate Host Info Since MAC Address Is None ********************** ')
        return False
    elif not AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address') == '0':
        AgentConstants.MAC_ADDRESS = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address')
        str_macAddress = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address')
    else:
        AgentConstants.IP_ADDRESS = str_hostIpAddress
        AgentConstants.MAC_ADDRESS = str_macAddress
    return True

class OSFactory:
    def __init__(self):
        AgentLogger.log(AgentLogger.STDOUT,"OS NAME ======> {0}".format(AgentConstants.OS_NAME))
        AgentLogger.log(AgentLogger.STDOUT,"OS NAME ======> {0}".format(AgentConstants.LINUX_OS))
        if AgentConstants.OS_NAME == AgentConstants.LINUX_OS:
            LinOS()
        elif AgentConstants.OS_NAME == AgentConstants.FREEBSD_OS:
            FreebsdOS()
        elif AgentConstants.OS_NAME == AgentConstants.OS_X:
            MacOs()
        else:
            AgentLogger.log([AgentLogger.MAIN,AgentLogger.CRITICAL],' ********************* AGENT DOES NOT SUPPORT \''+repr(AgentConstants.OS_NAME)+'\' OPERATING SYSTEM ********************** ')
            raise OSNotSupportedException  
        
class CollectorFactory:
    def __init__(self):
        DataCollector.COLLECTOR = DataCollector.UbuntuCollector(AgentConstants.LINUX_DIST)

class LinOS:
    def __init__(self):        
        (osFlavor, osVersion, osId) = platform.linux_distribution()    
        AgentConstants.OS_FLAVOR = osFlavor
        self.setUpgradeFileName()
    def setUpgradeFileName(self):
        AgentConstants.UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.LINUX_OS+'_'+AgentConstants.OS_ARCHITECTURE+'_Upgrade.tar.gz'
        AgentConstants.AGENT_UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.LINUX_OS+'_'+AgentConstants.OS_ARCHITECTURE+'_Agent_Upgrade.tar.gz'
        AgentConstants.WATCHDOG_UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.LINUX_OS+'_'+AgentConstants.OS_ARCHITECTURE+'_Watchdog_Upgrade.tar.gz'

class FreebsdOS:
    def __init__(self):
        osDetails = os.uname()
        if osDetails:
            osFlavor = osDetails.sysname
            osVersion = osDetails.release  
        else:
            osFlavor = AgentConstants.FREEBSD_OS
        #(osFlavor, osVersion, osId) = platform.linux_distribution()    
        AgentConstants.OS_FLAVOR = osFlavor
        self.setUpgradeFileName()
        self.setUserAgentName()
    def setUpgradeFileName(self):
        if AgentConstants.OS_VERSION_ARCH:
            AgentConstants.UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.FREEBSD_OS+'_'+AgentConstants.OS_VERSION_ARCH+'_Upgrade.tar.gz'
            AgentConstants.AGENT_UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.FREEBSD_OS+'_'+AgentConstants.OS_VERSION_ARCH+'_Agent_Upgrade.tar.gz'
            AgentConstants.WATCHDOG_UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.FREEBSD_OS+'_'+AgentConstants.OS_VERSION_ARCH+'_Watchdog_Upgrade.tar.gz'
        else:
            AgentConstants.UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.FREEBSD_OS+'_bsd10_64bit_Upgrade.tar.gz'
            AgentConstants.AGENT_UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.FREEBSD_OS+'_bsd10_64bit_Agent_Upgrade.tar.gz'
            AgentConstants.WATCHDOG_UPGRADE_FILE_NAME = AgentConstants.PRODUCT_NAME+'_'+AgentConstants.FREEBSD_OS+'_bsd10_64bit_Watchdog_Upgrade.tar.gz'
    def setUserAgentName(self):
        if AgentConstants.OS_NAME:
            AgentConstants.AGENT_NAME = AgentConstants.PRODUCT_NAME + ' ' + AgentConstants.FREEBSD_OS + ' Agent'

class MacOs:
    def __init__(self):        
        AgentConstants.OS_FLAVOR = AgentConstants.OS_X
        self.setUpgradeFileName()
    def setUpgradeFileName(self):
        AgentConstants.UPGRADE_FILE_NAME = 'Site24x7_OS_X_Agent.zip'
        AgentConstants.AGENT_UPGRADE_FILE_NAME = 'Site24x7Agent.app'
        AgentConstants.WATCHDOG_UPGRADE_FILE_NAME = ''


class OSNotSupportedException(Exception):
    def __init__(self):
        self.message = 'OS Not Supported Exception'
    def __str__(self):
        return self.message

def initialize():
    bool_isSuccess = True
    bool_isAgentInfoModified = False
    try:        
        str_osName = platform.system()    
        str_architecture = platform.architecture()[0] 
        AgentLogger.log(AgentLogger.STDOUT,'OPERATING SYSTEM : '+str_osName)
        if str_osName.lower() == AgentConstants.LINUX_OS_LOWERCASE:
            AgentConstants.OS_NAME = AgentConstants.LINUX_OS
        elif str_osName.lower() == AgentConstants.FREEBSD_OS_LOWERCASE:
            AgentConstants.OS_NAME = AgentConstants.FREEBSD_OS
        elif str_osName == 'Darwin':
            AgentConstants.OS_NAME = AgentConstants.OS_X
        else:
            AgentConstants.OS_NAME = str_osName
        
        if '32' in str_architecture:
            AgentConstants.OS_ARCHITECTURE = AgentConstants.THIRTY_TWO_BIT
        elif '64' in str_architecture:
            AgentConstants.OS_ARCHITECTURE = AgentConstants.SIXTY_FOUR_BIT
        else:
            AgentConstants.OS_ARCHITECTURE = platform.architecture()[0]
        OSFactory()
        CollectorFactory()
        if not populateHostInfo():
            return False
        if AgentConstants.OS_NAME == AgentConstants.LINUX_OS:
            fetchDomainNameForLinux()
        AgentLogger.log(AgentLogger.MAIN,'========================== HOST AND OS DETAILS ========================== \n')
        if AgentConstants.IP_ADDRESS == None or AgentConstants.IP_ADDRESS == '0':
            AgentConstants.IP_ADDRESS = '127.0.0.1'
        if AgentConstants.MAC_ADDRESS == None or AgentConstants.MAC_ADDRESS == '0':
            AgentConstants.MAC_ADDRESS = '00:00:00:00:00:00'
        AgentLogger.log(AgentLogger.MAIN,'HOST_NAME : '+repr(AgentConstants.HOST_NAME)+' HOST_FQDN_NAME : '+repr(AgentConstants.HOST_FQDN_NAME)+' IP_ADDRESS : '+repr(AgentConstants.IP_ADDRESS)+' MAC_ADDRESS : '+repr(AgentConstants.MAC_ADDRESS)+' CUSTOMER_ID : '+ str(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id'))+' OS_NAME : '+repr(AgentConstants.OS_NAME)+' OS_FLAVOR : '+repr(AgentConstants.OS_FLAVOR)+' OS_ARCHITECTURE : '+repr(AgentConstants.OS_ARCHITECTURE)+'\n')
        if AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '0':
            AgentLogger.log(AgentLogger.STDOUT,'Modifying AGENT_IP_ADDRESS '+repr(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address'))+' In Conf File To '+' : '+repr(AgentConstants.IP_ADDRESS))
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_ip_address', AgentConstants.IP_ADDRESS)            
            bool_isAgentInfoModified = True
        if AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address') == '0':
            AgentLogger.log(AgentLogger.STDOUT,'Modifying AGENT_MAC_ADDRESS '+repr(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_mac_address'))+' In Conf File To '+' : '+repr(AgentConstants.MAC_ADDRESS))            
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_mac_address', AgentConstants.MAC_ADDRESS)
            bool_isAgentInfoModified = True
        if bool_isAgentInfoModified:
            AgentUtil.persistAgentInfo()
        #AgentLogger.log(AgentLogger.MAIN,'==================================================================')
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL,AgentLogger.MAIN], ' *************************** Exception While Initializing HostHandler *************************** '+ repr(e))
        traceback.print_exc()
        bool_isSuccess = False
    return bool_isSuccess


def getHostIpAddress():
    hostIpAddress = '127.0.0.1'
    if hostIpAddress == None or hostIpAddress == '127.0.0.1' or hostIpAddress == '0.0.0.0':
        isSuccess, hostIpAddress = CommunicationHandler.pingServer(AgentLogger.MAIN)
        AgentLogger.log(AgentLogger.MAIN, 'Agent Ip Address Obtained By Pinging Server : '+repr(hostIpAddress)+'\n')
        if hostIpAddress == None or hostIpAddress == '127.0.0.1' or hostIpAddress == '0.0.0.0': 
            if AgentConstants.OS_NAME in AgentConstants.OS_SUPPORTED:
                hostIpAddress = linux_getIpAddress()
                if not hostIpAddress == None and not hostIpAddress == '127.0.0.1' and not hostIpAddress == '0.0.0.0':
                    AgentLogger.log(AgentLogger.MAIN, 'Agent Ip Address Obtained From /sbin/ifconfig : '+repr(hostIpAddress))                    
    if not AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '0' and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '127.0.0.1' and not AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address') == '0.0.0.0':
        AgentLogger.log(AgentLogger.MAIN, 'Agent Ip Address From Conf File : '+repr(AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address')))
        ipAddressFromConf = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_ip_address')
        if hostIpAddress == ipAddressFromConf:
            AgentLogger.log(AgentLogger.STDOUT,'IP address obtained and IP address present in config file are same')
            hostIpAddress = ipAddressFromConf
        else:
            AgentLogger.log(AgentLogger.MAIN,'IP address obtained and IP address present in config file are not same')
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO', 'agent_ip_address',hostIpAddress)
            AgentUtil.persistAgentInfo()
    return hostIpAddress

def linux_getIpAddress():
    str_macAddress = '00:00:00:00:00:00'
    str_ipAddress = '127.0.0.1'
    str_diskDetailsCommand = '/sbin/ifconfig -a'
    (bool_isSuccess,str_Output) = AgentUtil.executeCommand(str_diskDetailsCommand)
    AgentLogger.log(AgentLogger.STDOUT, 'Command output : '+repr(bool_isSuccess)+'\n'+str_Output)
    if bool_isSuccess:
        list_OutputLines = str_Output.split('\n')
        #print 'list_OutputLines : ',list_OutputLines
        for str_OutputLine in list_OutputLines:
            if str_macAddress == '00:00:00:00:00:00':
                int_ethernet0Index = str_OutputLine.find('eth0')
                if not int_ethernet0Index == -1:
                    str_macAddress = str_OutputLine[str_OutputLine.find('HWaddr')+6 :].strip()                            
                    AgentLogger.log(AgentLogger.STDOUT,'/sbin/ifconfig Mac address : '+str_macAddress)                    
                    continue
            if not str_macAddress == '00:00:00:00:00:00' and str_ipAddress == '127.0.0.1':                
                int_inetAddrIndex = str_OutputLine.find('inet addr:')
                if not int_inetAddrIndex == -1:
                    str_ipAddress = str_OutputLine[int_inetAddrIndex+10 :].split()[0]
                    AgentLogger.log(AgentLogger.STDOUT,'/sbin/ifconfig Ip Address : '+ str_ipAddress)
                    return str_ipAddress                                   
    else:
        AgentLogger.log(AgentLogger.STDOUT,'Error While Executing Command For Fetching Linux OS IpAddress')
    return str_ipAddress
        
        
