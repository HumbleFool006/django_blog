# $Id$
import os
import sys
import shutil
import codecs
import time
import threading
import traceback
import json
import math
import zipfile
import copy
import configparser
import subprocess, signal
import xml.etree.ElementTree as xml
import collections
import re
from urllib.parse import urlencode
from datetime import datetime

import com
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentBuffer
from com.manageengine.monagent.util import DesignUtils
# Process exit codes
# http://stackoverflow.com/questions/1101957/are-there-any-standard-exit-status-codes-in-linux


AGENT_CONFIG = configparser.RawConfigParser()

AGENT_PARAMS = {"AGENT_FILE_ID": "0", "AGENT_ZIP_ID": "0"}

ZipUtil = None
FileUtil = None
ZipInfoUtil = None

TERMINATE_AGENT = False
TERMINATE_AGENT_NOTIFIER = threading.Event()


def initialize():
    global ZipUtil, FileUtil
    ZipUtil = ZipHandler()
    FileUtil = FileHandler()
    ZipInfoUtil = FileZipAndUploadInfo()

def persistAgentParams():
    if not AGENT_PARAMS == None:        
        if not writeDataToFile(AgentConstants.AGENT_PARAMS_FILE, AGENT_PARAMS):
            AgentLogger.log(AgentLogger.STDOUT,'************************* Problem while Persisting Agent Params *************************') 
    else:
        AgentLogger.log(AgentLogger.STDOUT,'************************* Agent Params Not Populated *************************')

def backupConfFile():
    try:        
        AgentLogger.log(AgentLogger.STDOUT,'Taking backup of the configuration file : '+repr(AgentConstants.AGENT_CONF_FILE)+' to : '+repr(AgentConstants.AGENT_CONF_BACKUP_FILE))
        shutil.copy(AgentConstants.AGENT_CONF_FILE, AgentConstants.AGENT_CONF_BACKUP_FILE)
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while taking backup of the configuration file : '+repr(AgentConstants.AGENT_CONF_FILE)+' ************************* ')
        traceback.print_exc()  
        
def isWarmShutdown():
    try:
        if not os.path.exists(AgentConstants.AGENT_SHUTDOWN_FLAG_FILE):
            AgentLogger.log(AgentLogger.STDOUT,'AGENT_SHUTDOWN_FLAG_FILE is not present. Setting AGENT_WARM_SHUTDOWN = False')
            AgentConstants.AGENT_WARM_SHUTDOWN = False
        else:
            AgentLogger.log(AgentLogger.STDOUT,'AGENT_SHUTDOWN_FLAG_FILE is present. Setting AGENT_WARM_SHUTDOWN = True')
    except Exception as e:
        AgentLogger.log([AgentLogger.CRITICAL],' ************************* Exception while setting AGENT_WARM_SHUTDOWN variable ************************* ')
        traceback.print_exc()
    finally:
        FileUtil.deleteFile(AgentConstants.AGENT_SHUTDOWN_FLAG_FILE)

def handleSpecialTasks():
    try:
        if AgentConstants.MON_AGENT_UPGRADED:
            AgentLogger.log(AgentLogger.STDOUT,'================================= HANDLE SPECIAL TASKS =================================')
            com.manageengine.monagent.collector.DataCollector.ProcessUtil.updateProcessDetailsForAgentVersionsBelow11_0_0()
            com.manageengine.monagent.communication.UdpHandler.SysLogUtil.editSyslogConfiguration()
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT, AgentLogger.STDERR],' ************************* Exception while handling special tasks ************************* ')
        traceback.print_exc()
        
def updateShutdownTime():
    str_shutdownTime = 'Shutdown at '+repr(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"))
    fileObj = FileObject()
    fileObj.set_filePath(AgentConstants.AGENT_SHUTDOWN_FLAG_FILE)
    fileObj.set_data(str_shutdownTime)
    fileObj.set_loggerName(AgentLogger.MAIN)
    FileUtil.saveData(fileObj)
        
        
def shutdownAgent(signum, frame):
    try:  
        AgentLogger.log(AgentLogger.MAIN,'Received Shutdown Notification : \n')
        shutdownTime = getCurrentTimeInMillis()
        updateShutdownTime()
        if not (com.manageengine.monagent.upgrade.AgentUpgrader.UPGRADE or os.path.exists(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE)):
            com.manageengine.monagent.communication.AgentStatusHandler.notifyShutdown(shutdownTime)
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Server is not notified - upgrade ' +repr(com.manageengine.monagent.upgrade.AgentUpgrader.UPGRADE))
            AgentLogger.log(AgentLogger.STDOUT,'Watch dog restart flag file : '+repr(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE))

        
        com.manageengine.monagent.util.rca.RcaHandler.backupRCAReport(AgentConstants.AGENT_TEMP_RCA_REPORT_DIR)
        TerminateAgent()
        cleanAll()
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT, AgentLogger.STDERR],'*************************** Exception while handling shutdown notification *************************** '+ repr(e))
        traceback.print_exc()
        
def shutdownListener():
    signal.signal(signal.SIGTERM, shutdownAgent)
    #atexit.register(shutdownHandler)

def persistAgentInfo():
    AgentLogger.log(AgentLogger.STDOUT,'================================= PERSISTING AGENT INFO =================================')
    list_sections = AGENT_CONFIG.sections()
    for sec in list_sections:
        for key, value in AGENT_CONFIG.items(sec):
            if value == None:
                value = '0'
                AGENT_CONFIG.set(sec, key, value)
            AgentLogger.log(AgentLogger.STDOUT,'AGENT CONSTANTS : '+key+' : '+repr(value))
    confFile = open(AgentConstants.AGENT_CONF_FILE,"w") 
    AGENT_CONFIG.write(confFile)   

def persistProfile(str_fileName, dict_content):
    bool_toReturn = True
    str_dataToWrite = ''
    file_obj = None
    try:
        AgentLogger.log(AgentLogger.STDOUT,'Persisting the profile data : '+repr(dict_content)+' in the file : '+repr(str_fileName))
        for key in dict_content:
            str_dataToWrite += key
            str_dataToWrite += '='
            str_dataToWrite += dict_content[key]            
            str_dataToWrite += ';export '
            str_dataToWrite += key
            str_dataToWrite += '\n'
        try:
            if str_dataToWrite != '':  
                file_obj = open(str_fileName, 'w')
                file_obj.write(str_dataToWrite)
                os.chmod(str_fileName, 0o755)
        except:
            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while saving profile data : '+repr(str_dataToWrite)+' To File '+str(str_fileName)+' ************************* ')
            traceback.print_exc()
            bool_toReturn = False
        finally:        
            if not file_obj == None:
                file_obj.close()
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while creating profile ************************* '+ repr(e))
        traceback.print_exc()
        bool_toReturn = False
    return bool_toReturn   

def getAgentVersion():
    bool_returnStatus = True
    file_obj = None
    str_agentVersion = None
    try:
        file_obj = open(AgentConstants.AGENT_VERSION_FILE,'r')
        str_agentVersion = file_obj.read()
        if "\n" in str_agentVersion:
            str_agentVersion = str_agentVersion.replace("\n","") 
    except:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while reading agent version from the file '+AgentConstants.AGENT_VERSION_FILE+' ************************* ')
        traceback.print_exc()
        bool_returnStatus = False
    finally:
        if not file_obj == None:
            file_obj.close()
    if bool_returnStatus:
        AgentLogger.log(AgentLogger.STDOUT,'Agent version : '+repr(str_agentVersion)+' from the file : '+AgentConstants.AGENT_VERSION_FILE)
    return bool_returnStatus, str_agentVersion

def getAgentBuildNumber():
    bool_returnStatus = True
    file_obj = None
    str_agentBno = None
    try:
        file_obj = open(AgentConstants.AGENT_BUILD_NUMBER_FILE,'r')
        str_agentBno = file_obj.read()   
    except:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while reading agent version from the file '+AgentConstants.AGENT_BUILD_NUMBER_FILE+' ************************* ')
        traceback.print_exc()
        bool_returnStatus = False
    finally:
        if not file_obj == None:
            file_obj.close()
    if bool_returnStatus:
        AgentLogger.log(AgentLogger.STDOUT,'Agent build number : '+repr(str_agentBno)+' from the file : '+AgentConstants.AGENT_BUILD_NUMBER_FILE)
    return bool_returnStatus, str_agentBno

class Executor:
    def __init__(self):
        self.__str_command = None
        self.__int_timeout = 5
        self.__str_loggerName = AgentLogger.STDOUT
        self.__bool_redirectToFile = False
        self.__str_stdout = None
        self.__str_stderr = None
        self.__str_outputEncoding = 'UTF-8'
        self.__bool_isSuccess = False
        self.__str_customNameForOutputFile = 'Temp_Raw_Data'
        self.__str_ouputFilePath = None
        self.__str_commandExecuted = None
        self.__returnCode = None
    def setCommand(self, str_command):
        self.__str_command = str_command
    def getCommand(self):
        return self.__str_command
    def getCommandExecuted(self):
        return self.__str_commandExecuted
    def setTimeout(self, int_timeout):
        self.__int_timeout = int_timeout
    def getTimeout(self):
        return self.__int_timeout
    def setLogger(self, str_loggerName):
        self.__str_loggerName = str_loggerName
    def getLogger(self):
        return self.__str_loggerName
    def redirectToFile(self, bool_redirectToFile):
        self.__bool_redirectToFile = bool_redirectToFile
    def getRedirectToFile(self):
        return self.__bool_redirectToFile
    def getStdOut(self):
        return self.__str_stdout
    def getStdErr(self):
        return self.__str_stderr
    def getReturnCode(self):
        return self.__returnCode
    def setOutputEncoding(self, str_outputEncoding):
        self.__str_outputEncoding = str_outputEncoding
    def getOutputEncoding(self):
        return self.__str_outputEncoding
    def isSuccess(self):
        return self.__bool_isSuccess
    def setCustomNameForOutputFile(self, str_customNameForOutputFile):
        self.__str_customNameForOutputFile = str_customNameForOutputFile
    def getCustomNameForOutputFile(self):
        return self.__str_customNameForOutputFile
    def getOutputFilePath(self):
        return self.__str_ouputFilePath
    def __captureOutput(self, process):
        isSuccess = False
        out, err = process.communicate()
        self.__returnCode = process.returncode
        if ((process.returncode is not None) and (process.returncode not in AgentConstants.SCRIPT_ERROR_CODES)):
            AgentLogger.debug(self.__str_loggerName,'Return Code : '+str(process.returncode)+' Command \''+str(self.__str_commandExecuted)+'\' executed successfully')
            isSuccess = True
        else:
            AgentLogger.debug(self.__str_loggerName,'Return Code : '+str(process.returncode)+' Error while executing the command \''+str(self.__str_commandExecuted)+'\'')
            isSuccess = False  
        return isSuccess, out, err
    def executeCommand(self):    
        bool_isSuccess = False
        str_CommandOutput = None
        str_ErrorOutput = None
        int_timeoutCounter = 0
        isTerminated = False
        int_timeout = self.__int_timeout
        str_loggerName = self.__str_loggerName
        try:
            if self.__bool_redirectToFile:
                str_fileName = FileUtil.getUniqueFileName(AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), self.__str_customNameForOutputFile)
                self.__str_ouputFilePath = AgentConstants.AGENT_TEMP_RAW_DATA_DIR +'/'+str_fileName
                self.__str_commandExecuted = self.__str_command + ' > '+ '"'+self.__str_ouputFilePath+'"'
            else:
                self.__str_commandExecuted = self.__str_command
            list_commandArgs = [self.__str_commandExecuted]
            proc = subprocess.Popen(list_commandArgs, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, preexec_fn=os.setsid)
            processId = proc.pid
            while int_timeoutCounter <= int_timeout:      
                int_timeoutCounter +=.5                
                time.sleep(.5)
                AgentLogger.debug(str_loggerName,' Polling process, Return Code : '+str(proc.poll()))
                if proc.poll() is not None:
                    bool_isSuccess, byte_CommandOutput, byte_ErrorOutput = self.__captureOutput(proc)
                    str_CommandOutput = byte_CommandOutput.decode(self.__str_outputEncoding)
                    str_ErrorOutput = byte_ErrorOutput.decode(self.__str_outputEncoding)
                    isTerminated = True
                    break
            if not isTerminated:
                AgentLogger.log([str_loggerName,AgentLogger.MAIN],' Process Failed To Terminate, Hence issuing \'kill\' command')   
                os.killpg(processId, signal.SIGKILL)              
        except Exception as e:
            AgentLogger.log([str_loggerName,AgentLogger.MAIN],'***************************** Exception while executing command : '+str(self.__str_commandExecuted)+' *****************************')
            traceback.print_exc()
        finally:   
            self.__bool_isSuccess = bool_isSuccess
            self.__str_stdout = str_CommandOutput
            self.__str_stderr = str_ErrorOutput

def executeCommand(str_command, str_loggerName=AgentLogger.STDOUT, int_timeout=5):    
    bool_isSuccess = False
    str_CommandOutput = None
    int_timeoutCounter = 0
    isTerminated = False
    def captureOutput(process):
        isSuccess = False
        out, err = process.communicate()
        if process.returncode is not None:
            AgentLogger.debug(str_loggerName,'Return Code : '+str(process.returncode)+' Command \''+str(str_command)+'\' executed successfully')
            isSuccess = True
            output = out
        else:
            AgentLogger.debug(str_loggerName,'Return Code : '+str(process.returncode)+' Error while executing the command \''+str(str_command)+'\'')
            isSuccess = False
            output = err    
        return isSuccess, output
    list_commandArgs = [str_command]
    proc = subprocess.Popen(list_commandArgs, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, preexec_fn=os.setsid)
    processId = proc.pid    
    try:
        while int_timeoutCounter <= int_timeout:      
            int_timeoutCounter +=.5                
            time.sleep(.5)
            AgentLogger.debug(str_loggerName,' Polling process, Return Code : '+str(proc.poll()))
            if proc.poll() is not None:
                bool_isSuccess, byte_CommandOutput = captureOutput(proc)
                str_CommandOutput = byte_CommandOutput.decode('UTF-8')
                isTerminated = True
                break
        if not isTerminated:
            AgentLogger.log(str_loggerName,' Process Failed To Terminate, Hence issuing \'kill\' command')   
            os.killpg(processId, signal.SIGKILL)     
    except Exception as e:
        AgentLogger.log(str_loggerName,'***************************** Exception while executing command : '+str(str_command)+' *****************************')
        traceback.print_exc()        
    return bool_isSuccess, str_CommandOutput

def writeDataToFile(str_fileName, dic_DataToWrite):
    bool_toReturn = True
    file_obj = None
    try:
        file_obj = open(str_fileName,'w')
        json.dump(dic_DataToWrite, file_obj)        
    except:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception While Writing Data : '+repr(dic_DataToWrite)+' To File '+str_fileName+' ************************* ')
        traceback.print_exc()
        bool_toReturn = False
    finally:        
        if not file_obj == None:
            file_obj.close() 
    return bool_toReturn

def writeUnicodeDataToFile(str_fileName, dic_DataToWrite):
    bool_toReturn = True
    file_obj = None
    try:       
        file_obj = codecs.open(str_fileName,'w','UTF-16')
        file_obj.write(str(dic_DataToWrite))  
    except:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception While Writing Data : '+repr(dic_DataToWrite)+' To File '+str_fileName+' ************************* ')
        traceback.print_exc()
        bool_toReturn = False
    finally:        
        if not file_obj == None:
            file_obj.close() 
    return bool_toReturn
        
def loadDataFromFile(str_fileName):
    bool_returnStatus = True
    file_obj = None
    dic_dataToReturn = None
    try:
        file_obj = open(str_fileName,'r')
        dic_dataToReturn = json.load(file_obj,object_pairs_hook=collections.OrderedDict)    
    except:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception While Loading Data From File '+str_fileName+' ************************* ')
        traceback.print_exc()
        bool_returnStatus = False
    finally:
        if not file_obj == None:
            file_obj.close() 
    return bool_returnStatus, dic_dataToReturn

def loadUnicodeDataFromFile(str_fileName):
    bool_returnStatus = True
    file_obj = None
    dic_dataToReturn = None
    try:
        file_obj = open(str_fileName,'rb')
        byte_data = file_obj.read()
        unicodeData = byte_data.decode('UTF-16')
        dic_dataToReturn = json.loads(unicodeData)
    except:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception While Loading Unicode Data From File '+str_fileName+' ************************* ')
        traceback.print_exc()
        bool_returnStatus = False
    finally:
        if not file_obj == None:
            file_obj.close() 
    return bool_returnStatus, dic_dataToReturn

def convertXmlToMap(str_fileName):
    dict_toReturn = {}
    try:         
        tree = xml.parse(str_fileName)
        for node in tree.iter(): 
            dict_toReturn[node.tag] = node.text
    except Exception as e:
        print(' ************************* Exception While Converting XML Data To Map From The File : '+str_fileName+' ************************* '+repr(e))
        traceback.print_exc()
        dict_toReturn = None
    return dict_toReturn

def loadMonitorsXml(str_fileName):
    dict_toReturn = collections.OrderedDict()
    try:         
        tree = xml.parse(str_fileName)
        def getChildTags(node):
            list_childTags = None
            if len(list(node))>0:
                list_childTags = []
                for elem in list(node):                    
                    list_childTags.append(elem.tag)
            return list_childTags
        str_rootTag = None   
        str_parentTag = None
        str_monitorTagId = None
        list_rootChildTags = None     
        for node in tree.iter():            
            if node.tag == 'MonitorsXml':
                str_rootTag = node.tag
                dict_toReturn[str_rootTag] = collections.OrderedDict()
                dict_toReturn[str_rootTag]['Attributes'] = node.attrib
                list_rootChildTags = getChildTags(node)                
            elif node.tag in list_rootChildTags:
                dict_toReturn[str_rootTag][node.tag] = collections.OrderedDict()
                dict_toReturn[str_rootTag][node.tag]['Attributes'] = node.attrib
                str_parentTag = node.tag
            elif node.tag == 'Monitor':
                str_monitorTagId = node.attrib['Id']
                dict_toReturn[str_rootTag][str_parentTag][str_monitorTagId] = collections.OrderedDict()
                dict_toReturn[str_rootTag][str_parentTag][str_monitorTagId]['Attributes'] = node.attrib
                dict_toReturn[str_rootTag][str_parentTag][str_monitorTagId]['Entities'] = collections.OrderedDict()
            elif node.tag == 'Entity':
                str_entityId = node.attrib['Id']
                dict_toReturn[str_rootTag][str_parentTag][str_monitorTagId]['Entities'][str_entityId] = node.attrib   
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' ************************* Exception While Loading Monitors From The XML File : '+str_fileName+' ************************* '+repr(e))
        traceback.print_exc()
        dict_toReturn = None
    return dict_toReturn

def convertDataToDictionary(str_filePath):
    bool_toReturn = True        
    fileSysEncoding = sys.getfilesystemencoding()
    file_obj = None
    dict_toReturn = None
    try:            
        if os.path.isfile(str_filePath):                
            file_obj = open(str_filePath,'rb')
            byte_data = file_obj.read()
            str_data = byte_data.decode(fileSysEncoding)
            dict_toReturn = json.loads(str_data)#String to python object (dictionary)
        else:
            bool_toReturn = False
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception While Reading The file '+repr(str_filePath)+' ************************* '+ repr(e))
        traceback.print_exc()      
        bool_toReturn = False          
    finally:
        if file_obj:
            file_obj.close()
    return bool_toReturn, dict_toReturn

def getModifiedString(strData,initial,last):
    returnStr = strData
    try:
        if strData:
            if len(strData) > int(initial) + int(last):
                returnStr = strData[:initial] + "....." + strData[len(strData) - last:]
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' ************************* Exception while creating modified string ************************* '+ repr(e))
        traceback.print_exc()
    finally:
        return returnStr

def getTimeInMillis(float_timeInMillis = None, timeDiff = None):
    ''' With time_diff by default '''
    
    toReturn = None
    try:
        if float_timeInMillis and timeDiff:
            toReturn = round(float(float_timeInMillis)+float(timeDiff))
        elif float_timeInMillis:
            toReturn = round(float(float_timeInMillis)+float(AGENT_CONFIG.get('AGENT_INFO', 'time_diff')))
        else:
            toReturn = round((time.time()*1000)+float(AGENT_CONFIG.get('AGENT_INFO', 'time_diff')))
        AgentLogger.debug(AgentLogger.STDOUT,'Time in millis returned : '+repr(toReturn)+' ----> '+repr(getFormattedTime(toReturn)))
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' ************************* Exception while calculating time based on time diff ************************* '+ repr(e))
        traceback.print_exc()      
        toReturn = round(time.time()*1000)
    return toReturn

def getCurrentTimeInMillis(float_timeInMillis = None, timeDiff = None):
    ''' Without time_diff by default '''
    
    toReturn = None
    try:
        if float_timeInMillis and timeDiff:
            toReturn = round(float(float_timeInMillis)-float(timeDiff))
        elif float_timeInMillis:
            toReturn = round(float(float_timeInMillis)-float(AGENT_CONFIG.get('AGENT_INFO', 'time_diff')))
        else:
            toReturn = round(time.time()*1000)
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' ************************* Exception while calculating current time based on time diff ************************* '+ repr(e))
        traceback.print_exc()      
        toReturn = round(time.time()*1000)
    return toReturn

def getFormattedTime(timeInMillis):
    return time.asctime(time.localtime(float(timeInMillis)/1000))

def getUniqueId():
    import random
    int_uniqueId = 0
    try:    
        int_uniqueId = int(str(random.randint(1,9))+str(getCurrentTimeInMillis())+str(random.randint(10,99)))
        AgentLogger.log(AgentLogger.STDOUT,'UNIQUE ID GENERATED : '+repr(int_uniqueId))
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],' ************************* Exception while generating unique Id ************************* '+ repr(e))
        traceback.print_exc()      
        int_uniqueId = 0
    return int_uniqueId


class ZipHandler(DesignUtils.Singleton):
    __zipId = 0
    __zipIdCounterLock = threading.Lock()
    __zipProcessLock = threading.Lock()
    def __init__(self):
        pass
    def getUniqueZipId(self):
        with ZipHandler.__zipIdCounterLock:
            ZipHandler.__zipId+=1
            if ZipHandler.__zipId - int(AGENT_PARAMS['AGENT_ZIP_ID']) >= 100:
                AGENT_PARAMS['AGENT_ZIP_ID'] = str(ZipHandler.__zipId)
                persistAgentParams()
            return ZipHandler.__zipId
    def setZipId(self, int_id):
        ZipHandler.__zipId = int_id
    def getUniqueZipFileName(self,var_agentKey,str_customName=None):
        if str_customName:
            return 'Agent_'+str(var_agentKey)+'_'+str(str_customName)+'.zip'
        else:
            return 'Agent_'+str(var_agentKey)+'_'+str(self.getUniqueZipId())+'.zip'
    def getUniquePluginZipFileName(self,var_agentKey,str_customName=None):
        if str_customName:
            return 'Plugins_'+str(var_agentKey)+'_'+str(str_customName)+'_'+str(self.getUniqueZipId())+'.zip'
        else:
            return 'Plugins_'+str(var_agentKey)+'_'+str(self.getUniqueZipId())+'.zip'
    # A Method to zip files in buffer
    # Each zip file has a max of 1000 files - This param is configurable
    # A call to this method will create a max of 30 zip files
    def zipFilesInBuffer(self):
        Max_Zip_Files_To_Be_Created = 30
        bool_toReturn = True        
        bool_isBufferEmpty = False
        #buffer_filesToZip = None
        buffer_ZipInfoObjects = None
        int_sizeOfInfoBuffer = 0
        int_noOfZipFiles = 0        
        MAX_FILES_IN_ZIP = 0
        try:
            #buffer_filesToZip = AgentBuffer.getBuffer('FILES_TO_ZIP_BUFFER')
            buffer_ZipInfoObjects = AgentBuffer.getBuffer('FILES_TO_ZIP_BUFFER')
            buffer_filesToUpload = AgentBuffer.getBuffer('FILES_TO_UPLOAD_BUFFER')
            #int_sizeOfBuffer = buffer_filesToZip.size()
            int_sizeOfInfoBuffer = buffer_ZipInfoObjects.size()
            if int_sizeOfInfoBuffer > 0:
                with ZipHandler.__zipProcessLock:
                    AgentLogger.log(AgentLogger.STDOUT,'================================= ZIPPING FILES IN BUFFER =================================')
                    AgentLogger.debug(AgentLogger.STDOUT,'Obtained zip lock')
                    MAX_FILES_IN_ZIP = len(com.manageengine.monagent.collector.DataCollector.COLLECTOR.getMonitors())-1
                    while not bool_isBufferEmpty and int_sizeOfInfoBuffer > 0 and int_noOfZipFiles < Max_Zip_Files_To_Be_Created and not TERMINATE_AGENT: # Temporary hack to ensure that this loop is not infinite in zipping                
                        int_noOfFilesAddedToZip = 0
                        zipFileName = None
                        zip_fileObj = None
                        bool_isZippingSuccess = True                
                        try:
                            #while int_noOfFilesAddedToZip < MAX_FILES_IN_ZIP and not TERMINATE_AGENT: # This loop will break when buffer is empty or maximum file count in a zip is reached                
                            fileName = None
                            str_fileToZipPath = None 
                            if buffer_ZipInfoObjects.size() > 0:
                                zipAndUploadInfo = FileZipAndUploadInfo()
                                zipAndUploadInfo = buffer_ZipInfoObjects.pop() 
                                list_fileNames = zipAndUploadInfo.filesToZip 
                                #list_fileNames = buffer_filesToZip.pop()  
                                int_sizeOfInfoBuffer-=1
                                if ((list_fileNames) and (len(list_fileNames) > 0)):
                                    #zipFileName = AgentConstants.AGENT_UPLOAD_DIR+'/'+self.getUniqueZipFileName(AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), getTimeInMillis())
                                    zipFileName = zipAndUploadInfo.zipFilePath
                                    zip_fileObj = zipfile.ZipFile(zipFileName, 'w')   
                                    for fileName in list_fileNames: 
                                        try:                            
                                            str_fileToZipPath = os.path.join(zipAndUploadInfo.str_fileToZipPath,fileName)
                                            if os.path.isfile(str_fileToZipPath):                                
                                                zip_fileObj.write(str_fileToZipPath,'data/'+fileName, zipfile.ZIP_DEFLATED)
                                                AgentLogger.log(AgentLogger.STDOUT,'File added to zip : ' + str(str_fileToZipPath))
                                                int_noOfFilesAddedToZip+=1
                                                os.remove(str_fileToZipPath)
                                        except Exception as e:
                                            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while writing the file : '+repr(str_fileToZipPath)+' to the zip file '+repr(zipFileName)+' ************************* '+repr(e))
                                            traceback.print_exc()
                                else:
                                    AgentLogger.log(AgentLogger.STDOUT,'No files to zip in the list fetched from buffer : ' + repr(list_fileNames)) 
                            else:
                                AgentLogger.log(AgentLogger.STDOUT,'Buffer is empty, hence no files to zip')
                                bool_isBufferEmpty = True
                                break
                            AgentLogger.debug(AgentLogger.STDOUT,str(int_noOfFilesAddedToZip)+' File(s) added to the zip file : '+zipFileName)
                            # Increment zip file count when zipping is success
                            int_noOfZipFiles+=1
                        except Exception as e:
                            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while zipping the file : '+str(zipFileName)+' ************************* '+repr(e))
                            traceback.print_exc()
                            bool_isZippingSuccess = False
                        finally:        
                            if not zip_fileObj == None:
                                zip_fileObj.close()
                            if zipFileName is not None and os.path.exists(zipFileName) and not bool_isZippingSuccess:
                                AgentLogger.log(AgentLogger.STDOUT,'Deleting the corrupted zip file :'+str(zipFileName))
                                try:
                                    os.remove(zipFileName)
                                except Exception as e:
                                    AgentLogger.log(AgentLogger.STDOUT,'************************* Exception while deleting the corrupted zip file :'+str(zipFileName)+' *************************')
                                    traceback.print_exc()
                            else:
                                AgentLogger.log([AgentLogger.STDOUT],'Adding the zipanduploadinfo object to upload buffer :'+str(zipAndUploadInfo.zipFileName))
                                buffer_filesToUpload.add(zipAndUploadInfo)
                                if com.manageengine.monagent.collector.DataCollector.UPLOAD_PAUSE_FLAG:
                                    AgentLogger.log(AgentLogger.STDOUT,' Current data collection zips generated. Hence switching to normal upload mode ')
                                    com.manageengine.monagent.collector.DataCollector.UPLOAD_PAUSE_FLAG = False
                                    com.manageengine.monagent.collector.DataCollector.UPLOAD_PAUSE_TIME = 0
                                AgentLogger.log(AgentLogger.STDOUT,'New object added in the upload buffer with a total of : ' + str(len(buffer_filesToUpload)) + 'zips')
                    AgentLogger.debug(AgentLogger.STDOUT,str(int_noOfZipFiles)+' Zip file(s) created in this zipping process')
        except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while zipping the files in the buffer : '+repr(buffer_ZipInfoObjects)+' ************************* '+repr(e))
            traceback.print_exc()
            bool_toReturn = False
        finally:
            AgentLogger.debug(AgentLogger.STDOUT,'Released zip lock')
        return bool_toReturn
    # A Method to zip files in data directory
    # Each zip file has a max of 1000 files - This param is configurable
    # A call to this method will create a max of 30 zip files
    def zipFilesInDataDirectory(self):
        Max_Zip_Files_To_Be_Created = 30
        bool_toReturn = True        
        bool_isDirEmpty = False        
        int_noOfZipFiles = 0       
        buffer_filesToZip = None
        MAX_FILES_IN_ZIP = 0         
        try:
            with ZipHandler.__zipProcessLock:
                AgentLogger.log(AgentLogger.STDOUT,'===================================== ZIPPING FILES IN DATA DIRECTORY =====================================')
                AgentLogger.debug(AgentLogger.STDOUT,'Obtained zip lock')
                MAX_FILES_IN_ZIP = len(com.manageengine.monagent.collector.DataCollector.COLLECTOR.getMonitors())-1
                directoryToZip = AgentConstants.AGENT_DATA_DIR
                buffer_filesToZip = AgentBuffer.getBuffer('FILES_TO_ZIP_BUFFER')
                buffer_filesToUpload = AgentBuffer.getBuffer('FILES_TO_UPLOAD_BUFFER')
                list_fileNames = sorted(os.listdir(directoryToZip))
                if len(list_fileNames) == 0:
                    AgentLogger.log(AgentLogger.STDOUT,'Data directory is empty. No files to zip')
                else:
                    while not bool_isDirEmpty and int_noOfZipFiles < Max_Zip_Files_To_Be_Created and not TERMINATE_AGENT: # Temporary hack to ensure that this loop is not infinite in zipping                
                        int_noOfFilesAddedToZip = 0
                        zipFileName = None
                        zip_fileObj = None
                        bool_isZippingSuccess = True                
                        try:                    
                            zipFileName = AgentConstants.AGENT_UPLOAD_DIR+'/'+self.getUniqueZipFileName(AGENT_CONFIG.get('AGENT_INFO', 'agent_key'), getTimeInMillis())
                            str_fileToZipPath = None
                            if len(list_fileNames) >= MAX_FILES_IN_ZIP:
                                zip_fileObj = zipfile.ZipFile(zipFileName, 'w')
                                for fileName in list_fileNames: # This loop will break when directory is empty or maximum file count in a zip is reached
                                    if int_noOfFilesAddedToZip >= MAX_FILES_IN_ZIP:
                                        break
                                    else:                                              
                                        try:                            
                                            str_fileToZipPath = os.path.join(AgentConstants.AGENT_DATA_DIR, fileName)
                                            if os.path.isfile(str_fileToZipPath):                                
                                                zip_fileObj.write(str_fileToZipPath,'data/'+fileName, zipfile.ZIP_DEFLATED)
                                                AgentLogger.log(AgentLogger.STDOUT,'File Added To Zip : ' + str(fileName))
                                                int_noOfFilesAddedToZip+=1
                                                os.remove(str_fileToZipPath)   
                                                if fileName in buffer_filesToZip:                 
                                                    buffer_filesToZip.pop()
                                        except Exception as e:
                                            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while writing the file : '+str_fileToZipPath+' to the zip file '+zipFileName+' ************************* '+repr(e))
                                            traceback.print_exc()
                            else: # remove previous incomplete data collection set files.
                                try:
                                    for fileName in list_fileNames:
                                        str_fileToZipPath = os.path.join(AgentConstants.AGENT_DATA_DIR, fileName)
                                        if os.path.isfile(str_fileToZipPath):
                                            AgentLogger.log(AgentLogger.STDOUT,'Removing incomplete data collection set file : ' + str(str_fileToZipPath))
                                            os.remove(str_fileToZipPath)
                                            if fileName in buffer_filesToZip:                 
                                                buffer_filesToZip.pop()
                                except Exception as e:
                                    AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while deleting incomplete data collection set files ************************* '+repr(e))
                                    traceback.print_exc()
                            bool_isDirEmpty = True
                            AgentLogger.log(AgentLogger.STDOUT,str(int_noOfFilesAddedToZip)+' File(s) added to the zip file : '+zipFileName)
                            # Increment zip file count when zipping is success
                            int_noOfZipFiles+=1
                        except Exception as e:
                            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while zipping the file : '+str(zipFileName)+' ************************* '+repr(e))
                            traceback.print_exc()
                            bool_isZippingSuccess = False
                        finally:                    
                            if not zip_fileObj == None:
                                zip_fileObj.close()
                            if zipFileName is not None and os.path.exists(zipFileName) and not bool_isZippingSuccess:
                                AgentLogger.log(AgentLogger.STDOUT,'Deleting The Corrupted Zip File :'+str(zipFileName))
                                try:
                                    os.remove(zipFileName)
                                except Exception as e:
                                    AgentLogger.log(AgentLogger.STDOUT,'************************* Exception while deleting the corrupted Zip File :'+zipFileName+' *************************')
                                    traceback.print_exc()
                            else:
                                AgentLogger.log([AgentLogger.STDOUT],'Adding the following zip file to upload buffer :'+str(zipFileName))
                                buffer_filesToUpload.add(zipFileName)
                    AgentLogger.log(AgentLogger.STDOUT,str(int_noOfZipFiles)+' Zip file(s) created in this zipping process')
        except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT,' ************************* Exception while zipping the files in the data directory ************************* '+repr(e))
            traceback.print_exc()
            bool_toReturn = False
        finally:
            AgentLogger.debug(AgentLogger.STDOUT,'Released zip lock')
        return bool_toReturn

class FileObject:
    def __init__(self):
        self.str_fileName = None
        self.str_filePath = None
        self.data = None
        self.str_dataType = None
        self.str_dataEncoding = None
        self.str_mode = 'w'
        self.str_loggerName = None
        self.bool_changePermission = False
        self.bool_logging = True
        self.bool_forceSave = False
    def set_fileName(self, str_fileName):
        self.str_fileName = str_fileName
    def get_fileName(self):
        return self.str_fileName
    def set_filePath(self, str_filePath):
        self.str_filePath = str_filePath
    def get_filePath(self):
        return self.str_filePath
    def set_data(self, data):
        self.data = data
    def get_data(self):
        return self.data
    def set_dataType(self, str_dataType):
        self.str_dataType = str_dataType
    def get_dataType(self):
        return self.str_dataType
    def set_dataEncoding(self, str_dataEncoding):
        self.str_dataEncoding = str_dataEncoding
    def get_dataEncoding(self):
        return self.str_dataEncoding
    def set_mode(self, str_mode):
        self.str_mode = str_mode
    def get_mode(self):
        return self.str_mode
    def set_logging(self, bool_logging):
        self.bool_logging = bool_logging
    def get_logging(self):
        return self.bool_logging
    def set_loggerName(self, str_loggerName):
        self.str_loggerName = str_loggerName
    def get_loggerName(self):
        return self.str_loggerName
    def set_changePermission(self, bool_changePermission):
        self.bool_changePermission = bool_changePermission
    def get_changePermission(self):
        return self.bool_changePermission
    def set_forceSave(self, bool_value):
        self.bool_forceSave = bool_value
    def get_forceSave(self):
        return self.bool_forceSave

#Create objects of this class and put in zipBuffer and uploadBuffer
class FileZipAndUploadInfo:
    def __init__(self):
        self.filesToZip = None
        self.zipFileName = 'DEFAULT'
        self.uploadServlet = None
        self.uploadRequestParameters = None
        self.zipFilePath = 'DEFAULT'
        self.uploadData = None
        self.isZipFile = None
        self.str_fileToZipPath = AgentConstants.AGENT_DATA_DIR
        self.method = AgentConstants.HTTP_POST
    
    def setZipFileName(self,str_zipFileName):
        self.zipFileName = str_zipFileName
    
    def setUploadMethod(self,strMethod):
        self.method = strMethod 
    
    def getUploadMethod(self):
        return self.method
    
    def setFilesToZip(self,listFilesToZip):
        self.filesToZip = listFilesToZip
    
    def setFileToZipPath(self,str_path):
        self.str_fileToZipPath = str_path
    
    def setUploadServlet(self,str_uploadServlet):
        self.uploadServlet = str_uploadServlet
        
    def setUploadRequestParameters(self,listUploadRequestParameters):
        self.uploadRequestParameters = listUploadRequestParameters
    
    def setZipFilePath(self,str_zipFilePath):
        self.zipFilePath = str_zipFilePath
    
    def setUploadData(self, dataToSend):
        self.uploadData = dataToSend
        
    def getZipFileName(self):
        return self.zipFileName
    
    def getFilesToZip(self):
        return self.filesToZip
    
    def getFilesToZipPath(self):
        return self.str_fileToZipPath
    
    def getUploadServlet(self):
        return self.uploadServlet
    
    def getUploadRequestParameters(self):
        return self.uploadRequestParameters
    
    def getZipFilePath(self):
        return self.zipFilePath

class FileHandler(DesignUtils.Singleton):
    __fileId = 0
    __fileIdCounterLock = threading.Lock()
    def __init__(self):
        pass
    
    def setFileId(self, int_id):
        FileHandler.__fileId = int_id
        
    def getUniqueFileId(self):
        with FileHandler.__fileIdCounterLock:
            FileHandler.__fileId+=1
            if FileHandler.__fileId - int(AGENT_PARAMS['AGENT_FILE_ID']) >= 100:
                AGENT_PARAMS['AGENT_FILE_ID'] = str(FileHandler.__fileId)
                persistAgentParams()
            return FileHandler.__fileId
          
    def getUniqueFileName(self,var_agentKey,str_customName = None, ignoreDefaultName = False):
        if ignoreDefaultName:
            return 'Agent_'+str(str_customName)+'.txt'
        if str_customName:
            return 'Agent_'+str(var_agentKey)+'_'+str(str_customName)+'_'+str(self.getUniqueFileId())+'.txt'
        else:
            return 'Agent_'+str(var_agentKey)+'_'+str(self.getUniqueFileId())+'.txt'
    
    def getUniquePluginFileName(self,var_pluginKey,str_customName = None):
        return 'Plugin_'+str(var_pluginKey)+'_'+str(self.getUniqueFileId())+'.txt'
    
    def getUniquePluginFileName(self,var_pluginKey,str_customName = None):
        if str_customName:
            return 'Plugin_'+str(var_pluginKey)+'_'+str(str_customName)+'_'+str(self.getUniqueFileId())+'.txt'
        else:
            return 'Plugin_'+str(var_pluginKey)+'_'+str(self.getUniqueFileId())+'.txt'
    
    def getFileCount(self,directory,filename):
        count = 0
        fileList = os.listdir(directory)
        for file in fileList:
            if filename in file:
                count+=1
        return count
        
            
    # Returns a tuple (bool_isSuccess, str_fileName)
    def saveData(self, fileObj):
        bool_toReturn = True
        file_obj = None
        str_fileName = None
        str_filePath = None
        str_dataType = None
        str_dataEncoding = None
        dataToWrite = None
        dic_DataToWrite = None
        str_loggerName = None
        bool_changePermission = None
        str_mode = None
        bool_logging = True
        bool_forceSave = False
        duplicate_dataToWrite = None
        try:
            if not fileObj.get_forceSave() and  TERMINATE_AGENT:
                return False, None
            str_filePath = fileObj.get_filePath()
            dataToWrite = fileObj.get_data()
            str_dataType = fileObj.get_dataType()
            str_dataEncoding = fileObj.get_dataEncoding()
            str_mode = fileObj.get_mode()
            str_loggerName = fileObj.get_loggerName()
            bool_changePermission = fileObj.get_changePermission()
            bool_logging = fileObj.get_logging()
            duplicate_dataToWrite = copy.deepcopy(dataToWrite)
            if 'AGENTKEY' in duplicate_dataToWrite:
                del duplicate_dataToWrite['AGENTKEY']
            if 'dc' in duplicate_dataToWrite:
                del duplicate_dataToWrite['dc']
            if 'MSPCUSTOMERID' in duplicate_dataToWrite:
                del duplicate_dataToWrite['MSPCUSTOMERID']
            if 'reason' in duplicate_dataToWrite:
                del duplicate_dataToWrite['reason']
            if 'avail' in duplicate_dataToWrite:
                del duplicate_dataToWrite['avail']
            if str_dataType == 'json':
                file_obj = codecs.open(str_filePath,str_mode,str_dataEncoding)
                duplicate_dataToWrite = json.dumps(duplicate_dataToWrite)#python dictionary to json string
            else:
                file_obj = open(str_filePath,str_mode)    
            file_obj.write(duplicate_dataToWrite)
        except:
            AgentLogger.log(str_loggerName,'************************* Exception while saving data : '+repr(duplicate_dataToWrite)+' to the file '+str(str_filePath)+' ************************* ')
            traceback.print_exc()
            bool_toReturn = False
        finally:
            if not file_obj == None:
                file_obj.close()
        if bool_toReturn and bool_logging:        
            AgentLogger.log(str_loggerName,'SAVED DATA : ')
            if 'TOPMEMORYPROCESS' in dataToWrite:
                dataDict = json.loads(duplicate_dataToWrite)
                if 'TOPMEMORYPROCESS' in dataDict:
                    del dataDict['TOPMEMORYPROCESS']
                if 'TOPCPUPROCESS' in dataDict:
                    del dataDict['TOPCPUPROCESS']
                duplicate_dataToWrite=json.dumps(dataDict)
            AgentLogger.log(str_loggerName,repr(duplicate_dataToWrite)+' File : '+str(str_filePath))
        return bool_toReturn, str_filePath
    
    def readData(self, fileObj):
        bool_toReturn = True
        file_obj = None
        str_fileName = None
        str_filePath = None
        str_dataType = None
        str_dataEncoding = None
        var_dataToReturn = None
        str_loggerName = None
        bool_changePermission = None
        str_mode = None
        bool_logging = True
        try:
            if TERMINATE_AGENT:
                return False, None
            str_filePath = fileObj.get_filePath()
            str_dataType = fileObj.get_dataType()
            str_dataEncoding = fileObj.get_dataEncoding()
            str_mode = fileObj.get_mode()
            str_loggerName = fileObj.get_loggerName()
            bool_logging = fileObj.get_logging()
            if str_dataType == 'json':
                file_obj = open(str_filePath,str_mode)
                byte_data = file_obj.read()
                unicodeData = byte_data.decode(str_dataEncoding)
                var_dataToReturn = json.loads(unicodeData, object_pairs_hook=collections.OrderedDict)
            else:
                file_obj = open(str_filePath,str_mode)
                var_dataToReturn = file_obj.read()
        except:
            AgentLogger.log(str_loggerName,'************************* Exception while reading data from the file '+str(str_filePath)+' ************************* ')
            traceback.print_exc()
            bool_toReturn = False
        finally:
            if not file_obj == None:
                file_obj.close()
        if bool_toReturn and bool_logging:        
            AgentLogger.log(str_loggerName,'Data read from file : ')
            AgentLogger.log(str_loggerName,repr(dataToWrite)+' File : '+str(str_filePath))
        return bool_toReturn, var_dataToReturn
    
    # Sort by time - Returns file list sorted in ascending order
    def getSortedFileList(self, str_dirName, str_loggerName=AgentLogger.STDOUT, sortBy='time'):
        list_fileNames = None
        try:
            list_fileNames = os.listdir(str_dirName)
            list_fileNames = [os.path.join(str_dirName, f) for f in list_fileNames] # add path to each file
            if sortBy == 'time':
                list_fileNames.sort(key=lambda x: os.path.getmtime(x))
            AgentLogger.debug(str_loggerName,'Directory : '+repr(str_dirName)+', Sorted files : ' + repr(list_fileNames))
        except Exception as e:
            AgentLogger.log([str_loggerName,AgentLogger.STDERR], ' *************************** Exception while fetching sorted file list for the directory : '+repr(str_dirName)+', Sort by : '+repr(sortBy)+' *************************** '+ repr(e))
            traceback.print_exc()
        return list_fileNames
    
    def cleanUpFiles(self):
        try:   
            AgentLogger.debug(AgentLogger.STDOUT,'================================= CLEANING TEMP FILES =================================')
            for tuple_folderVsFileList in AgentConstants.FOLDER_VS_CLEAN_UP_FILE_LIST:
                str_cleanUpDirectory = tuple_folderVsFileList[0]
                list_cleanUpFileNames = tuple_folderVsFileList[1]
                for str_cleanUpFileName in list_cleanUpFileNames:
                    list_tempFileNames = []
                    list_fileNames = self.getSortedFileList(str_cleanUpDirectory, str_loggerName=AgentLogger.STDOUT)
                    for filePath in list_fileNames:
                        if str_cleanUpFileName in filePath:
                            list_tempFileNames.append(filePath)
                            #AgentLogger.log(AgentLogger.COLLECTOR,'List of temp files : ' + repr(list_tempFileNames))
                            if len(list_tempFileNames) > 10:
                                str_fileToDeletePath = list_tempFileNames.pop(0)
                                self.deleteFile(str_fileToDeletePath, AgentLogger.STDOUT)
        except Exception as e:
            AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR], ' *************************** Exception while deleting temp data collection files *************************** '+ repr(e))
            traceback.print_exc()
            
    def deleteFile(self, str_filePath, str_loggerName=AgentLogger.STDOUT):
        bool_isSuccess = True
        try:
            AgentLogger.debug(str_loggerName,'Deleting the file :'+str(str_filePath))
            if str_filePath is not None and os.path.exists(str_filePath):
                os.remove(str_filePath)
            else:
                AgentLogger.log([str_loggerName,AgentLogger.CRITICAL],'Failed to delete the file :'+str(str_filePath))
                bool_isSuccess = False
        except Exception as e:
            AgentLogger.log([str_loggerName,AgentLogger.STDERR],'************************* Exception while deleting the file :'+str(str_filePath)+' *************************')
            traceback.print_exc()
            bool_isSuccess = False
        return bool_isSuccess
    
    def copyFile(self, src, dst):
        bool_isSuccess = True
        try:
            shutil.copy2(src, dst)
        except Exception as e:
            AgentLogger.log(AgentLogger.STDERR,'************************* Exception while copying the file : '+str(src)+' to : '+repr(dst)+' *************************')
            traceback.print_exc()
            bool_isSuccess = False
        return bool_isSuccess

    def createFile(self, str_filePath, str_loggerName=AgentLogger.STDOUT):
        bool_isSuccess = True
        try:
            AgentLogger.log(str_loggerName,'File Name --> :'+str(str_filePath))
            if str_filePath is not None and not os.path.exists(str_filePath):
                file_obj=open(str_filePath,'w')
            else:
                AgentLogger.log(str_loggerName,'File Already Exists ----> :'+str(str_filePath))
                bool_isSuccess=False
        except Exception as e:
            AgentLogger.log([str_loggerName,AgentLogger.STDERR],'************************* Exception while creating the file :'+str(str_filePath)+' *************************')
            traceback.print_exc()
            bool_isSuccess = False
        finally:
            if not file_obj == None:
                file_obj.close()
        return bool_isSuccess
    
def startWatchdog():
    try:
        isSuccess, str_output = executeCommand(AgentConstants.AGENT_WATCHDOG_START_COMMAND)
        AgentLogger.log(AgentLogger.MAIN,'Watchdog status after invoking start command : '+repr(str_output))
    except Exception as e:
        AgentLogger.log(AgentLogger.MAIN,' ************************* Exception while starting watchdog ************************* '+ repr(e))
        traceback.print_exc()
    
def ReleaseApplicationLock():
    try:
        import fcntl
        fcntl.flock(AgentConstants.APPLICATION_LOCK, fcntl.LOCK_UN)
    except Exception as e:
        traceback.print_exc()
        
def UninstallAgent():
    try:
        AgentLogger.log([AgentLogger.STDOUT],'======================================= UNINSTALL AGENT : CREATING UNINSTALL FLAG =======================================')
        str_uninstallTime = 'Uninstall : '+repr(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"))
        fileObj = FileObject()
        fileObj.set_filePath(AgentConstants.AGENT_UNINSTALL_FLAG_FILE)
        fileObj.set_data(str_uninstallTime)
        fileObj.set_loggerName([AgentLogger.STDOUT])
        FileUtil.saveData(fileObj)
        com.manageengine.monagent.collector.DataCollector.COLLECTOR.stopDataCollection()
        TerminateAgent()
        cleanAll()
        if AGENT_CONFIG.has_section('AGENT_INFO') and ((AGENT_CONFIG.get('AGENT_INFO','agent_instance_type')==AgentConstants.AZURE_INSTANCE) or (AGENT_CONFIG.get('AGENT_INFO','agent_instance_type')==AgentConstants.AZURE_INSTANCE_CLASSIC)):
            do_status_report('Agent Uninstall','success',0,'Agent uninstalled successfully')
    except Exception as e:        
        AgentLogger.log([ AgentLogger.STDERR],' ************************* Exception while creating uninstall flag file!!! ************************* '+ repr(e))
        traceback.print_exc()
                
def RestartAgent():
    try:
        AgentLogger.log([AgentLogger.STDOUT],'======================================= RESTART AGENT : CREATING RESTART FLAG =======================================')
        str_uninstallTime = 'Restart : '+repr(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"))
        fileObj = FileObject()
        fileObj.set_filePath(AgentConstants.AGENT_RESTART_FLAG_FILE)
        fileObj.set_data(str_uninstallTime)
        fileObj.set_loggerName([AgentLogger.STDOUT])
        FileUtil.saveData(fileObj)
    except Exception as e:        
        AgentLogger.log([ AgentLogger.STDERR],' ************************* Exception while creating restart flag file!!! ************************* '+ repr(e))
        traceback.print_exc()

def TerminateAgent():
    global TERMINATE_AGENT
    if not TERMINATE_AGENT:
        AgentLogger.log(AgentLogger.MAIN,'======================================= SHUTTING DOWN AGENT ======================================= ')
        TERMINATE_AGENT = True
        TERMINATE_AGENT_NOTIFIER.set()
    #azure stop status update
    try:
        if AGENT_CONFIG.has_section('AGENT_INFO') and AGENT_CONFIG.get('AGENT_INFO','agent_instance_type')==AgentConstants.AZURE_INSTANCE or AGENT_CONFIG.get('AGENT_INFO','agent_instance_type')==AgentConstants.AZURE_INSTANCE_CLASSIC:
            do_status_report('Agent Termination','success',0,'Agent stopped successfully')
    except Exception as e:
        AgentLogger.log(AgentLogger.CRITICAL,' Exception While updating agent stop status ')
        traceback.print_exc()
        
        
def cleanAll():
    try:
        # Cleanup code
        AgentLogger.log(AgentLogger.MAIN,' ======================================= CLEANING UP AGENT RESOURCES ======================================= ')
        from com.manageengine.monagent.scheduler import AgentScheduler
        AgentScheduler.stopSchedulers()
        com.manageengine.monagent.communication.UdpHandler.SysLogUtil.persistLogMessages()
        persistAgentParams()
        AgentBuffer.cleanUp()
        AgentLogger.shutdown()
        ReleaseApplicationLock()
    except Exception as e:        
        AgentLogger.log(AgentLogger.CRITICAL,' ************************* PROBLEM WHILE CLEANING UP AGENT RESOURCES!!! ************************* '+ repr(e))
        traceback.print_exc()
    finally:
        ReleaseApplicationLock()
        
def timeConversion(timeinms):
    str_time=''
    days = math.floor(timeinms / 86400000)
    timeinms = timeinms-days*86400000

    hrs = math.floor(timeinms / 3600000)
    timeinms = timeinms-hrs*3600000

    mins = math.floor(timeinms / 60000)
    timeinms=timeinms-mins*60000
    
    secs=math.floor(timeinms/1000)
    ms=timeinms-secs*1000
    if days>0:
        str_time = str(int(days))+' '+'day(s)'
    if hrs>0:
        str_time+= ' '+str(int(hrs))+' '+'hr(s)'
    if mins>0:
        str_time+= ' '+str(int(mins))+' '+'min(s)'
    if secs>0:
        str_time+= ' '+str(int(secs))+' '+'sec(s)'
    if ms>0:
        str_time+= ' '+str(ms)+' '+'ms'
    return str_time

def getUptimeInChar():
    isSuccess, str_output = executeCommand(AgentConstants.UPTIME_CLIENT)
    if isSuccess:
        uptime = re.sub('\s+','',str_output).strip()
        int_ut = int(float(uptime))*1000
    else:
        return '0'
    return timeConversion(int_ut)

def do_status_report(operation, status, status_code, message):
        try:
            azure_status_file=getStatusFileName()
            if azure_status_file:
                DateTimeFormat = "%Y-%m-%dT%H:%M:%SZ"
                tstamp=time.strftime(DateTimeFormat, time.gmtime())
                stat = [{
                    "version" : "1.0.0",
                    "timestampUTC" : tstamp,
                    "status" : {
                        "operation" : operation,
                        "status" : status,
                        "code" : status_code,
                        "formattedMessage" : {
                            "lang" : "en-US",
                            "message" : message
                        }
                    }
                }]
                stat_rept = json.dumps(stat)
                with open(azure_status_file,'w') as f:
                    f.write(stat_rept)
            else:
                AgentLogger.log(AgentLogger.STDOUT,' Not Able to fetch status file '+repr(azure_status_file))
        except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT,' Exception While Updating the Agent Status '+ repr(e))
            traceback.print_exc()

def getStatusFileName():
    try:
        latest_status_file=None
        if os.path.exists(AgentConstants.AZURE_HANDLER_FILE):
            file_obj = open(AgentConstants.AZURE_HANDLER_FILE,'r')
            handler_conf_dict = json.load(file_obj,object_pairs_hook=collections.OrderedDict)
            for each in handler_conf_dict:
                for k in each:
                    if k=='handlerEnvironment':
                        conf_file_directory = each[k]['configFolder']
                        status_file_directory = each[k]['statusFolder']
            if not file_obj == None:
                        file_obj.close()
            if conf_file_directory:
                for dirname, dirnames, filenames in os.walk(conf_file_directory):
                    for file in filenames:
                        if '.settings' in file:
                            max_mtime = 0
                            full_path = os.path.join(dirname, file)
                            mtime = os.stat(full_path).st_mtime
                            if mtime > max_mtime:
                                max_mtime = mtime
                                max_dir = dirname
                                max_file = file
                latest_modified_config_file = max_file
                if latest_modified_config_file:
                    file_no=latest_modified_config_file.split('.')[0]
                    latest_status_file=status_file_directory+'/'+file_no+'.status'
        else:
            AgentLogger.log(AgentLogger.STDOUT,' Azure Handler Environment File not exists ')
    except Exception as e:
        traceback.print_exc()
    return latest_status_file


def generateTraceRoute():
    try:
        trace_dict={}
        str_fileName = 'trace_route_'+str(getTimeInMillis())+'.txt'
        executorObj = Executor()
        executorObj.setLogger(AgentLogger.STDOUT)
        executorObj.setTimeout(240)
        command = AgentConstants.TRACEROUTE_COMMAND
        AgentLogger.log(AgentLogger.CHECKS,'trace route command is '+repr(command))
        executorObj.setCommand(command)
        executorObj.executeCommand()
        trace_dict['status'] = executorObj.isSuccess()
        retVal = executorObj.getReturnCode()
        if not ((retVal == 0) or (retVal is not None)):
            trace_dict['timeout'] = True
        trace_dict['output'] = executorObj.getStdOut()
        trace_dict['error'] = getModifiedString(executorObj.getStdErr(),100,100)
        if trace_dict['error']!='' and 'unknown host' in trace_dict['error']:
            trace_dict['output']=trace_dict['error']
            AgentLogger.log(AgentLogger.CHECKS,'trace route error assigned to output ---> '+json.dumps(trace_dict))
        if not trace_dict['output'] == None and trace_dict['output']!='':
            str_filePath = AgentConstants.AGENT_TEMP_RCA_DIR+'/'+str_fileName
            trace_dict['output'] = trace_dict['output'].replace('\n','#')
            fileObj = FileObject()
            fileObj.set_fileName(str_fileName)
            fileObj.set_filePath(str_filePath)
            fileObj.set_data(trace_dict['output'])
            fileObj.set_dataType('json')
            fileObj.set_mode('wb')
            fileObj.set_dataEncoding('UTF-16LE')
            fileObj.set_loggerName(AgentLogger.STDOUT)
            bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
        AgentLogger.log(AgentLogger.CHECKS,'trace route output ---> '+json.dumps(trace_dict))
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'Exception occurred while generating trace route')
    return trace_dict

def getTraceRouteData(float_timeInMillis):
    AgentLogger.log(AgentLogger.STDOUT,' Search Time ---> '+repr(float_timeInMillis))
    try:
        fileList = FileUtil.getSortedFileList(AgentConstants.AGENT_TEMP_RCA_DIR)
        tracedict=None
        for file in fileList:
            if 'trace_route' in file:
                fileName = os.path.basename(file)
                AgentLogger.log(AgentLogger.STDOUT,' File Name ---> '+repr(fileName))
                name,fileExt = os.path.splitext(fileName)
                list = name.split('_')
                time = list[2]
                if int(time) < float_timeInMillis:
                    boolStatus,tracedict = loadUnicodeDataFromFile(file)
                    break
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'Exception occurred while getting trace route')
    return tracedict

def deleteTraceRoute():
    try:
        list = FileUtil.getSortedFileList(AgentConstants.AGENT_TEMP_RCA_DIR, str_loggerName=AgentLogger.STDOUT)
        if not list == None:
            for file in list:
                if 'trace_route' in file:
                    AgentLogger.log(AgentLogger.CHECKS,'Trace Route File to be removed ---> '+repr(file))
                    os.remove(file)
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Trace Route File List Empty')
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'Exception occurred while deleting trace route files')
        traceback.print_exc()

def invokeUptimeMonitoringFC():
    try:
        AgentLogger.log(AgentLogger.STDOUT,'########## UPTIME MONITORING FILE COLLECTOR ##########')
        str_url = None
        str_servlet = AgentConstants.AGENT_FILE_COLLECTOR_SERVLET
        dict_requestParameters = {
            'AGENTKEY' : AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),
            'CUSTOMERID' :  AGENT_CONFIG.get('AGENT_INFO', 'customer_id'),
            'AGENTUNIQUEID' : AGENT_CONFIG.get('AGENT_INFO', 'agent_unique_id'),
            'bno' : AgentConstants.AGENT_VERSION,
            'UPTIME_MONITORING': 'true'
        }
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        requestInfo = com.manageengine.monagent.communication.CommunicationHandler.RequestInfo()
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_timeout(30)
        bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData = com.manageengine.monagent.communication.CommunicationHandler.sendRequest(requestInfo)
        AgentLogger.log(AgentLogger.STDOUT,'Repsonse --- {0}'.format(bool_toReturn))
        AgentLogger.log(AgentLogger.STDOUT,'Error Code --- {0}'.format(int_errorCode))
        AgentLogger.log(AgentLogger.STDOUT,'Response Data --- {0}'.format(dict_responseData))
    except Exception as e:
        AgentLogger.log(AgentLogger.STDOUT,'Exception while updating file collector - uptime monitoring')
        traceback.print_exc()

def updateKeys(keysDict):
    try:
        isConfUpdated=False
        agent_key=None
        customer_id=None
        AgentLogger.log(AgentLogger.STDOUT,'########## UPDATE KEY WMS ACTION CALLED ##########')
        if 'AGENTKEY' in keysDict:
            agent_key=keysDict['AGENTKEY']
        if 'DEVICEKEY' in keysDict:
            customer_id=keysDict['DEVICEKEY']
        
        if not customer_id == None and not customer_id == '':
            AGENT_CONFIG.set('AGENT_INFO', 'customer_id',customer_id)
            isConfUpdated=True
        
        if not agent_key == None and not agent_key == '':
            AGENT_CONFIG.set('AGENT_INFO', 'agent_key',agent_key)
            isConfUpdated=True
        
        if isConfUpdated:
            AgentLogger.log(AgentLogger.STDOUT,'########## Updating Agent Configuration File ##########')
            persistAgentInfo()
        
    except Exception as e:
        traceback.print_exc()

def calculateNoOfCpuCores():
    try:
        output = None
        executorObj = Executor()
        executorObj.setLogger(AgentLogger.STDOUT)
        command = AgentConstants.NO_OF_CPU_CORES_COMMAND
        AgentLogger.log(AgentLogger.STDOUT,'no of cores command :: '+repr(command))
        executorObj.setCommand(command)
        executorObj.executeCommand()
        output = executorObj.getStdOut()
        if not output == None:
            AgentConstants.NO_OF_CPU_CORES=float(output.strip('\n'))
            AgentLogger.log(AgentLogger.STDOUT,'no of cores :: '+repr(AgentConstants.NO_OF_CPU_CORES))
    except Exception as e:
        traceback.print_exc()

def getSystemUUID():
    try:
        output = None
        executorObj = Executor()
        executorObj.setLogger(AgentLogger.STDOUT)
        command = AgentConstants.SYSTEM_UUID_COMMAND
        AgentLogger.log(AgentLogger.STDOUT,'server uuid command :: '+repr(command))
        executorObj.setCommand(command)
        executorObj.executeCommand()
        output = executorObj.getStdOut()
        if not output == None:
            AgentConstants.SYSTEM_UUID=(output.strip('\n'))
            AgentLogger.log(AgentLogger.STDOUT,'system uuid :: '+repr(AgentConstants.SYSTEM_UUID))
    except Exception as e:
        traceback.print_exc()

def updateTaskInfo(dict_task):
    try:
        AgentLogger.log(AgentLogger.STDOUT,'update task info  :: '+repr(dict_task))
        if dict_task:
            updateKey = dict_task['key']
            updateValue = dict_task['value']
            if AGENT_CONFIG.has_option('AGENT_INFO', updateKey):
                AGENT_CONFIG.set('AGENT_INFO', updateKey, updateValue)
                persistAgentInfo()
                if updateKey=="pl_zip_task_interval":
                    AgentConstants.PLUGINS_ZIP_INTERVAL = updateValue
                    com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.initiateZipTask()
                elif updateKey=="pl_dc_task_interval":
                    AgentConstants.PLUGINS_DC_INTERVAL = updateValue
                    com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.initiatePluginDC()
                elif updateKey=="pl_dc_zip_count":
                    AgentConstants.PLUGINS_ZIP_FILE_SIZE = updateValue
                elif updateKey=="dc_upload_interval":
                    AgentConstants.UPLOAD_CHECK_INTERVAL = updateValue
                    AgentConstants.CURRENT_DC_TIME = None
    except Exception as e:
        traceback.print_exc()


def getUpTime():
    try:
        executorObj = Executor()
        executorObj.setLogger(AgentLogger.STDOUT)
        executorObj.setTimeout(10)
        executorObj.setCommand(AgentConstants.UPTIME_COMMAND)
        executorObj.executeCommand()
        uptime = int(executorObj.getStdOut())
        return uptime
    except:
        AgentLogger.log(AgentLogger.STDOUT,'Exception while calculating the uptime')
        traceback.print_exc()
        return None
            
def getBootTime():
    uptime=None
    serverRestart=None
    bootTime=None
    try:
        uptime = getUpTime()
        if os.path.exists(AgentConstants.AGENT_UPTIME_FLAG_FILE):
                executorObj=Executor()
                executorObj.setCommand(AgentConstants.UPTIME_READ_COMMAND)
                executorObj.executeCommand()
                prev_uptime = int(executorObj.getStdOut())
                if uptime < prev_uptime:
                    serverRestart =  True
                    executorObj.setCommand(AgentConstants.BOOT_TIME_COMMAND)
                    executorObj.executeCommand()
                    cmd_out=executorObj.getStdOut().split('\n')
                    try:
                        boot_time_parsed=[]
                        boottime=''
                        boot_time_raw=datetime.strptime(cmd_out[0],'%b %d %H:%M:%S %Y')-datetime.strptime(cmd_out[1],'%b %d %H:%M:%S %Y')
                        boot_time_parsed.append(boot_time_raw.days)
                        if boot_time_parsed[0] != 0:
                            boottime=str(boot_time_parsed[0])+' days '
                        boot_time_parsed.append(int(boot_time_raw.seconds/3600))
                        if boot_time_parsed[1] != 0:
                            boottime=boottime+str(boot_time_parsed[1])+' hours '
                        boot_time_parsed.append(int((boot_time_raw.seconds-boot_time_parsed[1]*3600)/60))
                        if boot_time_parsed[2] != 0:
                            boottime=boottime+str(boot_time_parsed[2])+' minutes '
                        boot_time_parsed.append(boot_time_raw.seconds%60)
                        if boot_time_parsed[3] != 0:
                            boottime=boottime+str(boot_time_parsed[3])+' seconds '
                            bootTime = boottime
                    except Exception as e1:
                        AgentLogger.log(AgentLogger.STDOUT,'Exception while calculating the boot_time')
                        traceback.print_exc()
    except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT,'Exception while calculating the uptime')
            traceback.print_exc()
    return uptime,serverRestart,bootTime

        
initialize()
