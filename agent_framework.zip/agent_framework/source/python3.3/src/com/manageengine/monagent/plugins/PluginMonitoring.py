import json
import os
import re
import time
import traceback
import threading
import shutil
import platform
import math
from six.moves.urllib.parse import urlencode
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util import DesignUtils
from com.manageengine.monagent.util import AgentBuffer
from com.manageengine.monagent.util.AgentUtil import FileUtil, FileZipAndUploadInfo,ZipUtil,AGENT_CONFIG
from com.manageengine.monagent.plugins import PluginUtils
from com.manageengine.monagent.scheduler import AgentScheduler
import com

pluginUtil = None
customFileLock = threading.Lock()

previousLastModifiedTime=0
IGNORED_PLUGINS = {}
IGNORED_PLUGINS_CONF_FILE = {}
collection_Time=0
DONT_VALIDATE=['plugin_version','output','heartbeat_required']

class Plugins():
    def __init__(self):
        self.id = None
        self.name = None
        self.timeout = AgentConstants.DEFAULT_SCRIPT_TIMEOUT
        self.fileType = None
        self.command = None
        self.pluginType=None
        self.ispluginRegistered=None
        self.pluginStatus=None
        self.isPluginSupported=None
        self.nagiosVersion=None
        self.folderName = None
        self.plugin_ignore_filepath = None

    def setPluginDetails(self,plugCmd,pluginType):
        try:
            self.name = PluginUtils.fetchPluginName(plugCmd,pluginType)
            self.plugin_ignore_filepath = os.path.join(os.path.dirname(plugCmd.split(' ')[0]), '.ignore_file')
            AgentLogger.log(AgentLogger.PLUGINS,self.plugin_ignore_filepath+" value for plugin_ignore_filepath")
            self.pluginType=pluginType
            self.folderName,self.fileType = fetchFileType(self.name)
            self.command = getCmdForExecution(self.fileType,plugCmd)
            self.nagiosVersion = getNagiosVersion(pluginType,plugCmd)
            self.isPluginSupported=checkForPluginSupport(self.fileType,self.pluginType)
            #self.isPluginIgnored = checkIgnoreFilePresent(self.name)
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while setting Plugin monitor details *************************** ' + repr(e))
            traceback.print_exc()
    
    def setPluginStatus(self):
        try:
            bool_reg,plug_status=getPluginStatus(self.name)
            self.ispluginRegistered=bool_reg
            self.pluginStatus=plug_status
        except Exception as e:
            AgentLogger.log(AgentLogger.PLUGINS, '*********** Exception while setting plugin status ***********')
            traceback.print_exc()
    
    def pluginDC(self):
        global IGNORED_PLUGINS
        global IGNORED_PLUGINS_CONF_FILE
        if self.isPluginSupported:
            if int(self.pluginStatus) in [0,2,9]:
                if not self.name in IGNORED_PLUGINS_CONF_FILE['ignored_plugins']:
                    outputDict, result = self.executeScript()
                    AgentLogger.log(AgentLogger.PLUGINS,"plugin - {0} | output - {1}".format(self.name,json.dumps(outputDict)))
                    try:
                        if result:
                            if self.pluginType == 'nagios':
                                self.parseNagiosPlugins(outputDict)
                            else:
                                if self.fileType == '.sh':
                                    self.parseShellPlugins(outputDict)
                                else:
                                    self.parsePyPlugins(outputDict)
                        else:
                            AgentLogger.log(AgentLogger.PLUGINS, '======== Plugin Execution Result Not Obtained ========= {0}{1}'.format(outputDict, result))
                    except Exception as e:
                        AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception for Plugin  *************************** {0}'.format(self.name))
                        traceback.print_exc()
                else:
                    AgentLogger.log(AgentLogger.PLUGINS, 'Plugin Not Executed - Plugin is in Ignored State ---> {0} '.format(self.name))
            else:
                AgentLogger.log(AgentLogger.PLUGINS, 'Plugin Not Executed - Plugin Not Active -  Suspended or Deleted ---> {0} '.format(self.name))
        else:
            AgentLogger.log(AgentLogger.PLUGINS, 'Plugin Not Executed - Plugin Type Not Supported ---> {0} '.format(self.name))
            error_msg='plugin file type not supported'
            com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.populateIgnorePluginsList(self.name,error_msg)
            AgentConstants.UPDATE_PLUGIN_INVENTORY=True
            
            
    def executeScript(self):
        dictToReturn = {}
        result = True
        stdOutput=''
        stdErr=''
        try:
            executorObj = AgentUtil.Executor()
            executorObj.setLogger(AgentLogger.PLUGINS)
            executorObj.setTimeout(30)
            if self.command is not None:
                executorObj.setCommand(self.command)
                executorObj.executeCommand()
                dictToReturn['result'] = executorObj.isSuccess()
                retVal    = executorObj.getReturnCode()
                stdOutput = executorObj.getStdOut()
                stdErr    = executorObj.getStdErr()
                if retVal is not None:
                    dictToReturn['exit_code'] = retVal
                if self.fileType=='.py' and self.pluginType!='nagios':
                    if not stdOutput == None and stdOutput!='':
                        dictToReturn['output'] = json.loads(stdOutput)
                else:
                    dictToReturn['output'] = stdOutput.rstrip('\n')
                if not stdErr == None and stdErr!='':
                    dictToReturn['error'] = AgentUtil.getModifiedString(stdErr,100,100)
                #AgentLogger.log(AgentLogger.PLUGINS,'finale output --- {0}'.format(dictToReturn))
            else:
                AgentLogger.log(AgentLogger.PLUGINS, 'Command is NULL for the Plugin ==== {0}'.format(self.name))
                result = False
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], '********* Exception While Executing the Script*********' + repr(e))
            traceback.print_exc()
        finally:
            return dictToReturn, result
    
    def doPluginDataValidation(self,upload_dict):
        try:
            #AgentLogger.log(AgentLogger.PLUGINS,'upload dict --> {0}'.format(upload_dict))
            if 'data' in upload_dict and upload_dict['data']:
                data_dict = upload_dict['data']
                for key, value in data_dict.items():
                    if key not in DONT_VALIDATE:
                        float_val=isinstance(value, float)
                        int_val=isinstance(value, int)
                        if float_val:
                            final_value='{:.2f}'.format(value)
                            data_dict[key]=final_value
                        if int_val:
                            integer_value=float(value)
                            final_value='{:.2f}'.format(integer_value)
                            data_dict[key]=final_value
                upload_dict['data']=data_dict
            else:
                AgentLogger.log(AgentLogger.PLUGINS, 'Data Validation - There is no Data in Upload dictionary  ===> '+repr(upload_dict))
        except Exception as e:
            traceback.print_exc()
        return upload_dict
        
    def postPluginExecution(self,key, upload_dict):
        try:
            global IGNORED_PLUGINS_CONF_FILE
            global IGNORED_PLUGINS
            if key in IGNORED_PLUGINS_CONF_FILE['ignored_plugins']:
                AgentLogger.log(AgentLogger.PLUGINS, "Plugin "+self.name+" is in ignore state "+str(IGNORED_PLUGINS[key]))
                return
            if key in IGNORED_PLUGINS and int(upload_dict['availability']) == 0:
                IGNORED_PLUGINS[key]['count'] = IGNORED_PLUGINS[key]['count']+1
                if IGNORED_PLUGINS[key]['count'] == 12:
                    #create ignore file
                    try:
                        with open(AgentConstants.AGENT_IGNORED_PLUGINS_FILE, 'w')as fp:
                            IGNORED_PLUGINS_CONF_FILE['ignored_plugins'].append(key)
                            fp.write(json.dumps(IGNORED_PLUGINS_CONF_FILE))
                        IGNORED_PLUGINS[key]['count'] = 0
                        AgentLogger.log(AgentLogger.PLUGINS, "plugin has been added to ignore conf file") 
                    except Exception as e:
                        traceback.print_exc()
                AgentLogger.log(AgentLogger.PLUGINS, "Plugin "+self.name+" hasn't be registered and throws error ignore count "+str(IGNORED_PLUGINS[key]))
                return
            upload_dict=self.doPluginDataValidation(upload_dict)
            global PLUGIN_CONF_DICT
            PLUGIN_CONF_DICT = PluginUtils.getPluginConfDict()
            config_Change = False
            if not self.ispluginRegistered:
                AgentLogger.log([AgentLogger.MAIN,AgentLogger.PLUGINS], 'Plugin Registration ===> '+repr(self.name)+'\n')
                if len(PluginUtils.PLUGIN_CONF_DICT) < int(AgentUtil.AGENT_CONFIG.get('AGENT_INFO','count')):
                    upload_dict['type'] = key
                    configDict={}
                    if key not in PLUGIN_CONF_DICT:
                        PLUGIN_CONF_DICT.setdefault(key,{})
                    if 'plugin_version' not in upload_dict['data']:
                        configDict['version']="1"
                    else:
                        configDict['version']=upload_dict['data']['plugin_version']
                    if 'heartbeat_required' not in upload_dict['data']:
                        configDict['heartbeat_required']='true'
                    else:
                        configDict['heartbeat_required']=upload_dict['data']['heartbeat_required']
                    PLUGIN_CONF_DICT[key]['version']=configDict['version']
                    PLUGIN_CONF_DICT[key]['heartbeat_required']=configDict['heartbeat_required']
                    
                    registerScript(key, upload_dict)
                else:
                    AgentLogger.log(AgentLogger.PLUGINS, 'Plugin Count Exceeds So moving to Ignore List ===> '+repr(key))
                    AgentLogger.log(AgentLogger.PLUGINS, 'Plugin Count ===> '+repr(len(PluginUtils.PLUGIN_CONF_DICT)))
                    PluginHandler.populateIgnorePluginsList(key,'plugin count exceeded')
                    PluginUtils.removePluginConfig(key)
            else:
                #1 Version Check
                if 'plugin_version' in upload_dict['data'] and 'version' in PLUGIN_CONF_DICT[key]:
                    previous_Version = PLUGIN_CONF_DICT[key]['version']
                    current_Version = upload_dict['data']['plugin_version']
                    if int(current_Version) > int(previous_Version):
                        config_Change=True
                        PLUGIN_CONF_DICT[key]['version']=current_Version
                #2 heart beat check
                if 'heartbeat_required' in upload_dict['data'] and 'heartbeat_required' in PLUGIN_CONF_DICT[key]:
                    previous_HeartBeat = PLUGIN_CONF_DICT[key]['heartbeat_required']
                    current_HeartBeat = upload_dict['data']['heartbeat_required']
                    if str(current_HeartBeat).lower() != str(previous_HeartBeat).lower():
                        config_Change=True
                        PLUGIN_CONF_DICT[key]['heartbeat_required']=current_HeartBeat
                if config_Change:
                    temp_Dict={}
                    temp_Dict.setdefault(key,{})
                    temp_Dict[key]=PLUGIN_CONF_DICT[key]
                    PluginUtils.updateDictToFile(temp_Dict)
                uploadScriptResponse(key, upload_dict, PLUGIN_CONF_DICT,config_Change)
        except Exception as e:
            traceback.print_exc()
                
    
    def parseShellPlugins(self,outputDict):
        upload_dict = {}
        output_dict = {}
        file=self.name
        if 'error' in outputDict and outputDict['error']!='':
                upload_dict['availability']=0
                upload_dict['data']={}
                upload_dict['message']=outputDict['error']
                AgentLogger.log(AgentLogger.PLUGINS,'Plugin Output  =====> {0}'.format(outputDict))
                AgentLogger.log(AgentLogger.PLUGINS,'Error Output  =====> {0}'.format(upload_dict))
        else:
            if 'output' in outputDict:
                script_output = outputDict['output']
            if script_output.startswith('{') and script_output.endswith('}'):
                outputDict['output']=json.loads(script_output)
                self.parsePyPlugins(outputDict)
                return
            else:
                import re
                list_dict=re.split(r'\|', script_output.rstrip('\t'))
                for entry in list_dict:
                    str_entry=str(entry)
                    list_elem=str_entry.split(":")
                    output_dict[list_elem[0]]=list_elem[1]
                if 'status' in output_dict and int(output_dict['status'])==0:
                    err_msg='error message not configured'
                    if 'msg' in output_dict and output_dict['msg']!='':
                        err_msg=output_dict['msg']
                    upload_dict['availability']=0
                    upload_dict['data']={}
                    upload_dict['message']=err_msg
                else:
                    upload_dict['availability']=1
                    upload_dict['data']=output_dict
                    if 'units' in upload_dict['data']:
                        units_data=upload_dict['data'].pop('units')
                        units_data=units_data[1:-1]
                        units_dict=re.split(r'\,', units_data.rstrip('\t'))
                        units_pair={}
                        for units_entry in units_dict:
                            pair=str(units_entry)
                            elem=pair.split("-")
                            units_pair[elem[0]]=elem[1]
                            upload_dict['units']=units_pair
        self.postPluginExecution(file, upload_dict)
            
    def parsePyPlugins(self,outputDict):
        upload_dict = {}
        file=self.name
        error_Dict={}
        if 'output' in outputDict:
            script_output = outputDict['output']
        if 'error' in outputDict:
            error_Dict['status']=0
            error_Dict['msg']=outputDict['error']
            AgentLogger.log(AgentLogger.PLUGINS,'Plugin Output  =====> {0}'.format(outputDict))
            AgentLogger.log(AgentLogger.PLUGINS,'Error Output  =====> {0}'.format(error_Dict))
        
        if 'status' in error_Dict and int(error_Dict['status'])==0:
            upload_dict['message']=error_Dict['msg']
            upload_dict['availability']=0
            upload_dict['data']={}
        elif 'status' in script_output and int(script_output['status'])==0:
            err_msg='error message not configured'
            if 'msg' in script_output and script_output['msg']!='':
                err_msg=script_output['msg']
            upload_dict['message']=err_msg
            upload_dict['availability']=0
            upload_dict['data']={}
            if 'plugin_version' in script_output:
                upload_dict['plugin_version']=script_output['plugin_version']
        else:
            upload_dict['availability']=1
            upload_dict['data']=script_output
            if 'units' in upload_dict['data']:
                upload_dict['units']=upload_dict['data'].pop('units')
        self.postPluginExecution(file, upload_dict)
    
    def parseNagiosPlugins(self,outputDict):
        key = self.name
        upload_dict={}
        upload_dict['data'] = {}
        script_output = ""
        if 'output' in outputDict:
            script_output = outputDict['output']
            
        if 'error' in outputDict:
            #upload_dict['status'] = 0
            upload_dict['availability'] = 0
            upload_dict['msg'] = outputDict['error']
        elif 'exit_code' in outputDict and outputDict['exit_code'] >= 2:
            #upload_dict['status'] = 0
            upload_dict['availability']=0
            if '|' in script_output:
                self.getPerfData(upload_dict, script_output)    
                upload_dict['msg'] = script_output.split('|')[0]
            else:
                upload_dict['msg'] = script_output if not script_output.strip() == "" else "error occurred during plugin execution"
        else:
            #upload_dict['status']=1
            upload_dict['availability']=1
            upload_dict=self.getPerfData(upload_dict,script_output)
            if 'exit_code' in outputDict:
                upload_dict['data'][self.name+'_status']=outputDict['exit_code']

        upload_dict['data']['plugin_version'] = self.nagiosVersion
        self.postPluginExecution(key, upload_dict)
        
    def getPerfData(self,upload_dict,parsable_Out):
        if "|" in parsable_Out:
                perfData = parsable_Out.split("|")
                if len(perfData) > 1:
                    list_perf = perfData[1].strip().split(" ")
                    for each in list_perf:
                        list_elem = each.split(";")[0].split("=")
                        match = re.match('(?P<number>[\d]+[.]?\d*)(?P<units>.*)', list_elem[1].strip())
                        if match and 'number' in match.groupdict():
                            upload_dict['data'][list_elem[0]] = match.groupdict()['number']
                            if 'units' in match.groupdict():
                                if 'units' not in upload_dict:
                                    upload_dict['units']={}
                                upload_dict['units'][list_elem[0]] = match.groupdict()['units']
                        else:
                            upload_dict['data'][list_elem[0]] = list_elem[1].strip()
                         
        else:
            upload_dict['data']['output']=parsable_Out
        return upload_dict
    
class PluginHandler(DesignUtils.Singleton):
    _plugins_Dict = {}
    _plugins_List = []
    _lock = threading.Lock()
    
    def __init__(self):
        self._createNagiosFile()
        #self._serviceChecksForPlugin()
        PluginUtils.updatePluginConfigDict()
        #self._loadDefaultPlugins()
        #self._loadPluginsList()
    
    def getPluginList(self):
        return self._plugins_List
    
    def _createNagiosFile(self):
        try:
            if not os.path.exists(AgentConstants.AGENT_PLUGINS_DIR):
               AgentLogger.log(AgentLogger.PLUGINS,'creating plugins directory')
               os.mkdir(AgentConstants.AGENT_PLUGINS_DIR)
               src = AgentConstants.AGENT_PLUGINS_TMP_DIR+AgentConstants.AGENT_PLUGINS_NAGIOS_FILE
               dst = AgentConstants.AGENT_PLUGINS_DIR+AgentConstants.AGENT_PLUGINS_NAGIOS_FILE
               from shutil import copyfile
               copyfile(src, dst)
        except Exception as e:
            traceback.print_exc() 
    
    def _serviceChecksForPlugin(self):
        tmp_Plugins=[]
        working_plugins=[]
        if os.path.exists(AgentConstants.AGENT_PLUGINS_LISTS_FILE):
            fileObj = PluginUtils.getPluginsListFileObj()
            bool_toReturn, dict_monitorsInfo = FileUtil.readData(fileObj)
            if dict_monitorsInfo:
                plugins = dict_monitorsInfo['plugins']
                for plug in plugins:
                    working_plugins.append(plug.split("/")[-1])
        for dirname, dirnames, filenames in os.walk(AgentConstants.AGENT_PLUGINS_TMP_DIR):
            for filename in filenames:
                if filename=='nagios_plugins.json':
                    continue
                tmp_Plugins.append(filename)
        AgentLogger.log(AgentLogger.PLUGINS,'In Built Plugins ---> {} && Working Plugins ---> {}'.format(tmp_Plugins,working_plugins))
        self._pluginsPreCheck(tmp_Plugins,working_plugins)
    
    def _pluginsPreCheck(self,tmp_plugins,working_plugins):
        if tmp_plugins:
            for entry in tmp_plugins:
                try:
                    copyPlugin = False
                    name = entry.split('.')
                    name = name[0].lower()
                    if entry in working_plugins:
                        AgentLogger.log(AgentLogger.PLUGINS,'{} already present in the Working List So not sent for service check'.format(entry))
                        AgentLogger.log(AgentLogger.PLUGINS,'====================================================================')
                        continue
                    if not entry.endswith(".py"):
                        AgentLogger.log(AgentLogger.PLUGINS,'{} Service Check Not allowed for plugin ===> '.format(entry))
                        AgentLogger.log(AgentLogger.PLUGINS,'====================================================================')
                        continue
                    if PluginUtils.levelOneCheck(name):        
                            AgentLogger.log(AgentLogger.PLUGINS,'Level 1 Service Check Passed For Plugin ===== {}'.format(entry))
                            copyPlugin = True
                    if not copyPlugin and PluginUtils.levelTwoCheck(name):
                            AgentLogger.log(AgentLogger.PLUGINS,'Level 2 Data Directory Check Passed For Plugin ===== {}'.format(entry))
                            copyPlugin = True
                    if copyPlugin:
                            from_dir = AgentConstants.AGENT_PLUGINS_TMP_DIR+name
                            to_dir = AgentConstants.AGENT_PLUGINS_DIR+name
                            shutil.copytree(from_dir,to_dir)
                    else:
                        AgentLogger.log(AgentLogger.PLUGINS,'==== All three checks failed So Not Deploying the plugin ===='.format(name))
                except Exception as e:
                    AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception In Plugins Pre Check  *************************** ' + repr(e))
                    traceback.print_exc()
                
                    
    def _loadPluginsList(self):
        dict_monitorsInfo={}
        try:
            fileObj = PluginUtils.getPluginsListFileObj()
            bool_toReturn, dict_monitorsInfo = FileUtil.readData(fileObj)
            
            if os.path.exists(AgentConstants.AGENT_PLUGINS_CONF_FILE):
                try:
                    fileObj = PluginUtils.getPluginsConfFileObj()# -- for nagios
                    bool_toReturn, dict_nagiosMonitorsInfo = FileUtil.readData(fileObj)
                    dict_monitorsInfo.update(dict_nagiosMonitorsInfo)
                except Exception as e:
                    AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while loading Nagios Plugins List  *************************** ' + repr(e))
                    traceback.print_exc()
            
            for plugin_type in dict_monitorsInfo:
                for each_item in dict_monitorsInfo[plugin_type]:
                    self.__class__._plugins_List.append(each_item)
                    plugin = Plugins()
                    plugin.setPluginDetails(each_item,plugin_type)
                    #plugin.setPluginStatus()
                    self.__class__._plugins_Dict[each_item] = plugin
            AgentLogger.log(AgentLogger.PLUGINS,'Plugins List    ==========> {0}'.format(self.__class__._plugins_List))
#             if self.__class__._plugins_List==[]:
#                 com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.updateInventoryToServer()
            AgentLogger.log(AgentLogger.PLUGINS, '------------------------------------------------------------------------------------------------------')
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while loading Plugins List  *************************** ' + repr(e))
            traceback.print_exc()
    
    def _loadDefaultPlugins(self):
        default_Plugins=[]
        try:
            if not os.path.exists(AgentConstants.AGENT_PLUGINS_LISTS_FILE):
                AgentUtil.FileUtil.createFile(AgentConstants.AGENT_PLUGINS_LISTS_FILE,AgentLogger.PLUGINS)
            
            default_Plugins = PluginUtils.fetchExecutablePlugins()
            AgentLogger.debug(AgentLogger.PLUGINS,'Executable Plugins =====> {}'.format(json.dumps(default_Plugins)))
            dict_monitorsInfo={}
            dict_monitorsInfo['plugins']=default_Plugins
            fileObj = PluginUtils.getPluginsListFileObj()
            fileObj.set_data(dict_monitorsInfo)
            fileObj.set_mode('wb')
            with customFileLock:
                bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while loading Plugins List  *************************** ' + repr(e))
            traceback.print_exc()
    
    def deletePlugins(self):
        try:
            #AgentLogger.log(AgentLogger.PLUGINS,'--- Delete Plugins Called ---- ')
            self.__class__._plugins_List=[]
            self.__class__._plugins_Dict.clear()
#             AgentLogger.log(AgentLogger.PLUGINS,'--- Reloaded List ---- {0}'.format(self.__class__._plugins_List))
#             AgentLogger.log(AgentLogger.PLUGINS,'--- Reloaded Dictionary ---- {0}'.format(self.__class__._plugins_Dict))
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' CheckError | *************************** Exception while deleting PLUGINS *************************** ' + repr(e))
            traceback.print_exc()
    
    def loadPlugins(self):
        lastModifiedTime = max(os.path.getmtime(root) for root,_,_ in os.walk(AgentConstants.AGENT_PLUGINS_DIR))
        global previousLastModifiedTime
        if lastModifiedTime > previousLastModifiedTime:
            AgentLogger.log(AgentLogger.PLUGINS,'Loading Plugins ')
            import fnmatch
            no_of_folders = len(fnmatch.filter(os.listdir(AgentConstants.AGENT_PLUGINS_DIR),'*'))
            if no_of_folders > 100:
                AgentConstants.AGENT_SCHEDULER_NO_OF_PLUGIN_WORKERS = math.ceil(no_of_folders/20)
                AgentScheduler.Scheduler.startScheduler('PluginScheduler', AgentConstants.AGENT_SCHEDULER_NO_OF_PLUGIN_WORKERS)
                AgentLogger.log(AgentLogger.PLUGINS,'scheduling  {0}'.format(AgentConstants.AGENT_SCHEDULER_NO_OF_PLUGIN_WORKERS))
            else :
                AgentConstants.AGENT_SCHEDULER_NO_OF_PLUGIN_WORKERS = 5
            with self._lock:
                self.deletePlugins()
            self._loadDefaultPlugins()
            self._loadPluginsList()
            previousLastModifiedTime = lastModifiedTime
            self.doPluginDC()
              
    
    def load_ignored_plugins(self):
        global IGNORED_PLUGINS_CONF_FILE
        IGNORED_PLUGINS_CONF_FILE['ignored_plugins'] = []
        try:
            if os.path.isfile(AgentConstants.AGENT_IGNORED_PLUGINS_FILE):
                bool_status,IGNORED_PLUGINS_CONF_FILE = AgentUtil.loadDataFromFile(AgentConstants.AGENT_IGNORED_PLUGINS_FILE)
                if not 'ignored_plugins' in IGNORED_PLUGINS_CONF_FILE:
                    IGNORED_PLUGINS_CONF_FILE['ignored_plugins'] = []
        except Exception as e:
            AgentLogger.log(AgentLogger.PLUGINS,'==== Exception while reading ignored_plugins file ====')
            traceback.print_exc()
    
    def loadPluginTask(self):
        try:
            task = self.invokePlugins
            scheduleInfo = AgentScheduler.ScheduleInfo()
            scheduleInfo.setSchedulerName('AgentScheduler')
            scheduleInfo.setTaskName('PluginLoader')
            scheduleInfo.setTime(time.time())
            scheduleInfo.setTask(task)
            scheduleInfo.setIsPeriodic(True)
            scheduleInfo.setInterval(AgentConstants.PLUGINS_LOAD_INTERVAL)
            scheduleInfo.setLogger(AgentLogger.PLUGINS)
            AgentScheduler.schedule(scheduleInfo)
            #AgentLogger.log(AgentLogger.PLUGINS, ' tasks --- {0}'.format(AgentScheduler.getSchedulerTasks('PluginScheduler')))
        except Exception as e:
            traceback.print_exc()
    
    def invokePlugins(self):
        try:
            self.load_ignored_plugins()
            self.loadPlugins()
        except Exception as e:
            traceback.print_exc()

    def doPluginDC(self):
        try:
            with self._lock:
                global collection_Time
                collection_Time = AgentUtil.getTimeInMillis()
                for pluginName, plugin in self.__class__._plugins_Dict.items():
                    task = self.pluginExecutor
                    taskArgs = plugin
                    scheduleInfo = AgentScheduler.ScheduleInfo()
                    scheduleInfo.setSchedulerName('PluginScheduler')
                    scheduleInfo.setTaskName(pluginName)
                    scheduleInfo.setTime(time.time())
                    scheduleInfo.setTask(task)
                    scheduleInfo.setTaskArgs(taskArgs)
                    scheduleInfo.setIsPeriodic(True)
                    scheduleInfo.setInterval(AgentConstants.PLUGINS_DC_INTERVAL)
                    scheduleInfo.setLogger(AgentLogger.PLUGINS)
                    AgentScheduler.schedule(scheduleInfo)
                #self.doZipAction()
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], '************* Exception while DC of Plugin ****' + repr(e))
            traceback.print_exc()
    
    def pluginExecutor(self,plugin):
        try:
            plugin.setPluginStatus()
            plugin.pluginDC()
        except Exception as e:
            traceback.print_exc()
    
    def initiateZipTask(self):
        try:
            task = self.doZipAction
            scheduleInfo = AgentScheduler.ScheduleInfo()
            scheduleInfo.setSchedulerName('AgentScheduler')
            scheduleInfo.setTaskName('PluginZipper')
            scheduleInfo.setTime(time.time())
            scheduleInfo.setTask(task)
            scheduleInfo.setIsPeriodic(True)
            scheduleInfo.setInterval(AgentConstants.PLUGINS_ZIP_INTERVAL)
            scheduleInfo.setLogger(AgentLogger.PLUGINS)
            AgentScheduler.schedule(scheduleInfo)
            AgentLogger.log(AgentLogger.PLUGINS, '------------------------------------------------------------------------------------------------------')
        except Exception as e:
            traceback.print_exc()
    
    def initiatePluginDC(self):
        try:
            self._loadDefaultPlugins()
            self._loadPluginsList()
            self.doPluginDC()
        except Exception as e:
            traceback.print_exc()
    
    def doZipAction(self):
        listOfFiles=[]
        for dirname, dirnames, filenames in os.walk(AgentConstants.AGENT_DATA_DIR):
            for file in filenames:  
                if 'Plugin_' in file:
                    listOfFiles.append(file)
                if len(listOfFiles) == AgentConstants.PLUGINS_ZIP_FILE_SIZE:
                    AgentLogger.log(AgentLogger.PLUGINS,'file size matches constant value --- '+repr(len(listOfFiles)))
                    self.createZipFile(listOfFiles)
                    listOfFiles=[]
        if len(listOfFiles) > 0:
            AgentLogger.log(AgentLogger.PLUGINS,'No of files zipped --- '+repr(len(listOfFiles)))
            self.createZipFile(listOfFiles)
            
    def createZipFile(self,listOfFiles):
        try:
            global collection_Time
            dict_requestParameters={}
            zipAndUploadInfo = FileZipAndUploadInfo()
            zipAndUploadInfo.filesToZip = listOfFiles
            zipAndUploadInfo.zipFileName = ZipUtil.getUniquePluginZipFileName(AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),''+str(collection_Time))
            zipAndUploadInfo.zipFilePath = AgentConstants.AGENT_UPLOAD_DIR+'/' + zipAndUploadInfo.zipFileName
            dict_requestParameters['agentkey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            dict_requestParameters['apikey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
            dict_requestParameters['zipname'] = zipAndUploadInfo.zipFileName
            zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
            zipAndUploadInfo.uploadServlet = AgentConstants.PLUGIN_DATA_POST_SERVLET
            AgentBuffer.getBuffer(AgentConstants.FILES_TO_ZIP_BUFFER).add(zipAndUploadInfo)
        except Exception as e:
            AgentLogger.log(AgentLogger.STDERR,'exception while creating zip '+repr(e))
            traceback.print_exc()
            
    def removePluginFromIgnoreList(self,pluginName):
        global IGNORED_PLUGINS
        if pluginName in IGNORED_PLUGINS:
            if 'ignore_file' in IGNORED_PLUGINS[pluginName]:
                try:
                    os.remove(IGNORED_PLUGINS[pluginName]['ignore_file'])
                except Exception as _:
                    pass
            IGNORED_PLUGINS.pop(pluginName)
        AgentLogger.log(AgentLogger.PLUGINS,'==== Ignored Plugins List  ===='+repr(IGNORED_PLUGINS))

    def populateIgnorePluginsList(self,pluginName,errorMsg):
        global IGNORED_PLUGINS
        global IGNORED_PLUGINS_CONF_FILE
        AgentLogger.log(AgentLogger.PLUGINS,'entry in populateIgnorePluginsList List of IGNORED_PLUGINS ====> {} IGNORED_PLUGINS_CONF_FILE ====> {}'.format(json.dumps(IGNORED_PLUGINS), json.dumps(IGNORED_PLUGINS_CONF_FILE))+'\n')
        if pluginName not in IGNORED_PLUGINS:
            IGNORED_PLUGINS[pluginName] = {}
            IGNORED_PLUGINS[pluginName]['count'] = 1
            IGNORED_PLUGINS[pluginName]['error_msg'] = errorMsg
        AgentLogger.log(AgentLogger.PLUGINS,'exit in populateIgnorePluginsList List of IGNORED_PLUGINS ====> {} IGNORED_PLUGINS_CONF_FILE ====> {}'.format(json.dumps(IGNORED_PLUGINS), json.dumps(IGNORED_PLUGINS_CONF_FILE))+'\n')
        
    def reRegisterAllPlugins(self,dict_task):
        global IGNORED_PLUGINS
        global IGNORED_PLUGINS_CONF_FILE
        AgentLogger.log(AgentLogger.PLUGINS,'entry in re-registration | List of IGNORED_PLUGINS ====> {} IGNORED_PLUGINS_CONF_FILE ====> {}'.format(json.dumps(IGNORED_PLUGINS), json.dumps(IGNORED_PLUGINS_CONF_FILE)))
        if not 'PLUGIN_NAME' in dict_task:
            if os.path.isfile(AgentConstants.AGENT_IGNORED_PLUGINS_FILE):
                os.remove(AgentConstants.AGENT_IGNORED_PLUGINS_FILE)
            IGNORED_PLUGINS = {}
            IGNORED_PLUGINS_CONF_FILE = {}
            IGNORED_PLUGINS_CONF_FILE['ignored_plugins'] = []
        else:
            bool_status,ignored_dict = AgentUtil.loadDataFromFile(AgentConstants.AGENT_IGNORED_PLUGINS_FILE)
            if ignored_dict:
                pname = dict_task['PLUGIN_NAME']
                plist = ignored_dict['ignored_plugins']
                if pname in plist:
                    plist.remove(pname)
                    try:
                        with open(AgentConstants.AGENT_IGNORED_PLUGINS_FILE, 'w') as fp:
                            ignored_dict['ignored_plugins']=plist
                            fp.write(json.dumps(ignored_dict))
                            AgentLogger.log(AgentLogger.PLUGINS,'plugin list after re-register action   -- {0}'.format(json.dumps(ignored_dict)))
                            IGNORED_PLUGINS.pop(pname)
                    except Exception as e:
                        traceback.print_exc()
                else:
                    AgentLogger.log(AgentLogger.PLUGINS,' plugin not present in the ignored list  -- {0}'.format(json.dumps(plist)))
        AgentLogger.log(AgentLogger.PLUGINS,'exit in re-registration | List of IGNORED_PLUGINS ====> {} IGNORED_PLUGINS_CONF_FILE ====> {}'.format(json.dumps(IGNORED_PLUGINS), json.dumps(IGNORED_PLUGINS_CONF_FILE)))
        
    def updateInventoryToServer(self):
        inventory_dict={}
        plugins_dict=None
        if not AgentConstants.PLUGIN_FOLDER_DICT == None:
            inventory_dict = AgentConstants.PLUGIN_FOLDER_DICT
        if os.path.exists(AgentConstants.AGENT_PLUGINS_SITE24X7ID):
            bool_FileLoaded, plugins_dict = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID)
        if plugins_dict:
            for key,value in plugins_dict.items():
                temp_dict = {}
                temp_dict['status']=value['status']
                if 'version' in value:
                    temp_dict['version']=value['version']
                if 'heartbeat_required' in value:
                    temp_dict['heartbeat_required']=value['heartbeat_required']
                if 'error_msg' in value:
                    temp_dict['error_msg']=value['error_msg']
                inventory_dict[key]=temp_dict
        if IGNORED_PLUGINS:
            for item,value in IGNORED_PLUGINS.items():
                inventory_dict[item]={}
                inventory_dict[item]['status']=2
                inventory_dict[item]['error_msg']=value['error_msg']
        try:
            if not inventory_dict==None:
                str_servlet = AgentConstants.DATA_AGENT_HANDLER_SERVLET
                dict_requestParameters      =   {
                'agentKey'  :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),
                'action'  :   AgentConstants.PLUGIN_INVENTORY,
                'bno' : AgentConstants.AGENT_VERSION,
                'custID'  :   AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')        
                }
                str_jsonData = json.dumps(inventory_dict)#python dictionary to json string
                AgentLogger.log(AgentLogger.PLUGINS, 'Plugin Inventory to be sent : '+repr(str_jsonData))
                str_url = None
                if not dict_requestParameters == None:
                    str_requestParameters = urlencode(dict_requestParameters)
                    str_url = str_servlet + str_requestParameters
                requestInfo = com.manageengine.monagent.communication.CommunicationHandler.RequestInfo()
                requestInfo.set_loggerName(AgentLogger.PLUGINS)
                requestInfo.set_method(AgentConstants.HTTP_POST)
                requestInfo.set_url(str_url)
                requestInfo.set_data(str_jsonData)
                requestInfo.add_header("Content-Type", 'application/json')
                requestInfo.add_header("Accept", "text/plain")
                requestInfo.add_header("Connection", 'close')
                (isSuccess, int_errorCode, dict_responseHeaders, dict_responseData) = com.manageengine.monagent.communication.CommunicationHandler.sendRequest(requestInfo)
        except Exception as e:
            traceback.print_exc()
    
#filename can be used as folder name too
def fetchFileType(fileName):
    fileName, fileExt = os.path.splitext(fileName)
    return fileName,fileExt

def getPluginStatus(name):
        bool_pluginreg = False
        plugin_status = 0
        try:
            tempIdDict = PluginUtils.getPluginConfDict()
            if tempIdDict and name in tempIdDict:
                    if 'pluginkey' in tempIdDict[name]:
                        bool_pluginreg = True
                    plugin_status = tempIdDict[name]['status']
        except Exception as e:
            traceback.print_exc()
        return bool_pluginreg,plugin_status
  
def uploadScriptResponse(key, upload_dict, tempIdDict,config_Change):
    try:
        upload_dict['ct'] = AgentUtil.getTimeInMillis()
        if 'units' in upload_dict and config_Change==False:
                upload_dict.pop('units')
        if 'heartbeat_required' in upload_dict['data']:
            upload_dict['data'].pop('heartbeat_required')
        
        if 'plugin_version' in upload_dict['data']:
            version=upload_dict['data']['plugin_version']
            upload_dict['data'].pop('plugin_version')
        elif 'plugin_version' in upload_dict:
            version=upload_dict['plugin_version']
            upload_dict.pop('plugin_version')
        else:
            version="1"
        upload_dict['version'] =version
        pluginkey= tempIdDict[key]['pluginkey']
        if config_Change:
            upload_dict['config_data']=tempIdDict[key]
        savePluginData(upload_dict,pluginkey)
    except Exception as e:
        AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while uploading response to Server *************************** ' + repr(e))
        traceback.print_exc()
            
def registerScript(key, upload_dict,str_loggerName=AgentLogger.PLUGINS):
    dict_requestParameters = {}
    requestInfo = com.manageengine.monagent.communication.CommunicationHandler.RequestInfo()
    try:
        dict_requestParameters['agentkey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dict_requestParameters['apikey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dict_requestParameters['plugin_name'] = key 
        dict_requestParameters['display_name'] = key+"-"+AgentConstants.HOST_NAME
        dict_requestParameters['ct'] = AgentUtil.getTimeInMillis()
        dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
        if 'plugin_version' in upload_dict['data']:
            version=upload_dict['data']['plugin_version']
            upload_dict['data'].pop('plugin_version')
        else:
            version="1"
        if 'heartbeat_required' in upload_dict['data']:
            heartbeat=upload_dict['data']['heartbeat_required']
            upload_dict['data'].pop('heartbeat_required')
        else:
            heartbeat="true"
        AgentLogger.log(AgentLogger.PLUGINS, 'Registering Plugin =======> {0}'.format(json.dumps(upload_dict)))
        dict_requestParameters['version'] =version
        dict_requestParameters['heartbeat_required'] = heartbeat
        str_servlet = AgentConstants.PLUGIN_REGISTER_SERVLET
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        str_dataToSend = json.dumps(upload_dict)
        str_contentType = 'application/json'
        requestInfo.set_loggerName(AgentLogger.PLUGINS)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_data(str_dataToSend)
        requestInfo.set_dataType(str_contentType)
        requestInfo.add_header("Content-Type", str_contentType)
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        (bool_isSuccess, errorCode, dict_responseHeaders, dict_responseData) = com.manageengine.monagent.communication.CommunicationHandler.sendRequest(requestInfo)
        if not bool_isSuccess and errorCode!=200:
            PluginUtils.removePluginConfig(key)
        com.manageengine.monagent.communication.CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'PLUGINS')
    except Exception as e:
        AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while registering Plugin to Server *************************** ' + repr(e))
        traceback.print_exc()

def getCmdForExecution(fileExt, cmd):
    command = None
    try:
        if '---site24x7version' in cmd:
            command=cmd.split('---site24x7version')[0]
            AgentLogger.log(AgentLogger.PLUGINS,' nagios cmd ==== {0}'.format(command))
        else:
            if platform.system() == 'Darwin':
                command = "sudo "+cmd
            else:
                command = cmd
    except Exception as e:
        AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], ' *************************** Exception while fetching command for execution *************************** ' + repr(e))
        traceback.print_exc()
    return command

def getNagiosVersion(pluginType,cmd):
    version_Value=1
    try:
        if pluginType == 'nagios' and '---site24x7version' in cmd:
            version_Value=cmd.split('---site24x7version=')[1]
            AgentLogger.log(AgentLogger.PLUGINS,' nagios Version ==== {0}'.format(version_Value))
    except Exception as e:
         AgentLogger.log(AgentLogger.PLUGINS,' Exception in getting nagios version ')
         traceback.print_exc()
    return version_Value

def checkForPluginSupport(file,pluginType):
    if pluginType == 'nagios':
        return True
    if file=='.py' or file=='.sh':
        return True
    else:
        return False

def savePluginData(pluginData,key):
    try:
        AgentLogger.log(AgentLogger.PLUGINS,'Plugin Data for Save : '+json.dumps(pluginData))
        str_fileName = FileUtil.getUniquePluginFileName(key,pluginData['ct'])
        str_filePath = AgentConstants.AGENT_DATA_DIR + '/' + str_fileName
        fileObj = AgentUtil.FileObject()
        fileObj.set_fileName(str_fileName)
        fileObj.set_filePath(str_filePath)
        fileObj.set_data(pluginData)
        fileObj.set_dataType('json')
        fileObj.set_mode('wb')
        fileObj.set_dataEncoding('UTF-16LE')
        fileObj.set_logging(False)
        fileObj.set_loggerName(AgentLogger.PLUGINS)            
        bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
        if bool_toReturn:
            AgentLogger.debug(AgentLogger.PLUGINS,'Statistics file name and saved to : '+str_fileName + str_filePath)
        #setZipAndUploadInfo([str_fileName])
    except Exception as e:
        AgentLogger.log([AgentLogger.UDP,AgentLogger.STDERR], ' *************************** Exception while saving plugin data *************************** '+ repr(e))
        traceback.print_exc()
