'''
Created on 08-Feb-2017

@author: giri
'''
from com.manageengine.monagent import AgentConstants
import subprocess, traceback, os, time, json, tarfile
from functools import wraps
from contextlib import contextmanager
from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import ZipManager

current_milli_time = lambda: int(round(time.time() * 1000))

@contextmanager
def s247_applog_communicator(filename):
    try:
        '''check if directory is present or not'''
        if not os.path.isdir(AgentConstants.APPLOG_S247_DMS_DIR_PATH):
            os.mkdir(AgentConstants.APPLOG_S247_DMS_DIR_PATH)
        filepath = os.path.join(AgentConstants.APPLOG_S247_DMS_DIR_PATH, filename+str(current_milli_time()))
        f = open(filepath, 'w')
        yield f
    except Exception as e:
        traceback.print_exc()
    finally:
        f.close()

def exceptionhandler(func):
    try:
        @wraps(func)
        def wrapper(*args, **kwargs):
            f = func(*args, **kwargs)
            return f
        return wrapper
    except Exception as e:
        if type(AgentConstants.APPLOG_PROCESS) is subprocess.Popen:
            AgentConstants.APPLOG_PROCESS.kill()   #kill subprocess
            AgentConstants.APPLOG_PROCESS.poll()   #poll and inform the os about pid
        traceback.print_exc()
        return False, "failure, "+e
        
@exceptionhandler
def start():
    if os.path.isfile(AgentConstants.APPLOG_EXEC_PATH): #have to check whether process is already running
        #AgentConstants.APPLOG_PROCESS = subprocess.Popen(["python3.4", AgentConstants.APPLOG_EXEC_PATH], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        AgentConstants.APPLOG_PROCESS = subprocess.Popen(AgentConstants.APPLOG_EXEC_PATH, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        time.sleep(5)
        if AgentConstants.APPLOG_PROCESS.poll() is None: 
            AgentLogger.log(AgentLogger.STDOUT,'start : Applog Agent Started Successfully')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'start : Applog Agent Already running')
    else:
        AgentLogger.log(AgentLogger.STDOUT,'start : Applog Agent file not present')
        

@exceptionhandler
def stop():
    if type(AgentConstants.APPLOG_PROCESS) is subprocess.Popen:
        AgentConstants.APPLOG_PROCESS.kill()   #kill subprocess
        time.sleep(5)
        AgentConstants.APPLOG_PROCESS.poll()  #poll and inform the os about pid
        AgentLogger.log(AgentLogger.STDOUT,'stop : Applog Agent Stopped')
    else:
        AgentLogger.log(AgentLogger.STDOUT,'stop : Applog Agent file not present')
        
@exceptionhandler
def restart():
    if type(AgentConstants.APPLOG_PROCESS) is subprocess.Popen:
        AgentConstants.APPLOG_PROCESS.kill()   #kill subprocess
        time.sleep(5)
        AgentConstants.APPLOG_PROCESS.poll()   #poll and inform the os about pid
        if os.path.isfile(AgentConstants.APPLOG_EXEC_PATH):
            #AgentConstants.APPLOG_PROCESS = subprocess.Popen(["python3.4",AgentConstants.APPLOG_EXEC_PATH], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            AgentConstants.APPLOG_PROCESS = subprocess.Popen(AgentConstants.APPLOG_EXEC_PATH, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            AgentLogger.log(AgentLogger.STDOUT, 'restart : Applog Agent Restarted')
    else:
        AgentLogger.log(AgentLogger.STDOUT,'restart : Applog Agent file not present')

@exceptionhandler
def configure(data):
    with s247_applog_communicator("conf.json.") as fp:
        fp.write(json.dumps(data))
    AgentLogger.log(AgentLogger.STDOUT, 'configure : configuration communicated by s24x7agent')

def install(data):
    deployment_success = True
    if not os.path.isfile(AgentConstants.APPLOG_EXEC_PATH):
        staticUrl = data['STATIC_URL']
        file_path=AgentConstants.AGENT_TEMP_DIR+'/applog_agent.zip'
        AgentLogger.log(AgentLogger.STDOUT,'install : Downloading Applog Agent From Static Server {0}'.format(staticUrl))
        bool_DownloadStatus = CommunicationHandler.downloadPlugin(staticUrl, file_path, AgentConstants.STATIC_SERVER_HOST, AgentLogger.STDOUT)
        if not bool_DownloadStatus:
            sagentUrl = data['SAGENT_URL']
            AgentLogger.log(AgentLogger.STDOUT,'install : Downloading Applog Agent From sagent {0}'.format(sagentUrl))
            bool_DownloadStatus = CommunicationHandler.downloadFile(sagentUrl,file_path,AgentLogger.STDOUT)
            if not bool_DownloadStatus:
                AgentLogger.log(AgentLogger.STDOUT,'install : Applog Agent Download Failed')
                deployment_success=False
            else:
                AgentLogger.log(AgentLogger.STDOUT,'install : Applog Agent Download Successfully via sagent')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'install : Applog Agent Download Successfully')
        
        if deployment_success:
            bool_Unzip=True
            try:
                AgentLogger.log(AgentLogger.STDOUT,'install : Going to extract Applog Agent Zip')
                with ZipManager.ZipManager(file_path) as zfp:
                    zfp.extractall(AgentConstants.AGENT_WORKING_DIR)
            except Exception as e:
                bool_Unzip=False
                AgentLogger.log(AgentLogger.STDOUT,'install : exception while extracting Applog Agent Zip')
                traceback.print_exc()
        if bool_Unzip:
            os.remove(file_path)
            AgentLogger.log(AgentLogger.STDOUT,'install : Applog Agent Zip File Removed Successfully')
            start();    
    else:
        AgentLogger.log(AgentLogger.STDOUT, 'install : Applog Agent already exist')

def upgrade(data):
    stop()
    deployment_success = True
    if os.path.isfile(AgentConstants.APPLOG_EXEC_PATH):
        staticUrl = data['STATIC_URL']
        file_path=AgentConstants.AGENT_TEMP_DIR+'/applog_agent.zip'
        AgentLogger.log(AgentLogger.STDOUT,'upgrade : Downloading Applog Agent From Static Server {0}'.format(staticUrl))
        bool_DownloadStatus = CommunicationHandler.downloadPlugin(staticUrl,file_path, AgentConstants.STATIC_SERVER_HOST, AgentLogger.STDOUT)
        if not bool_DownloadStatus:
            sagentUrl = data['SAGENT_URL']
            AgentLogger.log(AgentLogger.STDOUT,'upgrade : Downloading Applog Agent From sagent {0}'.format(sagentUrl))
            bool_DownloadStatus = CommunicationHandler.downloadFile(sagentUrl,file_path,AgentLogger.STDOUT)
            if not bool_DownloadStatus:
                AgentLogger.log(AgentLogger.STDOUT,'upgrade : Applog Agent Download Failed')
                deployment_success=False
            else:
                AgentLogger.log(AgentLogger.STDOUT,'upgrade : Applog Agent Download Successfully via sagent')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'upgrade : Applog Agent Download Successfully')
        
        if deployment_success:
            bool_Unzip=True
            try:
                AgentLogger.log(AgentLogger.STDOUT,'upgrade : Going to extract Applog Agent Zip')
                with ZipManager.ZipManager(file_path) as zfp:
                    zfp.extractall(AgentConstants.AGENT_WORKING_DIR)
            except Exception as e:
                bool_Unzip=False
                AgentLogger.log(AgentLogger.STDOUT,'upgrade : exception while extracting Applog Agent Zip')
                traceback.print_exc()
        if bool_Unzip:
            os.remove(file_path)
            AgentLogger.log(AgentLogger.STDOUT,'upgrade : Applog Agent Zip File Removed Successfully')
            start();    
    else:
        AgentLogger.log(AgentLogger.STDOUT, 'upgrade : Applog Agent not exist')

