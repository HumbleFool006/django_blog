#!/bin/bash

######################################################################################
# Put all your custom action scripts in this directory.
# Only these scripts will be retained after an upgrade or reinstallation of the agent.
# Ideally each script should return an output and a status value.

#output=$(sudo wget https://staticdownloads.site24x7.com/server/Site24x7_Linux_64bit.install)

ls

#sleep 35

#sleep 10

#sudo service mysql restart

#sleep 10
