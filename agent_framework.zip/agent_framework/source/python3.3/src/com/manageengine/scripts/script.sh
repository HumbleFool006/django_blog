#!/bin/bash
#set -x
SUCCESS=0
FAILURE=1
LINUX_DIST='Lin_dist'
OS_NAME=`/bin/uname -s`
USER_SESSIONS_COMMAND='last -F -n 50'
export LC_NUMERIC="en_US"

setUserSessionsCommand()
{
	$USER_SESSIONS_COMMAND > /dev/null 2>&1
    RET_VAL=$?
    if [ $RET_VAL == $FAILURE ]; then
    	USER_SESSIONS_COMMAND='last'
    fi
}

echoMessage() {
	echo ""
	echo "<<$1>>"	
}

loadSystemStats(){
	echoMessage "system_stats"
	cat /proc/loadavg
}

loadSystemUptime(){
	echoMessage "system_uptime"
	cat /proc/uptime
}

loadProcessQueue(){
	echoMessage "process_queue"
	cat /proc/stat | grep "procs_running"
	cat /proc/stat | grep "procs_blocked"
}

loadMemoryStats(){
	echoMessage "memory_stats"
	cat /proc/meminfo | grep -i 'MemTotal'
	cat /proc/meminfo | grep -i 'MemFree'
	cat /proc/meminfo | grep -i 'Buffers'
	cat /proc/meminfo | grep -w 'Cached'
	cat /proc/meminfo | grep 'SwapCached'
	cat /proc/meminfo | grep -i 'SwapTotal'
	cat /proc/meminfo | grep -i 'SwapFree'
	cat /proc/meminfo | grep -i 'CommitLimit'
	cat /proc/meminfo | grep -i 'Committed_AS'
	cat /proc/meminfo | grep -i 'Dirty'
	cat /proc/meminfo | grep -i 'Slab'
	cat /proc/meminfo | grep -wi 'WriteBack'
	cat /proc/meminfo | grep -i 'AnonPages'
	cat /proc/meminfo | grep -i 'Mapped'
	cat /proc/meminfo | grep -i 'PageTables'
	cat /proc/vmstat | grep -i 'pgmajfault'
	cat /proc/vmstat | grep -i 'pswpin'
	cat /proc/vmstat | grep -i 'pswpout'
	cat /proc/meminfo | grep 'Active:'
	cat /proc/meminfo | grep 'Inactive:'
}

getUdpStats()
{
	echoMessage "udp_stats"
	cat /proc/net/snmp | grep -w "Udp"
}

getTcpStats()
{
	echoMessage "tcp_stats"
	cat /proc/net/snmp | grep -w "Tcp"
}

getLoginCount(){
	echoMessage "login_count"
	who -q
}

getIpStats(){
	echoMessage "ip_stats"
	cat /proc/net/snmp | grep -w "Ip"
}

getIcmpStats(){
	echoMessage "icmp_stats"
	cat /proc/net/snmp | grep -w "Icmp"
}

detectOSAndDistro() {
	#echoMessage "OS"
	if [ "${OS_NAME}" = "SunOS" ]; then
		OS_NAME=Solaris		
	elif [ "${OS_NAME}" = "AIX" ]; then
		OS_NAME=AIX	
	elif [ "${OS_NAME}" = "Linux" ]; then				
		if [ -f /etc/redhat-release ]; then
			LINUX_DIST="RedHat"
		elif [ -f /etc/centos-release ]; then
			LINUX_DIST="CentOS"		
		elif [ -f /etc/SuSE-release ]; then
			LINUX_DIST="Suse"		
		elif [ -f /etc/mandrake-release ]; then
			LINUX_DIST="Mandrake"
		elif [ -f /etc/fedora-release ]; then
			LINUX_DIST="Fedora"			
		elif [ -f /etc/debian_version ]; then
			LINUX_DIST="Debian"			
		fi
	fi
	#echo "Operating System : $OS_NAME"
	#echo "Linux Distribution : $LINUX_DIST"

}

osArchitecture() {
	echoMessage "os architecture"
	uname -i | awk 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF,$NF;
		print "Architecture : "$NF
	}'	
}

topCommand() {
	echoMessage "top"
	/usr/bin/top -b -d2 -n2
}

processor() {
	echoMessage "Processor"
	grep -E 'model name' /proc/cpuinfo | awk -F':' 'NR==1{print $2}'	
}

getCpuDetails() {
	echoMessage "cpu details"
        topFilteredOutput=`top -b -d1 -n2 | awk 'BEGIN{ORS=" ::: ";} /^%Cpu|^Cpu/ '`
        #echo $topFilteredOutput        
        echo $topFilteredOutput | awk 'BEGIN{FS=" ::: ";}
        {
                #print NF
                #print $1
                #print $2
                for(k=(NF/2+1);k<=NF;k++)
                {
                        split($k,arrBeforeCpuIdleTime,"id|un")
                        #print "Substring before cpu idle time : ",arrBeforeCpuIdleTime[1]
                        split(arrBeforeCpuIdleTime[1],arrAfterNiceCpuTime,"ni")
                        #print "Substring after use nice cpu time : ",arrAfterNiceCpuTime[2]    
                        awkCpu = substr(arrAfterNiceCpuTime[2],2)
                        #print "Extracted ideal percentage : ",awkCpu
                        gsub(",",".",awkCpu)
                        netSumCpuIdealPercentage+=awkCpu
                }
                #print "Net sum  Cpu ideal percentage : ",netSumCpuIdealPercentage
                cpu_idle_percentage = netSumCpuIdealPercentage/(NF/2)
                #print "cpu_idle_percentage: ",cpu_idle_percentage
                cpu_util = 100.0 - cpu_idle_percentage
                print "CPU_Name : cpu"
                print "CPU_Idle_Percentage : ",cpu_idle_percentage           
                printf "CPU_Utilization : %.2f\n",cpu_util
        }'
               
}

rcaCpuDetails() {
	echoMessage "rca cpu details"
        rcaTopFilteredOutput=`top -b -d1 -n2 | awk 'BEGIN{ORS=" ::: ";} /^%Cpu|^Cpu/ '`
        #echo $rcaTopFilteredOutput        
        echo $rcaTopFilteredOutput | awk 'BEGIN{FS=" ::: ";}
        {
                #print NF
                #print $1
                #print $2
        		for(k=(NF/2+1);k<=NF;k++)
                {
                        split($k,arrBeforeCpuIdleTime,"id|un")
                        #print "Substring before cpu idle time : ",arrBeforeCpuIdleTime[1]
                        split(arrBeforeCpuIdleTime[1],arrAfterNiceCpuTime,"ni")
                        #print "Substring after use nice cpu time : ",arrAfterNiceCpuTime[2]    
                        awkCpu = substr(arrAfterNiceCpuTime[2],2)
                        #print "Extracted ideal percentage : ",awkCpu
                        gsub(",",".",awkCpu)
                        netSumCpuIdealPercentage+=awkCpu
                }
                #print "Net sum  Cpu ideal percentage : ",netSumCpuIdealPercentage
                cpu_idle_percentage = netSumCpuIdealPercentage/(NF/2)
                #print "cpu_idle_percentage: ",cpu_idle_percentage
                cpu_util = 100.0 - cpu_idle_percentage
                print "CPU_Name : cpu"
                print "CPU_Idle_Percentage : ",cpu_idle_percentage           
                printf "CPU_Utilization : %.2f\n",cpu_util
        }'               

    cat /proc/stat | grep -i 'intr ' | awk '{ print "Interrupts :",$2 }'
    cat /proc/stat | grep -i 'ctxt ' | awk '{ print "Context Switches :",$2 }'

}

cpuCoreDetails() {
	echoMessage "cpu cores usage"
		procStatCpuData=` awk 'BEGIN{ORS=" ::: ";} /^cpu[0-9]/' /proc/stat`
        echo $procStatCpuData | awk 'BEGIN{FS=" ::: ";}
        {
                for (i=1;i<=NF;i++)
                {
                        split($i,array," ")
                        printf "%s -- %d -- %d -- %d -- %d -- %d -- %d -- %d -- %d -- %d -- %d \n",array[1],array[2],array[3],array[4],array[5],array[6],array[7],array[8],array[9],array[10],array[11]
                }
        }'	
}

getCpuCores() {
	echoMessage "cpu cores"
	cat /proc/cpuinfo | awk 'BEGIN {
		FS=":";
		cpu_count = 0;
	}
	{
		split($1, temp_arr, "%")
		name = temp_arr[1]
		sub(/[ \t]+$/,"",name) #remove leading and trailing spaces.
		#print ":"name":"
		#print cpu_count
		if (name == "processor")
		{
			cpu_count+=1
		}
	}
	END {
		print "Cpu cores :",cpu_count
	}'
}

getProcessorName() {
	echoMessage "processor"
	grep -E 'model name' /proc/cpuinfo | awk 'BEGIN {
			FS=":";
			ORS="\n";			
		}
		{
			if (NR == 1) {
				print "Processor Name :",$2
			}
		}'
	
}
# Number of interrupts (since the last boot)
getCpuInterrupts() {
	echoMessage "cpu interrupt"
	cat /proc/stat | grep -i 'intr ' | awk '{ print "Interrupts :",$2 }'
}
# Number of context switches (since the last boot)
getCpuContextSwitches() {
	echoMessage "cpu context switches"
	cat /proc/stat | grep -i 'ctxt ' | awk '{ print "Context Switches :",$2 }'
}

diskDetails() {
	echoMessage "disk details"
    df -l -T | grep -iv Filesystem | awk 'BEGIN {
        ORS="\n";
        partitionNameArray[0] = 0;
    }
    {       
        #print "Processing Record ",NR,NF,$NF;
        if ($NF in partitionNameArray == 0)
        {
            partitionNameArray[$NF] = $NF
            if (NF > 2)
            {
				printf $NF" -- %.0f -- %.0f \n",(($(NF-3)*1024)+($(NF-2)*1024)), $(NF-2)*1024      
            }
        }
    }'
}

rcaDiskDetails() {
	echoMessage "rca disk details"
    df -l -Th | grep -iv Filesystem | awk 'BEGIN {
        ORS="\n";
        partitionNameArray[0] = 0;
    }
    {       
        #print "Processing Record ",NR,NF, $0;
        stdFieldCount=7
        if ($NF in partitionNameArray == 0)
        {
            partitionNameArray[$stdFieldCount] = $stdFieldCount
            partitionSize = $(stdFieldCount-4)
        	partitionUsed = $(stdFieldCount-3)
        	partitionAvail = $(stdFieldCount-2)
        	partitionUsedPercentage = $(stdFieldCount-1) 
            if (NF > 2)
            {
            	print $NF" -- "partitionSize" -- "partitionUsed" -- "partitionAvail" -- "partitionUsedPercentage      
            }
        }
    }'
}



# Number of reads, writes completed (since the last boot)
diskStats() {
	echoMessage "disk stats"
	PARTITIONS=(`awk 'NR > 1 && $0 !~ /dm-|loop|drbd/ && $4 !~ /[0-9]$/ {ORS=" "; print $4}' /proc/partitions`)
	#echo "PARTITIONS : ${PARTITIONS[@]}"
	if [ "${#PARTITIONS[@]}" -eq 0 ]; then
	    PARTITIONS=(`awk 'NR > 1 && $0 !~ /dm-|loop|drbd/ {ORS=" "; print $4}' /proc/partitions`)
	    #echo "PARTITIONS : ${PARTITIONS[@]}"
	fi
	NUMBER_OF_SECTORS_READ=0
	NUMBER_OF_SECTORS_WRITE=0
	BYTES_PER_SECTOR=512
	for (( i = 0; i < ${#PARTITIONS[@]} ; i++ )); do
    	#printf "awk -v dev=${PARTITIONS[$i]} '$3 == dev' /proc/diskstats \n"
    	STATS_ARR=(`awk -v dev=${PARTITIONS[$i]} '$3 == dev' /proc/diskstats1`)
    	#echo "STATS_ARR : ${STATS_ARR[@]}"
    	#echo "${STATS_ARR[2]} : ${STATS_ARR[5]} : ${STATS_ARR[9]}"
    	NUMBER_OF_SECTORS_READ=$(($NUMBER_OF_SECTORS_READ + ${STATS_ARR[5]}))
    	NUMBER_OF_SECTORS_WRITE=$(($NUMBER_OF_SECTORS_WRITE + ${STATS_ARR[9]}))
	done
	READ_IN_BYTES=$(($NUMBER_OF_SECTORS_READ * $BYTES_PER_SECTOR))
	WRITE_IN_BYTES=$(($NUMBER_OF_SECTORS_WRITE * $BYTES_PER_SECTOR))
	#echo "Disk I/O : $NUMBER_OF_SECTORS_READ : $NUMBER_OF_SECTORS_WRITE"
	echo "Disk I/O bytes : $READ_IN_BYTES : $WRITE_IN_BYTES"
}

diskErrors() {
	echoMessage "disk errors"
	cat aaa
	dmesg | grep -w "I/O error\|EXT2-fs error\|EXT3-fs error\|EXT4-fs error\|UncorrectableError\|DriveReady SeekComplete Error\|I/O Error Detected" | sort -u	
}

dmesgErrors() {
	echoMessage "dmesg errors"
	dmesg | grep -i 'error' | tail -n 10	
}

uptimeDetails() {
	echoMessage "uptime details"
	uptime	
}

getMemoryDetails() {
	echoMessage "memory details"
	free -k | awk 'BEGIN {  
        ORS="\n";
	virtTrue=0;
	avail = 0;
	}
	{
        #print "Processing Record ",NR;
	mem = match($1,"Mem")
	swap = match($1,"Swap")
	if(NR == 1)
	{
		avail = match($0,"available")
		#print "Setting available to :",avail	
	}
        if (mem == 1)
            { 
		print "TotalVisibleMemorySize :",$2
		if( avail != 0 )
		{
			print "FreePhysicalMemory :"$7	
		}
		else
		{
			print "FreePhysicalMemory :",($2-$3+$6+$7)
		}
	    }	
        else if (swap == 1)
            {print "TotalVirtualMemorySize :",$2,"\nFreeVirtualMemory :",$4
	    virtTrue = 1
	    }       
	}END{if(virtTrue == 0) print "TotalVirtualMemorySize :",0,"\nFreeVirtualMemory :",0}'
	detectOSAndDistro
	strcmd="/bin/cat /etc/issue"
	if [ ${LINUX_DIST} = "RedHat" ]; then
		strcmd="/bin/cat /etc/redhat-release"
	elif [ ${LINUX_DIST} = "CentOS" ]; then
		strcmd="/bin/cat /etc/centos-release"
	else 
		strcmd="/bin/cat /etc/issue"	
	fi

	$strcmd  | awk 'BEGIN {  
        ORS="\n";
        LINUX_DIST="";
	}
	{
        #print "Processing Record ",NR;
        if (NR<6 && $0 != "") {
            LINUX_DIST=LINUX_DIST""$0
            gsub(/\\n/,"",LINUX_DIST)
            gsub(/\\l/,"",LINUX_DIST)
            gsub(/\\r/,"",LINUX_DIST)
            gsub(/\\m/,"",LINUX_DIST)	                
        }       
	}END {print "Linux Distribution : ",LINUX_DIST}'
}

getRcaMemoryDetails() {
	echoMessage "rca memory details"
	free -km | awk 'BEGIN {  
        ORS="\n";
	}
	{
        #print "Processing Record ",NR;
        if (NR == 2)
        {
            print "Total Memory :",$2,"MB"
            print "Used Memory :",$3,"MB"
            print "Free Memory :",$4,"MB"
        }
        else if (NR == 3)
        {
        	print "Buffer Free Memory :",$4,"MB"
            print "Buffer Used Memory :",$3,"MB"
        }
        else if (NR == 4)
        {
            print "Total Virtual Memory :",$2,"MB"
            print "Free Virtual Memory :",$4,"MB"
        }          
	}'
}

# Number of pagein, pageout and pgfault (since the last boot)
getMemoryStats() {
	echoMessage "memory stats"
	cat /proc/vmstat | grep -i 'pgpgin\|pgpgout\|pgfault'
}

fetchTrafficDetails() {
	echoMessage "interface traffic"
	cat /proc/net/dev | awk 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]	
			if_speed = ""	
			sub(/[ \t]+$/,"",temp_arr[2])
			#print ":"temp_arr[2]":"
			if (temp_arr[2] == "")
			{
				rx_bytes = $2
				ifSpeed_command = "/bin/cat /sys/class/net/"if_name"/speed"
				isStateCommandSuccess = (ifSpeed_command | getline if_speed)
				print if_name,rx_bytes,$3,$10,$11,$12,$13,"speed : ",if_speed;
			}
			else
			{
				rx_bytes = temp_arr[2]
				ifSpeed_command = "/bin/cat /sys/class/net/"if_name"/speed"
				isStateCommandSuccess = (ifSpeed_command | getline if_speed)
				print if_name,rx_bytes,$2,$9,$10,$11,$12,"speed : ",if_speed;
			}
		}		
	}'
}

fetchRcaTrafficDetails() {
	echoMessage "rca interface traffic"
	cat /proc/net/dev | awk 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]	
			if_speed = ""	
			sub(/[ \t]+$/,"",temp_arr[2])
			#print ":"temp_arr[2]":"
			if (temp_arr[2] == "")
			{
				rx_bytes = $2
				ifSpeed_command = "/bin/cat /sys/class/net/"if_name"/speed"
				isStateCommandSuccess = (ifSpeed_command | getline if_speed)
				print if_name,rx_bytes,$3,$10,$11,$12,$13,"speed : ",if_speed;
			}
			else
			{
				rx_bytes = temp_arr[2]
				ifSpeed_command = "/bin/cat /sys/class/net/"if_name"/speed"
				isStateCommandSuccess = (ifSpeed_command | getline if_speed)
				print if_name,rx_bytes,$2,$9,$10,$11,$12,"speed : ",if_speed;
			}
		}		
	}'
}


fetchInterfaceStatus() {
	echoMessage "interface details"
	cat /proc/net/dev | awk 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]
			#print if_name
			if_status = 7
			if_address = "N/A-" if_name	
			state_command = "/bin/cat /sys/class/net/"if_name"/operstate"
			macAddr_command = "/bin/cat /sys/class/net/"if_name"/address"
			isStateCommandSuccess = (state_command | getline if_state) 
			isMacAddrCommandSuccess = (macAddr_command | getline if_address)
			#print isStateCommandSuccess isMacAddrCommandSuccess
			#print "State : "if_state" Address : "if_address
			if (if_state == "up")
			{
				if_status = 2
			}
			print if_name" -- "if_status" -- "if_address
		}
	}'
}


fetchInterfaceData(){
	echoMessage "interface data"
	if [ -f /sys/class/net/bonding_masters ]; then
		bonding_masters=$( cat /sys/class/net/bonding_masters )
	fi
	cat /proc/net/dev | awk -v awk_bonding_masters="${bonding_masters[*]}" 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]
			#print if_name
			int_match = match(if_name,"veth")
			if (int_match != 1)
			{
			if_valid = 1
			if_status = 0
			if_address = "N/A-" if_name	
			state_command = "/bin/cat /sys/class/net/"if_name"/operstate"
			macAddr_command = "/bin/cat /sys/class/net/"if_name"/address"
			rxbytes_command = "/bin/cat /sys/class/net/"if_name"/statistics/rx_bytes"
			rxpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/rx_packets"
			txbytes_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_bytes"
			txpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_packets"
			txerrors_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_errors"
			txdrops_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_dropped"
			rxmulticastpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/multicast"
			isStateCommandSuccess = (state_command | getline if_state) 
			isMacAddrCommandSuccess = (macAddr_command | getline if_address)
			rxbytesCommandSuccess = (rxbytes_command | getline rx_bytes)
			rxpacketsCommandSuccess = (rxpackets_command | getline rx_packets)
			txbytesCommandSuccess = (txbytes_command | getline tx_bytes)
			txpacketsCommandSuccess = (txpackets_command | getline tx_packets)
			txerrorsCommandSuccess = (txerrors_command | getline tx_errors)
			txdropsCommandSuccess = (txdrops_command | getline tx_drops)
			rxmulticastpacketsCommandSuccess = (rxmulticastpackets_command | getline rx_multicastPackets)
			{split(awk_bonding_masters, awk_bonding_masters_array, / /)}
			for (i in awk_bonding_masters_array){if (awk_bonding_masters_array[i] == if_name){ if_valid = 0; if_address = if_address"_"if_name}};
			#print isStateCommandSuccess isMacAddrCommandSuccess
			#print "State : "if_state" Address : "if_address
			if (if_state == "up")
			{
				if_status = 1
			}
			if (if_state == "unknown")
			{
				if_status = 2
			}
			if(if_valid == 1){
			print if_name" -- "if_status" -- "if_address" -- "rx_bytes" -- "rx_packets" -- "tx_bytes" -- "tx_packets" -- "tx_errors" -- "tx_drops" -- "rx_multicastPackets
			}
		}
		}
	}'

}

fetchBondInterfaceData(){
	echoMessage "interface data"
	if [ -f /sys/class/net/bonding_masters ]; then
		bonding_masters=$( cat /sys/class/net/bonding_masters )
	fi
	cat /proc/net/dev | awk -v awk_bonding_masters="${bonding_masters[*]}" 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]
			#print if_name
			int_match = match(if_name,"veth")
			if (int_match != 1)
			{
			if_valid = 1
			if_status = 0
			if_address = "N/A-" if_name	
			state_command = "/bin/cat /sys/class/net/"if_name"/operstate"
			macAddr_command = "/bin/cat /sys/class/net/"if_name"/address"
			rxbytes_command = "/bin/cat /sys/class/net/"if_name"/statistics/rx_bytes"
			rxpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/rx_packets"
			txbytes_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_bytes"
			txpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_packets"
			txerrors_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_errors"
			txdrops_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_dropped"
			rxmulticastpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/multicast"
			isStateCommandSuccess = (state_command | getline if_state) 
			isMacAddrCommandSuccess = (macAddr_command | getline if_address)
			rxbytesCommandSuccess = (rxbytes_command | getline rx_bytes)
			rxpacketsCommandSuccess = (rxpackets_command | getline rx_packets)
			txbytesCommandSuccess = (txbytes_command | getline tx_bytes)
			txpacketsCommandSuccess = (txpackets_command | getline tx_packets)
			txerrorsCommandSuccess = (txerrors_command | getline tx_errors)
			txdropsCommandSuccess = (txdrops_command | getline tx_drops)
			rxmulticastpacketsCommandSuccess = (rxmulticastpackets_command | getline rx_multicastPackets)
			{split(awk_bonding_masters, awk_bonding_masters_array, / /)}
			for (i in awk_bonding_masters_array){if (awk_bonding_masters_array[i] == if_name){ if_address = if_address"_"if_name}};
			#print isStateCommandSuccess isMacAddrCommandSuccess
			#print "State : "if_state" Address : "if_address
			if (if_state == "up")
			{
				if_status = 1
			}
			if (if_state == "unknown")
			{
				if_status = 2
			}
			if(if_valid == 1){
			print if_name" -- "if_status" -- "if_address" -- "rx_bytes" -- "rx_packets" -- "tx_bytes" -- "tx_packets" -- "tx_errors" -- "tx_drops" -- "rx_multicastPackets
			}
		}
		}
	}'

}

asa(){
`cat aurn`
}

fetchBondInterfaceData(){
	echoMessage "interface data"
	if [ -f /sys/class/net/bonding_masters ]; then
		bonding_masters=$( cat /sys/class/net/bonding_masters )
	fi
	cat /proc/net/dev | awk -v awk_bonding_masters="${bonding_masters[*]}" 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]
			#print if_name
			int_match = match(if_name,"veth")
			if (int_match != 1)
			{
			if_status = 0
			if_address = "N/A-" if_name	
			state_command = "/bin/cat /sys/class/net/"if_name"/operstate"
			macAddr_command = "/bin/cat /sys/class/net/"if_name"/address"
			rxbytes_command = "/bin/cat /sys/class/net/"if_name"/statistics/rx_bytes"
			rxpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/rx_packets"
			txbytes_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_bytes"
			txpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_packets"
			txerrors_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_errors"
			txdrops_command = "/bin/cat /sys/class/net/"if_name"/statistics/tx_dropped"
			rxmulticastpackets_command = "/bin/cat /sys/class/net/"if_name"/statistics/multicast"
			isStateCommandSuccess = (state_command | getline if_state) 
			isMacAddrCommandSuccess = (macAddr_command | getline if_address)
			rxbytesCommandSuccess = (rxbytes_command | getline rx_bytes)
			rxpacketsCommandSuccess = (rxpackets_command | getline rx_packets)
			txbytesCommandSuccess = (txbytes_command | getline tx_bytes)
			txpacketsCommandSuccess = (txpackets_command | getline tx_packets)
			txerrorsCommandSuccess = (txerrors_command | getline tx_errors)
			txdropsCommandSuccess = (txdrops_command | getline tx_drops)
			rxmulticastpacketsCommandSuccess = (rxmulticastpackets_command | getline rx_multicastPackets)
			{split(awk_bonding_masters, awk_bonding_masters_array, / /)}
			for (i in awk_bonding_masters_array){if (awk_bonding_masters_array[i] == if_name){ if_address = if_address"_"if_name}};
			#print isStateCommandSuccess isMacAddrCommandSuccess
			#print "State : "if_state" Address : "if_address
			if (if_state == "up")
			{
				if_status = 1
			}
			if (if_state == "unknown")
			{
				if_status = 2
			}
			print if_name" -- "if_status" -- "if_address" -- "rx_bytes" -- "rx_packets" -- "tx_bytes" -- "tx_packets" -- "tx_errors" -- "tx_drops" -- "rx_multicastPackets
			}
		}
	}'
}

fetchRcaInterfaceStatus() {
	echoMessage "rca interface details"
	cat /proc/net/dev | awk 'BEGIN {
		ORS="\n";
	}
	{	
		#print "Processing Record ",NR,NF;
		if_name = ""
		rx_bytes = 0
		if (NR > 2) {
			split($1, temp_arr, ":")
			if_name = temp_arr[1]
			if_status = 7
			if_address = "N/A-" if_name		
			state_command = "/bin/cat /sys/class/net/"if_name"/operstate"
			macAddr_command = "/bin/cat /sys/class/net/"if_name"/address"
			isStateCommandSuccess = (state_command | getline if_state) 
			isMacAddrCommandSuccess = (macAddr_command | getline if_address)
			#print isStateCommandSuccess isMacAddrCommandSuccess
			#print "State : "if_state" Address : "if_address
			if (if_state == "up")
			{
				if_status = 2
			}
			else
			{
				if_state = "down"
			}
			print if_name" -- "if_state
		}
	}'
}

installedSoftware() {
	echoMessage "installed software"
	dpkg --list | awk 'BEGIN {
		ORS="\n";
	}
	{
		if (NR > 5)	{
			description = "" 
			for(i=4;i<=NF;i++){description=description" "$i}; 
			print $2 " ::: " $3 " ::: "description
		}
	}'
}

listUsers() {
	echoMessage "list users"
	who -uH | awk 'BEGIN {
		ORS="\n";
	}
	{
		if (NR > 1)	{
			timeField = "" 
			for(i=4;i<=NF;i++){timeField=timeField" "$i}; 
			print $1 " ::: "$2" ::: "$3" "$4" ::: "$7
		}
	}'
}

userSessions() {
	setUserSessionsCommand
	echoMessage "user sessions"
	$USER_SESSIONS_COMMAND | head -n 20 | awk 'BEGIN {
		ORS="\n";
	}
	{
		column1=substr($0,1,8)
		column2=substr($0,10,11)
		column3=substr($0,21,18)
		column4=substr($0,39)
		gsub(/^[ \t]+|[ \t]+$/,"",column1)
		gsub(/^[ \t]+|[ \t]+$/,"",column2)
		gsub(/^[ \t]+|[ \t]+$/,"",column3)
		gsub(/^[ \t]+|[ \t]+$/,"",column4)
		if (column1  !~ /^ *$/ && column1 !~ /^wtmp/ && column2 !~ /^ *$/ && column3  !~ /^ *$/ )
		{
			print column1 " ::: "column2" ::: "column3" ::: "column4
		}   
		
	}'
}

processMonitoring(){
	#echoMessage $1
	processes=`echo $1 | awk -F "::" '{print $2}'`
	#echoMessage $processes
	echoMessage "process_monitoring"
	#echoMessage "/bin/ps -eo pid,fname,pcpu,pmem,nlwp,command,args,pri| grep -E '$processes'"
	#echoMessage "/bin/ps -eo pid,fname,pcpu,pmem,nlwp,command,args,pri| grep -E ${processes}"
	/bin/ps -eo pid,pri,fname,pcpu,pmem,nlwp,command,args | grep -v "\[sh] <defunct>" | grep -E ${processes} | grep -v grep | awk 'BEGIN {
	ORS="\n";
	}
	{
		#print length($0)
		processName = $3
		exePath = $7
		oldCommandArgs = $8
		commandArgs = substr($0,63,length($0))
		gsub("\"", "\\\"", processName)
		gsub("\"", "\\\"", exePath)
		gsub("\"", "\\\"", commandArgs)
		awkProcessIndex = index(commandArgs,"ishandleCountCommandSuccess")
		if (awkProcessIndex == 0) {
			if (NR == 1) {
				print "  PID PRIORITY NAME %CPU %MEM NLWP HANDLE COMMAND                     ARGS"
			} 
			if (NR >= 1) {
				fd = 0
				lastField = ""
				handleCountCommand = "ls /proc/"$1"/fd | /usr/bin/wc -l"
				ishandleCountCommandSuccess = (handleCountCommand | getline fd)		
				#print "error: "ishandleCountCommandSuccess
				for(i=7;i<=NF;i++)
				{		
					lastField=lastField" "$i
				} 
				print $1" :: "$2" :: "processName" :: "$4" :: "$5" :: "$6" :: "fd" :: "exePath" :: "commandArgs" :: "oldCommandArgs
			}
		}
	}'
}

psCommand() {
		echoMessage "ps"
		/bin/ps -eo pid,fname,pcpu,pmem,nlwp,command,args| grep -v "\[sh] <defunct>" | awk 'BEGIN {
			ORS="\n";
		}
		{
			#print length($0)
			processName = $2
			exePath = $6
			oldCommandArgs = $7
			commandArgs = substr($0,59,length($0))
			gsub("\"", "\\\"", processName)
			gsub("\"", "\\\"", exePath)
			gsub("\"", "\\\"", commandArgs)
			awkProcessIndex = index(commandArgs,"ishandleCountCommandSuccess")
			if (awkProcessIndex == 0) {
				if (NR == 1) {
					print "  PID COMMAND  %CPU %MEM NLWP COMMAND                     ARGS"
				} 
				if (NR > 1) {	
					fd = 0
					lastField = ""
					handleCountCommand = "ls /proc/"$1"/fd | /usr/bin/wc -l"
					ishandleCountCommandSuccess = (handleCountCommand | getline fd)		
					#print "error: "ishandleCountCommandSuccess
					for(i=7;i<=NF;i++)
					{		
						lastField=lastField" "$i
					} 
					
					print $1" :: "processName" :: "$3" :: "$4" :: "$5" :: "fd" :: "exePath" :: "commandArgs" :: "oldCommandArgs
				}
			}
		}'
}

parseInput() {
	if [ "$1" != "" ]; then
		for PARAM in ${1//,/ }; do
			echo "PARAM : $PARAM"
			if [ "${PARAM}" = "cpu_util" ]; then
				getCpuDetails
			elif [ "${PARAM}" = "rca_cpu_details" ]; then
				rcaCpuDetails
			elif [ "${PARAM}" = "cpu_cores" ]; then
				getCpuCores
			elif [ "${PARAM}" = "cpu_intr" ]; then
				getCpuInterrupts
			elif [ "${PARAM}" = "cpu_cs" ]; then
				getCpuContextSwitches
			elif [ "${PARAM}" = "processor" ]; then
				getProcessorName
			elif [ "${PARAM}" = "os_arch" ]; then
				osArchitecture					
			elif [ "${PARAM}" = "disk_details" ]; then
				diskDetails
			elif [ "${PARAM}" = "rca_disk_details" ]; then
				rcaDiskDetails
			elif [ "${PARAM}" = "disk_stats" ]; then
				diskStats
			elif [ "${PARAM}" = "disk_err" ]; then
				diskErrors
			elif [ "${PARAM}" = "mem_details" ]; then
				getMemoryDetails
			elif [ "${PARAM}" = "rca_mem_details" ]; then
				getRcaMemoryDetails
			elif [ "${PARAM}" = "mem_stats" ]; then
				getMemoryStats
			elif [ "${PARAM}" = "if_details" ]; then
				fetchInterfaceStatus
			elif [ "${PARAM}" = "if_data" ]; then
				fetchInterfaceData
			elif [ "${PARAM}" = "rca_if_details" ]; then
				fetchRcaInterfaceStatus
			elif [ "${PARAM}" = "if_traffic" ]; then
				fetchTrafficDetails
			elif [ "${PARAM}" = "rca_if_traffic" ]; then
				fetchRcaTrafficDetails
			elif [ "${PARAM}" = "dmesg_err" ]; then
				dmesgErrors
			elif [ "${PARAM}" = "uptime_details" ]; then
				uptimeDetails
			elif [ "${PARAM}" = "user_sessions" ]; then
				userSessions
			elif [ "${PARAM}" = "inst_soft" ]; then
				installedSoftware
			elif [ "${PARAM}" = "topCommand" ]; then
				topCommand
			elif [ "${PARAM}" = "psCommand" ]; then
				psCommand
			elif [[ "${PARAM}" == *"pcheck"* ]];then
				processMonitoring $PARAM
			elif [ "${PARAM}" = "core_usage" ]; then
				cpuCoreDetails				
			elif [ "${PARAM}" = "system_stats" ]; then
				loadSystemStats
			elif [ "${PARAM}" = "system_uptime" ]; then
				loadSystemUptime
			elif [ "${PARAM}" = "process_queue" ]; then
				loadProcessQueue
			elif [ "${PARAM}" = "memory_stats" ]; then
				loadMemoryStats
			elif [ "${PARAM}" = "login_count" ]; then
				getLoginCount
			elif [ "${PARAM}" = "udp_stats" ]; then
				getUdpStats
			elif [ "${PARAM}" = "tcp_stats" ]; then
				getTcpStats
			elif [ "${PARAM}" = "ip_stats" ]; then
				getIpStats
			elif [ "${PARAM}" = "icmp_stats" ]; then
				getIcmpStats
			elif [ "${PARAM}" = "if_bond_data" ]; then
				fetchBondInterfaceData
			elif [ "${PARAM}" = "asa" ]; then
				asa
			fi

		done
	fi
}

main() {
	echo "TIME : "+`date`
	parseInput $1
	echo "aaa"
	#diskStats
	#detectOSAndDistro
}

main $1 
echo "assasa" $1
