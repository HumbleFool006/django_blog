#!/bin/bash
cd xyz
echo $(sudo service mysql restart)
