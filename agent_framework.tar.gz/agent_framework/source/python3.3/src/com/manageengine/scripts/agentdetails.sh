agentdetails()
{

/bin/ps -eo pid,fname,pcpu,pmem,nlwp,command,args| grep -v "\[sh] <defunct>" | grep -v grep | grep -i "/opt/site24x7/monagent/lib/Site24x7Agent" | grep -v "Site24x7AgentWatchdog" | awk 'BEGIN{
}
{ print $1,$2,$3,$4,$5,$6,$7,"Site24x7Agent"
}
END{
}'


}

agentdetails
