#!/bin/bash
check(){
	#echo "check"
	#echo $1
        path=$1
	ipaddr=$(mount -l -t nfs,nfs4,nfs2,nfs3 | grep -w "$path" | awk -F'[(|,|=|)]' '{ for(i=1;i<=NF;i++) if ($i == "addr") print $(i+1) }')
	#echo $ipaddr
        if [ "$ipaddr" ]
        then
		echo "$ipaddr" |
                while read line
                do
                        #echo "$line:ss"
                        output=$(rpcinfo -u "$line" nfs | egrep -i "ready|waiting")
                        #echo "$output"
                        if [ "$output" ]
                        then
                                echo "$line%%1"
                        else
                                echo "$line%%0"
                        fi
                done
        else
                echo "-1"
        fi
}
main(){
	#echo "main"
        check $1
}
main $1
