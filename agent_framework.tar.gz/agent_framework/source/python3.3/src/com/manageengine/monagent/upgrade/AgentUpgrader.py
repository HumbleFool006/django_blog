# $Id$
import traceback, os
from datetime import datetime
import time

from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.util import AgentArchiver
from com.manageengine.monagent.util import DesignUtils
from com.manageengine.monagent.util.AgentUtil import FileUtil

UPGRADE = False

def initialize():
    AgentLogger.log(AgentLogger.STDOUT, '================================= UPGRADER INITIALIZED =================================')
    AgentLogger.debug(AgentLogger.STDOUT, 'AGENT_UPGRADE_CONTEXT : '+str(AgentConstants.AGENT_UPGRADE_CONTEXT))
    AgentLogger.debug(AgentLogger.STDOUT, 'UPGRADE_FILE_NAME : '+str(AgentConstants.UPGRADE_FILE_NAME))
    AgentLogger.debug(AgentLogger.STDOUT, 'AGENT_UPGRADE_FILE_NAME : '+str(AgentConstants.AGENT_UPGRADE_FILE_NAME))
    AgentLogger.debug(AgentLogger.STDOUT, 'WATCHDOG_UPGRADE_FILE_NAME : '+str(AgentConstants.WATCHDOG_UPGRADE_FILE_NAME))    
    
    AgentConstants.UPGRADE_FILE = AgentConstants.AGENT_UPGRADE_DIR + '/'+ AgentConstants.UPGRADE_FILE_NAME
    AgentConstants.AGENT_UPGRADE_FILE = AgentConstants.AGENT_UPGRADE_DIR + '/'+ AgentConstants.AGENT_UPGRADE_FILE_NAME
    AgentConstants.WATCHDOG_UPGRADE_FILE = AgentConstants.AGENT_UPGRADE_DIR +'/'+ AgentConstants.WATCHDOG_UPGRADE_FILE_NAME
    AgentConstants.AGENT_UPGRADE_URL = '//' + AgentConstants.AGENT_UPGRADE_CONTEXT + '//' + AgentConstants.UPGRADE_FILE_NAME
    
    AgentLogger.log(AgentLogger.STDOUT, 'Agent Upgrade Url : '+str(AgentConstants.AGENT_UPGRADE_URL))
    AgentLogger.log(AgentLogger.STDOUT, 'UPGRADE_FILE : '+str(AgentConstants.UPGRADE_FILE))
    AgentLogger.log(AgentLogger.STDOUT, 'AGENT_UPGRADE_FILE : '+str(AgentConstants.AGENT_UPGRADE_FILE))
    AgentLogger.log(AgentLogger.STDOUT, 'WATCHDOG_UPGRADE_FILE : '+str(AgentConstants.WATCHDOG_UPGRADE_FILE))
    
    isMonAgentUpgraded()
    return True

def patchUpgrader():
    pass


def isMonAgentUpgraded():
    try:
        if os.path.exists(AgentConstants.MON_AGENT_UPGRADED_FLAG_FILE):
            #add main log here
            AgentLogger.log(AgentLogger.MAIN,'================================= MON_AGENT_UPGRADED_FLAG_FILE is present, hence assigning MON_AGENT_UPGRADED = True =================================')
            AgentConstants.MON_AGENT_UPGRADED = True
            #delete file here only
        else:
            AgentLogger.log(AgentLogger.STDOUT,'================================= MON_AGENT_UPGRADED_FLAG_FILE is not present, hence this is not a start after upgrade =================================')
    except Exception as e:
        AgentLogger.log([AgentLogger.MAIN, AgentLogger.STDERR],' ************************* Exception while setting MON_AGENT_UPGRADED variable ************************* ')
        traceback.print_exc()
    finally:
        FileUtil.deleteFile(AgentConstants.MON_AGENT_UPGRADED_FLAG_FILE)
    
def handleUpgrade(var_obj=None, custom = False):    
    global UPGRADE
    try:        
        UPGRADE = True   
        watchdogUpgrader = WatchdogUpgrader()
        watchdogUpgrader.setLogger(AgentLogger)
        watchdogUpgrader.setUpgradeProps(var_obj)
        watchdogUpgrader.setUpgradeFile(AgentConstants.UPGRADE_FILE)
        if custom == True:
            AgentLogger.log(AgentLogger.MAIN,'UPGRADE : Inside patch upgrade ')
            watchdogUpgrader.upgrade(custom = True)
        else:
            AgentLogger.log(AgentLogger.MAIN,'UPGRADE : Inside normal upgrade ')
            watchdogUpgrader.upgrade()
#            if watchdogUpgrader.isUpgradeSuccess():
#                AgentLogger.log(AgentLogger.MAIN, ' -------------------------------- Terminating Monitoring Agent for upgrade ------------------------------------ ')
#                AgentUtil.TerminateAgent()      
    except Exception as e:
        AgentLogger.log(AgentLogger.MAIN, ' *************************** Exception While Handling Upgrade *************************** '+ repr(e))
        traceback.print_exc()
        
def downloadPatch(destination,untarDir):
    try:
        bool_toReturn = True
        bool_downloadStatus = CommunicationHandler.downloadCustomFile(AgentConstants.PLUS_DOWNLOAD_SERVLET, destination, AgentLogger.MAIN)
        if bool_downloadStatus:
            AgentLogger.log(AgentLogger.MAIN,'File downloaded successfully.')
            tarHandle = AgentArchiver.getArchiver(AgentArchiver.TAR)
            tarHandle.setFile(destination)
            tarHandle.setPath(untarDir)
            tarHandle.setMode('r:gz')
            tarHandle.decompress()
            tarHandle.close()
            AgentLogger.log(AgentLogger.MAIN,'Tar extracted successfully.')
    except Exception as e:
        AgentLogger.log(AgentLogger.MAIN,'Exception occurred while downloading and extracting the file.')
        traceback.print_exc()
        bool_toReturn = False
    finally:
        return bool_toReturn

def updatefilesfrompatch():
    try:
        bool_toReturn=downloadPatch(AgentConstants.UPGRADE_FILE,AgentConstants.AGENT_WORKING_DIR)
        if bool_toReturn:
            AgentLogger.log(AgentLogger.MAIN,'Creating Restart Flag.')
            AgentUtil.RestartAgent()
            str_uninstallTime = 'Restart : '+repr(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"))
            file_obj = open(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE,'w')
            file_obj.write(str_uninstallTime)
            if not file_obj == None:
                file_obj.close()
            isSuccess, str_output = AgentUtil.executeCommand(AgentConstants.AGENT_WATCHDOG_STATUS_COMMAND, AgentLogger.MAIN, 5)
            AgentLogger.log(AgentLogger.MAIN,'WATCHDOG STATUS : '+str(isSuccess) +' : ' +str(str_output))
            if AgentConstants.AGENT_WATCHDOG_SERVICE_DOWN_MESSAGE in str_output:
                isBoolSuccess, str_out = AgentUtil.executeCommand(AgentConstants.AGENT_WATCHDOG_START_COMMAND, AgentLogger.MAIN, 5)
                AgentLogger.log(AgentLogger.MAIN,'STARTING WATCHDOG : '+str(isBoolSuccess) +' : ' +str(str_out))
                if AgentConstants.AGENT_WATCHDOG_SERVICE_STARTED_MESSAGE in str_out:
                    AgentLogger.log(AgentLogger.MAIN,'Watchdog started successfully.')
            else:
                isSuccess, str_output = AgentUtil.executeCommand(AgentConstants.AGENT_WATCHDOG_STOP_COMMAND, AgentLogger.MAIN, 5)
                AgentLogger.log(AgentLogger.MAIN,'STOPPING WATCHDOG : '+str(isSuccess) +' : ' +str(str_output))
                if AgentConstants.AGENT_WATCHDOG_SERVICE_STOPPED_MESSAGE in str_output:
                    isBoolSuccess, str_out = AgentUtil.executeCommand(AgentConstants.AGENT_WATCHDOG_START_COMMAND, AgentLogger.MAIN, 5)
                    AgentLogger.log(AgentLogger.MAIN,'STARTING WATCHDOG : '+str(isBoolSuccess) +' : ' +str(str_out))
                    if AgentConstants.AGENT_WATCHDOG_SERVICE_STARTED_MESSAGE in str_out:
                        AgentLogger.log(AgentLogger.MAIN,'Watchdog started successfully.')
        else:
            AgentLogger.log(AgentLogger.MAIN,'Upgrade File download failed.')
    except Exception as e:
        AgentLogger.log(AgentLogger.MAIN,'Exception occurred while updating the patch.')
        traceback.print_exc()


class Upgrader(DesignUtils.Singleton):
    def __init__(self):
        self.bool_isSuccess = False
        self.bool_inProgress = False
        self.str_upgradeFile = None
        self.logger = None
        self.dict_upgradeProps = None
    def setIsUpgradeSuccess(self, bool_isSuccess):
        self.bool_isSuccess = bool_isSuccess
    def isUpgradeSuccess(self):
        return self.bool_isSuccess
    def initiateUpgrade(self):
        return self.bool_initiateUpgrade
    def setUpgradeFile(self, str_upgradeFile):
        self.str_upgradeFile = str_upgradeFile
    def getUpgradeFile(self):
        return self.str_upgradeFile
    def setUpgradeProps(self, dict_upgradeProps):
        self.dict_upgradeProps = dict_upgradeProps
    def getUpgradeProps(self):
        return self.dict_upgradeProps
    def setLogger(self, logger):
        self.logger = logger
    def getLogger(self):
        return self.logger
    def log(self, str_message):
        if self.logger:
            self.logger.log(AgentLogger.MAIN, str_message)
    def setIsUpgradeInProgress(self, bool_inProgress):
        self.bool_inProgress = bool_inProgress
    def isUpgradeInProgress(self):
        return self.bool_inProgress
    def upgrade(self):
        raise NotImplementedError
    def preUpgrade(self):
        raise NotImplementedError
    def postUpgrade(self):
        raise NotImplementedError
    def upgradeAction(self):
        raise NotImplementedError

class WatchdogUpgrader(Upgrader):
    def __init__(self):
        super(WatchdogUpgrader, self).__init__()
    # Check whether agent needs upgrade with parameters from server.
    def initiateUpgrade(self):
        bool_isSuccess = True
        try: 
            if self.isUpgradeInProgress():
                self.log('INITIATE UPGRADE : =========================== UPGRADE ALREADY INITIATED ============================')
                return False
            self.setIsUpgradeInProgress(True)
            self.log('INITIATE UPGRADE : =========================== UPGRADE INITIATED ============================')
            bool_isSuccess = True
        except Exception as e:
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)
            bool_isSuccess = False           
            self.log('INITIATE UPGRADE : *********************** Exception while trying to initiate upgrade *****************************')
            traceback.print_exc()
        return bool_isSuccess    
    # Step 1 : Download upgrade file
    # Step 2 : Stop watchdog service if it is running by any chance.
    def preUpgrade(self, custom=False):
        bool_isSuccess = True
        bool_downloadStatus = True
        try:
            if custom == True:            
                bool_downloadStatus = CommunicationHandler.downloadCustomFile(AgentConstants.PLUS_DOWNLOAD_SERVLET, self.getUpgradeFile(), AgentLogger.MAIN)    
            else:
                bool_downloadStatus = CommunicationHandler.downloadFile(AgentConstants.AGENT_UPGRADE_URL, self.getUpgradeFile(), AgentLogger.MAIN)
            if bool_downloadStatus:
                self.log('PRE UPGRADE : Successfully downloaded the file to the path : '+str(self.getUpgradeFile()))                
                isSuccess, str_output = AgentUtil.executeCommand(AgentConstants.AGENT_WATCHDOG_STATUS_COMMAND, AgentLogger.MAIN, 5)
                if AgentConstants.AGENT_WATCHDOG_SERVICE_DOWN_MESSAGE in str_output:
                    self.log('PRE UPGRADE : Monitoring Agent Watchdog Service is down. Can proceed watchdog upgrade')
                else:
                    isSuccess, str_output = AgentUtil.executeCommand(AgentConstants.AGENT_WATCHDOG_STOP_COMMAND, AgentLogger.MAIN, 5)
                    if AgentConstants.AGENT_WATCHDOG_SERVICE_STOPPED_MESSAGE in str_output:
                        self.log('PRE UPGRADE : Monitoring Agent Watchdog Service stopped successfully for upgrade')
                    else:
                        self.setIsUpgradeInProgress(False)
                        self.setIsUpgradeSuccess(False)
                        bool_isSuccess = False
                        self.log('PRE UPGRADE : *************************** Failed to stop Monitoring Agent Watchdog Service before upgrade ***************************')            
            else:                
                self.setIsUpgradeInProgress(False)
                self.setIsUpgradeSuccess(False)
                bool_isSuccess = False            
                self.log('PRE UPGRADE : *********************** Unable to download the Upgrade file '+repr(self.getUpgradeFile())+' from the url : '+repr(AgentConstants.AGENT_UPGRADE_URL)+' *****************************')
        except Exception as e:
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)
            bool_isSuccess = False       
            self.log('PRE UPGRADE : *********************** Exception while downloading the Upgrade file '+repr(self.getUpgradeFile())+' from the url : '+repr(AgentConstants.AGENT_UPGRADE_URL)+' *****************************')
            traceback.print_exc()
        return bool_isSuccess
    # Step 1 : Extract upgrade file that contains watchdogUpgrade.tar and agentUpgrade.tar
    # Step 2 : Extract watchdogUpgrade.tar            
    def upgradeAction(self):    
        bool_isSuccess = True    
        try:            
            # Extract upgrade tar
            self.log('UPGRADE : Extracting upgrade tar file : '+repr(self.getUpgradeFile()))
            tarHandle = AgentArchiver.getArchiver(AgentArchiver.TAR)
            tarHandle.setFile(self.getUpgradeFile())
            tarHandle.setPath(AgentConstants.AGENT_UPGRADE_DIR)
            tarHandle.setMode('r:gz')
            tarHandle.decompress()
            tarHandle.close()
            self.log('UPGRADE : Tar Extraction Successful')
            # Extract watchdog tar
            self.log('UPGRADE : Extracting upgrade tar file : '+repr(AgentConstants.WATCHDOG_UPGRADE_FILE))
            tarHandle = AgentArchiver.getArchiver(AgentArchiver.TAR)
            tarHandle.setFile(AgentConstants.WATCHDOG_UPGRADE_FILE)
            tarHandle.setPath(AgentConstants.AGENT_WORKING_DIR)
            tarHandle.setMode('r:gz')
            tarHandle.decompress()
            tarHandle.close()    
            self.log('UPGRADE : Tar Extraction Successful')   
        except Exception as e:     
            self.log('UPGRADE : ********************** Exception while extracting Tar file *************************')       
            traceback.print_exc()
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)            
            bool_isSuccess = False
        return bool_isSuccess
    # Step 1 : Create upgrade flag file
    # Step 2 : Start watchdog service   
    def postUpgrade(self):
        bool_isSuccess = True    
        try:
            def createTempUpgradeFile():
                bool_toReturn = True
                file_obj = None
                try:
                    file_obj = open(AgentConstants.AGENT_UPGRADE_FLAG_FILE,'w')
                    file_obj.write(AgentConstants.AGENT_UPGRADE_FILE_NAME)                  
                except:
                    AgentLogger.log(AgentLogger.MAIN,' ************************* Exception while creating Upgrade Flag File : '+AgentConstants.AGENT_UPGRADE_FLAG_FILE+' ************************* ')
                    traceback.print_exc()
                    bool_toReturn = False
                finally:        
                    if not file_obj == None:
                        file_obj.close()
                return bool_toReturn
            str_watchdogStartCommand = AgentConstants.AGENT_WATCHDOG_START_COMMAND+' '+AgentConstants.AGENT_UPGRADE_FILE
            #self.log('command is -- '+repr(str_watchdogStartCommand))
            if createTempUpgradeFile():
                isSuccess, str_output = AgentUtil.executeCommand(str_watchdogStartCommand, AgentLogger.MAIN, 5)
                if AgentConstants.AGENT_WATCHDOG_SERVICE_STARTED_MESSAGE in str_output:
                    self.log('POST UPGRADE : Monitoring Agent Watchdog Service started successfully')
                    self.setIsUpgradeInProgress(False)
                    self.setIsUpgradeSuccess(True)
                    self.log('POST UPGRADE : ======================= MONITORING AGENT WATCHDOG UPGRADE SUCCESSFUL ==========================')                
                else:
                    self.log(str_output+' and: '+AgentConstants.AGENT_WATCHDOG_SERVICE_STARTED_MESSAGE)
                    self.setIsUpgradeInProgress(False)
                    self.setIsUpgradeSuccess(False)
                    self.log('POST UPGRADE : *************************** Failed to start Monitoring Agent Watchdog Service ***************************')            
                    bool_isSuccess = False
            else:
                self.setIsUpgradeInProgress(False)
                self.setIsUpgradeSuccess(False)
                self.log('POST UPGRADE : *************************** Failed to create upgrade flag file ***************************')            
                bool_isSuccess = False
        except Exception as e:     
            self.log('POST UPGRADE : ********************** Exception while starting watchdog service  *************************')       
            traceback.print_exc()
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)            
            bool_isSuccess = False
        return bool_isSuccess      
                
    def upgrade(self, custom = False):
        if self.initiateUpgrade():
            if custom == True:
                self.log('UPGRADE : Inside patch upgrade ')
                if self.preUpgrade(True):
                    if self.upgradeAction():
                        return self.postUpgrade()
            else:
                self.log('UPGRADE : Inside normal upgrade ')
                if self.preUpgrade():
                    if self.upgradeAction():
                        return self.postUpgrade()
                
    
    
