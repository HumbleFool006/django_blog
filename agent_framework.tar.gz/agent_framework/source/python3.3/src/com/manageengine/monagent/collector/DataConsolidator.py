#$Id$
import os
import json
import time
import traceback
import threading
import hashlib
import re

from six.moves.urllib.parse import urlencode
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util.AgentUtil import FileUtil
from com.manageengine.monagent.communication import BasicClientHandler
from com.manageengine.monagent.communication import UdpHandler
from com.manageengine.monagent.util.rca import RcaHandler
from com.manageengine.monagent.util.rca.RcaHandler import RcaUtil

customFileLock = threading.Lock()
CONFIG_OBJECTS = None
PARSE_IMPL = None
ACTIVE_PROCESS_DICT = None
PROCESS_WATCHER_DICT = None
THRESHOLD_DICT = None

def getHashID(strArgs):
    try:
        return hashlib.md5(strArgs.encode()).hexdigest()
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR],'*************************** Exception While getting hash ID for process args :'  +  str(strArgs) +'*************************** '+ repr(e))
        traceback.print_exc()

def initialize():
    global PARSE_IMPL,CONFIG_OBJECTS,ACTIVE_PROCESS_DICT,PROCESS_WATCHER_DICT
    PARSE_IMPL = {'ROOT_IMPL': getRootData,
                  'ASSET_IMPL': getAssetData,
                  'MEMORY_IMPL': getMemoryData,
                  'DISK_IMPL': getDiskData,
                  'NETWORK_IMPL': getNetworkData,
                  'CPU_IMPL' : getCPUData,
                  'PROCESS_IMPL' : getProcessData,
                  'PROCESS_IMPLEMENTATION':getProcessMonitoring,
                  'SYSTEM_IMPL':getSystemData,
                  'MEMORY_STATS_IMPL':getMemoryStats,
                  'NETWORK_STATS_IMPL':getNetworkStats
                  }
    #CONFIG_OBJECTS = {}
    #ACTIVE_PROCESS_DICT = {}
    PROCESS_WATCHER_DICT = {}
    #updateAgentConfig()
    
def updateAgentConfig(restart=False):
    ''' To sync the config objects in data consolidator'''
    str_servlet = AgentConstants.AGENT_CONFIG_SERVLET
    dictRequestParameters = {}
    try:
        dictRequestParameters['CUSTOMERID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
        dictRequestParameters['AGENTKEY'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
        dictRequestParameters['bno'] = AgentConstants.AGENT_VERSION
        if not dictRequestParameters == None:
            str_requestParameters = urlencode(dictRequestParameters)
            str_url = str_servlet + str_requestParameters
        AgentLogger.log(AgentLogger.STDOUT,'================================= UPDATING AGENT CONFIG DATA =================================\n')
        requestInfo = CommunicationHandler.RequestInfo()
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.add_header("Content-Type", 'application/json')
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.add_header("Connection", 'close')
        (isSuccess, int_errorCode, dict_responseHeaders, dict_responseData) = CommunicationHandler.sendRequest(requestInfo)
        if isSuccess and dict_responseData:
            #decodedData = dict_responseData.decode('UTF-16LE')
            dictParsedData = json.loads(dict_responseData)
            AgentLogger.log(AgentLogger.MAIN,'Monitoring config data from Server received successfully \n')
            AgentLogger.log(AgentLogger.STDOUT,'Server returned the config data :' + repr(dictParsedData) + '\n')
            updateConfigObjects(dictParsedData,restart)
        else:
            AgentLogger.log([AgentLogger.STDOUT, AgentLogger.MAIN],'Server returned no config data or connection failure \n')
        CommunicationHandler.handleResponseHeaders(dict_responseHeaders, dict_responseData, 'CONFIG DATA')
    except Exception as e:
        AgentLogger.log([AgentLogger.MAIN,AgentLogger.STDERR],'*************************** Exception While loading agent config data from server *************************** '+ repr(e) + '\n')
        traceback.print_exc()

def updateConfigObjects(dictConfigData,restart):
    '''To update the global config object '''
    
    #traceback.print_stack()
    global CONFIG_OBJECTS,ACTIVE_PROCESS_DICT,THRESHOLD_DICT
    CONFIG_OBJECTS={}
    PROCESS_NAMES=[]
    try:
        if 'threshold' in dictConfigData:
            THRESHOLD_DICT={}               
            THRESHOLD_DICT=dictConfigData['threshold']
            AgentLogger.log([AgentLogger.COLLECTOR]," threshold configuration -- {0} ".format(json.dumps(THRESHOLD_DICT)))
        if 'process' in dictConfigData:
            ACTIVE_PROCESS_DICT = {}
            CONFIG_OBJECTS['Processes'] = {}
            listProcess = dictConfigData['process']
            for each_process in listProcess:
                CONFIG_OBJECTS['Processes'][each_process['args']] = each_process['id']
                processid = each_process['id']
                processname = each_process['pn']
                HId = getHashID(each_process['args'])
                AgentLogger.debug([AgentLogger.COLLECTOR]," Config Update - Adding to Active process dict the hID : " + str(HId) + " for process : " + str(each_process['args']))
                ACTIVE_PROCESS_DICT.setdefault(processid,{})
                ACTIVE_PROCESS_DICT[processid]['pn'] = each_process['pn']
                ACTIVE_PROCESS_DICT[processid]['args'] = each_process['args']
                ACTIVE_PROCESS_DICT[processid]['pth'] = each_process['pth']
                ACTIVE_PROCESS_DICT[processid]['id'] = each_process['id']
                PROCESS_NAMES.append(each_process['pn'])
                if 'regex' in each_process and each_process['regex']=="true":
                    ACTIVE_PROCESS_DICT[processid]['regex_exp'] = re.compile(each_process['args'],re.IGNORECASE)
                    ACTIVE_PROCESS_DICT[processid]['regex']=True
                else:
                    ACTIVE_PROCESS_DICT[processid]['regex']=False
        
        AgentLogger.log(AgentLogger.CHECKS,'process monitoring configuration --- {0}'.format(ACTIVE_PROCESS_DICT))
        
        if  'BONDING_STATUS' in dictConfigData:
            if dictConfigData['BONDING_STATUS'] == 'true':
                AgentConstants.BONDING_INTERFACE_STATUS = True

        if 'nw' in dictConfigData:
            CONFIG_OBJECTS['NICS'] = {}
            listNICs = dictConfigData['nw']
            for each_NIC in listNICs:
                CONFIG_OBJECTS['NICS'][each_NIC['ma']] = each_NIC['id']

        if 'disks' in dictConfigData:
            CONFIG_OBJECTS['DISKS'] = {}
            listDisks = dictConfigData['disks']
            for each_disk in listDisks:
                CONFIG_OBJECTS['DISKS'][each_disk['dn']] = each_disk['id']
        
        if 'apps' in dictConfigData:
            pass
        
        AgentConstants.PROCESS_MONITORING_NAMES='|'.join(PROCESS_NAMES)
        AgentLogger.log(AgentLogger.CHECKS,'list of process to be monitored--- '+repr(PROCESS_NAMES)+'\n')
        AgentLogger.debug(AgentLogger.CHECKS,'process names :' + repr(AgentConstants.PROCESS_MONITORING_NAMES) + '\n')
        
        if (('reloadNotRequired' not in dictConfigData) or (dictConfigData['reloadNotRequired'] != True) or (restart)):
            if 'url' in dictConfigData:
                CONFIG_OBJECTS['URL'] = {}
                listURLs = dictConfigData['url']
                for each_URL in listURLs:
                    CONFIG_OBJECTS['URL'][each_URL['id']] = each_URL['id']
            if 'port' in dictConfigData:
                CONFIG_OBJECTS['PORT'] = {}
                listPorts = dictConfigData['port']
                for each_port in listPorts:
                    CONFIG_OBJECTS['PORT'][each_port['id']] = each_port['id']
            if 'script' in dictConfigData:
                CONFIG_OBJECTS['SCRIPT'] = {}
                listScripts = dictConfigData['script']
                for each_script in listScripts:
                    CONFIG_OBJECTS['SCRIPT'][each_script['PATH']] = each_script['id']
            if (('nfs' in dictConfigData) and  (AgentConstants.OS_NAME in AgentConstants.NFS_MON_SUPPORTED)):
                CONFIG_OBJECTS['NFS'] = {}
                listNFS = dictConfigData['nfs']
                for each_nfs in listNFS:
                    CONFIG_OBJECTS['NFS'][each_nfs['id']] = each_nfs['id']
            if ((('file' in dictConfigData) or ('dir' in dictConfigData)) and  (AgentConstants.OS_NAME in AgentConstants.NFS_MON_SUPPORTED)):
                CONFIG_OBJECTS['FILE'] = {}
                if 'file' in dictConfigData:
                    listFiles = dictConfigData['file']
                    for each_file in listFiles:
                        CONFIG_OBJECTS['FILE'][each_file['id']] = each_file['id']
                if 'dir' in dictConfigData:
                    listDirs = dictConfigData['dir']
                    for each_dir in listDirs:
                        CONFIG_OBJECTS['FILE'][each_dir['id']] = each_dir['id']
            if 'logrule' in dictConfigData:
                CONFIG_OBJECTS['logrule'] = {}
                listFilters = dictConfigData['logrule']
                if listFilters:
                    UdpHandler.SysLogUtil.reloadCustomFilters(listFilters)
                for each_filter in listFilters:
                    CONFIG_OBJECTS['logrule'][each_filter['filter_name']] = each_filter['id']
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(AgentConstants.AGENT_CUSTOM_MONITORS_GROUP_FILE)
            fileObj.set_dataType('json')
            fileObj.set_mode('rb')
            fileObj.set_dataEncoding('UTF-8')
            fileObj.set_loggerName(AgentLogger.CHECKS)
            fileObj.set_logging(False)
            bool_toReturn, dict_monitorsInfo = FileUtil.readData(fileObj)
            dict_monitorsInfo['MonitorGroup']['ChecksMonitoring']['Port'] = dictConfigData['port']
            dict_monitorsInfo['MonitorGroup']['ChecksMonitoring']['URL'] = dictConfigData['url']
            if 'nfs' in dictConfigData:
                dict_monitorsInfo['MonitorGroup']['ChecksMonitoring']['NFSMonitoring'] = dictConfigData['nfs']
            dict_monitorsInfo['MonitorGroup']['ChecksMonitoring']['FileDirectory'] = dictConfigData['file']+dictConfigData['dir']
            #add nfs and script dict config data here into custom json
            fileObj.set_data(dict_monitorsInfo)
            fileObj.set_mode('wb')
            with customFileLock:
                #time.sleep(20)
                bool_toReturn, str_filePath = FileUtil.saveData(fileObj)
            BasicClientHandler.reload()
        else:
            AgentLogger.log([AgentLogger.STDOUT],'=============== Skipped Updating resoure config values =======')
        AgentLogger.log([AgentLogger.STDOUT],' Updated config values ' + json.dumps(CONFIG_OBJECTS))
    except Exception as e:
        AgentLogger.log([AgentLogger.STDOUT,AgentLogger.STDERR],'*************************** Exception While loading agent config data from server *************************** '+ repr(e))
        traceback.print_exc()

def updateID(dictProcessData):
    try:
        for eachProcess in dictProcessData['Process Details']:
            if "COMMANDLINE" in eachProcess:
                if eachProcess['COMMANDLINE'] in CONFIG_OBJECTS['Processes']:
                    id  = CONFIG_OBJECTS['Processes'][eachProcess['COMMANDLINE']]
                    eachProcess['id'] = id
                    eachProcess['status'] = '1'
                else:
                    eachProcess['id'] = '-9'
                    eachProcess['status'] = '1'
            else:
                eachProcess['id'] = '-1'
                eachProcess['status'] = '0'
        return dictProcessData
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR],'*************************** Exception While updating IDs in process data *************************** '+ repr(e))
        traceback.print_exc()

def getRootData(dictData, dictKeyData, dictConfig):
    try:
        if 'CPU Utilization' in dictKeyData:
            dictData['cper'] = dictKeyData['CPU Utilization'][0]['LoadPercentage']
        elif 'Context Switches' in dictKeyData:
            dictData['ctxtsw'] = dictKeyData['Context Switches'][0]['ContextSwitchesPersec']
        elif 'Disk Statistics' in dictKeyData:
            dictData['dreads'] = dictKeyData['Disk Statistics'][0]['DiskReadBytesPersec']
            dictData['dwrites'] = dictKeyData['Disk Statistics'][0]['DiskWriteBytesPersec']
            dictData['diskio'] = int(dictData['dreads'])+int(dictData['dwrites'])
        elif 'Number of Interrupts' in dictKeyData:
            dictData['interrupts'] = dictKeyData['Number of Interrupts'][0]['InterruptsPersec']
    except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for root node *********************************')
            traceback.print_exc()

def getAssetData(dictData, dictKeyData, dictConfig):
    try:
        if 'Number Of Cores' in dictKeyData:
            dictData['asset']['core'] = dictKeyData['Number Of Cores'][0]['NumberOfCores']
        elif 'Memory Utilization' in dictKeyData:
            dictData['asset']['os'] = dictKeyData['Memory Utilization'][0]['Caption']
        elif 'OS Architecture' in dictKeyData:
            dictData['asset']['arch'] = dictKeyData['OS Architecture'][0]['OSArchitecture']
        elif 'CPU Utilization' in dictKeyData:
            dictData['asset']['cpu'] = dictKeyData['CPU Utilization'][0]['Name']
        dictData['asset']['instance'] = AgentConstants.AGENT_INSTANCE_TYPE
    except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for asset node*********************************')
            traceback.print_exc()

def getMemoryData(dictData, dictKeyData, dictConfig):
    defMemPercent = 0
    defMemory = 0
    try:
        if 'Memory Utilization' in dictKeyData:
            if ('FreePhysicalMemory' in dictKeyData['Memory Utilization'][0]):
                freePhy = round(int(dictKeyData['Memory Utilization'][0]['FreePhysicalMemory'])/1024)
            else:
                freePhy = defMemory
            if ('TotalVisibleMemorySize' in dictKeyData['Memory Utilization'][0]):
                totPhy = round(int(dictKeyData['Memory Utilization' ][0]['TotalVisibleMemorySize'])/1024)
            else:
                totPhy = defMemory
            if ('FreeVirtualMemory' in dictKeyData['Memory Utilization'][0]):
                freeVir = round(int(dictKeyData['Memory Utilization' ][0]['FreeVirtualMemory'])/1024)
            else:
                freeVir = defMemory
            if ('TotalVirtualMemorySize' in dictKeyData['Memory Utilization'][0]):
                totVir = round(int(dictKeyData['Memory Utilization' ][0]['TotalVirtualMemorySize'])/1024)
            else:
                totVir = defMemory
            dictData['memory']['fvirm'] = freeVir
            dictData['memory']['fvism'] = freePhy
            dictData['memory']['tvirm'] = totVir
            dictData['memory']['tvism'] = totPhy
            dictData['memory']['uvism'] = totPhy - freePhy
            dictData['memory']['uvirm'] = totVir - freeVir
            dictData['memory']['swpmemper'] = ((totVir - freeVir)/totVir)*100
            try:
                memUsedPercent = round((((totPhy - freePhy)/totPhy)*100),2)
            except ZeroDivisionError as e:
                memUsedPercent = defMemPercent
            dictData['mper'] = str(memUsedPercent)
            dictData['asset']['ram'] = totPhy
        elif 'Memory Statistics' in dictKeyData:
            dictData['memory']['pfaults'] = int(dictKeyData['Memory Statistics'][0]['PageFaultsPersec'])
            dictData['memory']['pin'] = int(dictKeyData['Memory Statistics'][0]['PagesInputPersec'])
            dictData['memory']['pout'] = int(dictKeyData['Memory Statistics'][0]['PagesOutputPersec'])
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for memory node *********************************')
        traceback.print_exc()

def getDiskData(dictData, dictKeyData, dictConfig):
    totalDisk = 0
    totalUsedDisk = 0
    defaultDiskPer = 0
    listDisks = []
    try:
        listKeyDicts = dictKeyData['Disk Utilization']
        for each_disk in listKeyDicts:
            temp_dict = {}
            if dictConfig and'DISKS' in dictConfig and each_disk['Name'] in dictConfig['DISKS']:
                temp_dict['id'] = dictConfig['DISKS'][each_disk['Name']]
            else:
                temp_dict['id'] = "None"
            try:
                freeSpace = float(each_disk['FreeSpace'])/(1024*1024)
            except:
                freeSpace = int(each_disk['FreeSpace'])/(1024*1024)
            try:
                totalSpace = float(each_disk['Size'])/(1024*1024)
            except:
                totalSpace = int(each_disk['Size'])/(1024*1024)
            usedSpace = totalSpace - freeSpace            
            totalDisk += totalSpace
            totalUsedDisk += usedSpace
            temp_dict['name'] = each_disk['Name']
            temp_dict['dfree'] = int(round(freeSpace,0))
            try:
                temp_dict['dfper'] = int(round(((freeSpace/totalSpace)*100),0))
            except ZeroDivisionError as e:
                temp_dict['dfper'] = defaultDiskPer
            temp_dict['dused'] = int(round(usedSpace,0))
            try:
                temp_dict['duper'] = int(round(((usedSpace/totalSpace)*100),0))
            except ZeroDivisionError as e:
                temp_dict['duper'] = defaultDiskPer
            listDisks.append(temp_dict)
        try:
            diskUsedPercent = int(round(((totalUsedDisk/totalDisk)*100),0))
        except ZeroDivisionError as e:
            diskUsedPercent = defaultDiskPer
        diskFreePercent = 100 - diskUsedPercent
        dictData['dfper'] = str(diskFreePercent)
        dictData['duper'] = str(diskUsedPercent)
        dictData.setdefault('disk',listDisks)
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for disk node *********************************')
        traceback.print_exc()

def getNetworkData(dictData, dictKeyData, dictConfig):
    listNics = []
    dictNicData = {}
    try:
        listKeyDict = dictKeyData['Network Data']
        for each_nic in listKeyDict:
            if ((each_nic['MACAddress'] in dictNicData) and (int(each_nic['Status']) == 2)):
                AgentLogger.log( AgentLogger.COLLECTOR, '*********** MAC Address already exists and status is unknown. Hence skipping!! ****************')
                continue
            if (str(each_nic['AdapterDesc']).startswith('veth')):
                AgentLogger.log( AgentLogger.COLLECTOR, '*********** Network interface name starts with veth. Hence skipping!! ****************')
                continue
            temp_dict = {}
            if dictConfig and 'NICS' in dictConfig and each_nic['MACAddress'] in dictConfig['NICS']:
                temp_dict['id'] = dictConfig['NICS'][each_nic['MACAddress']]
            else:
                temp_dict['id'] = "None"
            #temp_dict['dctime'] = dictKeyData['DATACOLLECTTIME']
            temp_dict['status'] = each_nic['Status']
            if int(each_nic['Status'])==2:
                temp_dict['status']=1
            temp_dict['name'] = each_nic['AdapterDesc']
            temp_dict['ipv4'] = each_nic['Ipv4Addrs']
            temp_dict['ipv6'] = each_nic['Ipv6Addrs']
            temp_dict['macadd'] = each_nic['MACAddress']
            temp_dict['bandwidth'] = each_nic['CurrentBandwidth']
            temp_dict['bytesrcv'] = each_nic['BytesReceivedPersec']
            temp_dict['bytessent'] = each_nic['BytesSentPersec']
            temp_dict['bytesrcvkb'] = (int(each_nic['BytesReceivedPersec'])/1024)
            temp_dict['bytessentkb'] = (int(each_nic['BytesSentPersec'])/1024)
            temp_dict['totbyteskb'] = temp_dict['bytesrcvkb'] +  temp_dict['bytessentkb']
            temp_dict['discardpkts'] = each_nic['PacketsOutboundDiscarded']
            temp_dict['errorpkts'] = each_nic['PacketsOutboundErrors']
            temp_dict['pktrcv'] = each_nic['PacketsReceivedUnicastPersec']
            temp_dict['pktsent'] = each_nic['PacketsSentUnicastPersec']
            dictNicData.setdefault(each_nic['MACAddress'],temp_dict)
        for (Macaddr,dictNic) in dictNicData.items():
            listNics.append(dictNic)
        dictData.setdefault('network',listNics)
        isempty_file = True
        if os.path.isfile('/sys/class/net/bonding_masters'):
            with open('/sys/class/net/bonding_masters', 'r') as bond_file:
                for line in bond_file:
                    if line.strip():
                        isempty_file = False
                        break
        if isempty_file is True:
            dictData.setdefault('bonding','false')
        else:
            dictData.setdefault('bonding','true')
    
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for network node *********************************')
        traceback.print_exc()

def getCPUData(dictData, dictKeyData, dictConfig):
    listCores = []
    try:
        listKeyDict = dictKeyData['CPU Cores Usage']
        for each_core in listKeyDict:
            temp_dict = {}
            temp_dict['core'] = each_core['Name']
            temp_dict['load'] = each_core['PercentProcessorTime']
            listCores.append(temp_dict)
        dictData.setdefault('cpu',listCores)
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for CPU node *********************************')
        traceback.print_exc()

def getCpuInfo():
    processor_dict=None
    bool_toReturn=True
    cpuCoreInfo=[]
    try:
        if os.path.isfile('/proc/cpuinfo'):
            for line in open('/proc/cpuinfo', 'r').readlines():
                if line.startswith('processor'):
                    if processor_dict:
                        cpuCoreInfo.append(processor_dict)
                    processor_dict={}
                line = line.split(":")
                if len(line) > 1:
                    processor_dict[line[0].strip()]=line[1].strip()
            cpuCoreInfo.append(processor_dict)
            AgentLogger.debug(AgentLogger.COLLECTOR,' Final Output --- {0}'.format(cpuCoreInfo))
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while Reading CPU Info File *********************************')
        traceback.print_exc()
        bool_toReturn=False
    return bool_toReturn,cpuCoreInfo


def getProcessMonitoring(dictData, dictKeyData, dictConfig):
    try:
        listProcesses=[]
        VISITED_KEYS=[]
        dictProcessData={}
        processData = {}
        listKeyDict = dictKeyData['Process Details']
        if not listKeyDict and AgentConstants.PROCESS_MONITORING_NAMES:
            for key,value in ACTIVE_PROCESS_DICT.items():
                process_id = key
                finalDict=processReCheck(value)
                processData.setdefault(process_id,finalDict)
        else:
            #AgentLogger.debug(AgentLogger.CHECKS,' list key dict -- {0}'.format(json.dumps(listKeyDict)))
            outputDict = {}
            for each_process in listKeyDict:
                process_name = each_process['pname']
                if process_name in outputDict:
                    list = outputDict.get(process_name)
                    temp_dict=getProcessTempDict(each_process)
                    list.append(temp_dict)
                else:
                    dictList = []
                    temp_dict=getProcessTempDict(each_process)
                    dictList.append(temp_dict)
                    outputDict.setdefault(process_name,dictList)
            for processid in ACTIVE_PROCESS_DICT.keys():
                process_config = ACTIVE_PROCESS_DICT[processid]
                process_id = process_config['id']
                regex_enaled = False
                pname = process_config['pn']
                process_args = process_config['args']
                regexEnabled = False
                if 'regex' in process_config:
                    regexEnabled = process_config['regex']
                processMonitoring = False
                if pname in outputDict:
                    processList = outputDict[pname]
                    retry_Once=False
                    for each_process_dict in processList:
                        args = each_process_dict['pargs']
                        if regexEnabled:
                            result = isRegexMatching(process_config,args)
                        else:
                            result = isArgsMatching(process_config,args)
                        if result:
                            innerDict={}
                            innerDict['name']=each_process_dict['pname']
                            innerDict['status'] = 1
                            innerDict['args'] = each_process_dict['pargs']
                            innerDict['path'] = each_process_dict['path']
                            innerDict['cpu'] = round(float(each_process_dict['pcpu']),1)
                            innerDict['memory'] = round(float(each_process_dict['pmem']),1)
                            innerDict['thread'] = each_process_dict['pthread']
                            innerDict['handle'] = each_process_dict['phandle']
                            innerDict['instance'] = 1
                            innerDict['priority'] = each_process_dict['priority']
                            innerDict['user'] = each_process_dict['user']
                            innerDict['id']=process_id
                            if ((process_id in processData) and (each_process_dict['AVAILABILITY'] == 1)):
                                innerDict['cpu'] = round(float(innerDict['cpu']) + float(processData[process_id]['cpu']),1)
                                innerDict['memory'] = round(float(innerDict['memory']) + float(processData[process_id]['memory']),1)
                                innerDict['instance'] = 1 + processData[process_id]['instance']
                                processData[process_id] = innerDict
                            elif process_id in processData:
                                innerDict['instance'] = 1 + processData[process_id]['instance']
                                processData[process_id] = innerDict
                            else:
                                processData.setdefault(process_id,innerDict)
                        else:
                            retry_Once=True
                    if process_id in processData:
                        retry_Once=False
                    if retry_Once:
                        finalDict = processReCheck(process_config)
                        processData.setdefault(process_id,finalDict)
                else:
                    finalDict = processReCheck(process_config)
                    processData.setdefault(process_id,finalDict)
        
        listProcesses=[]
        for key in processData:
            listProcesses.append(processData[key])
        dictData.setdefault('process',listProcesses)
        AgentLogger.debug(AgentLogger.CHECKS," process monitoring data --- {0}".format(listProcesses))
        
    except Exception as e:
        traceback.print_exc()

def isRegexMatching(process_config,args):
    regexMatch = False
    try:
        if process_config['regex_exp'].search(args):
            AgentLogger.debug(AgentLogger.CHECKS," regex matched --- {0}".format(args))
            regexMatch = True
        else:
            AgentLogger.debug(AgentLogger.CHECKS," args not matched - from command  --- {0}".format(args))
            AgentLogger.debug(AgentLogger.CHECKS," args not matched - regex --- {0}".format(process_config['regex_exp']))
    except Exception as e:
        traceback.print_exc()
    return regexMatch
        
def isArgsMatching(process_config,args):
    argsMatch = False
    try:
        if process_config['args'] == args:
            AgentLogger.debug(AgentLogger.CHECKS," args matched --- {0}".format(args))
            argsMatch = True
        else:
            AgentLogger.debug(AgentLogger.CHECKS," args not matched - from command  --- {0}".format(args))
            AgentLogger.debug(AgentLogger.CHECKS," args not matched - from config --- {0}".format(process_config['args']))
    except Exception as e:
        traceback.print_exc()
    return argsMatch

def getProcessTempDict(process):
    temp_dict={}
    try:
        temp_dict['AVAILABILITY'] = process['AVAILABILITY']
        temp_dict['pargs'] = process['pargs']
        temp_dict['pname'] = process['pname']
        temp_dict['path'] = process['path']
        temp_dict['pcpu'] = round(float(process['pcpu']),1)
        temp_dict['pmem'] = round(float(process['pmem']),1)
        temp_dict['pthread'] = process['pthread']
        temp_dict['phandle'] = process['phandle']
        if 'priority' in process:
            temp_dict['priority'] = process['priority']
        if 'user' in process:
            temp_dict['user'] = process['user']
        temp_dict['instance'] = 1
    except Exception as e:
        traceback.print_exc()
    finally:
        return temp_dict

def getProcessData(dictData, dictKeyData, dictConfig):
    listProcesses = []
    dictProcessData = {}
    AgentLogger.debug(AgentLogger.COLLECTOR,'process data -- {0}'.format(dictKeyData['Process Details']))
    try:
        listKeyDict = dictKeyData['Process Details']
        for each_process in listKeyDict:
            pHId = getHashID(each_process['COMMANDLINE'])
            if pHId in ACTIVE_PROCESS_DICT.keys():
                temp_dict = {}
                if dictConfig and 'Processes' in dictConfig and each_process['COMMANDLINE'] in dictConfig['Processes']:
                    temp_dict['id'] = dictConfig['Processes'][each_process['COMMANDLINE']]
                else:
                    temp_dict['id'] = "None"
                if each_process['AVAILABILITY'] == 1:
                    temp_dict['status'] = 1
                    temp_dict['args'] = each_process['COMMANDLINE']
                    temp_dict['name'] = each_process['PROCESS_NAME']
                    temp_dict['path'] = each_process['EXEUTABLE_PATH']
                    #temp_dict['PID'] = each_process['PROCESS_ID']
                    #temp_dict['PS_CPU_UTILIZATION'] = each_process['PS_CPU_UTILIZATION']
                    temp_dict['cpu'] = round(float(each_process['CPU_UTILIZATION']),1)
                    #temp_dict['PS_MEMORY_UTILIZATION'] = each_process['PS_MEMORY_UTILIZATION']
                    temp_dict['memory'] = round(float(each_process['MEMORY_UTILIZATION']),1)
                    temp_dict['thread'] = each_process['THREAD_COUNT']
                    temp_dict['handle'] = each_process['HANDLE_COUNT']
                    temp_dict['instance'] = 1
                else:
                    temp_dict['status'] = 0
                    temp_dict['instance'] = 1
                    temp_dict['args'] = each_process['COMMANDLINE']
                if ((pHId in dictProcessData) and (each_process['AVAILABILITY'] == 1)):
                    temp_dict['cpu'] = round(float(temp_dict['cpu']) + float(dictProcessData[pHId]['cpu']),1)
                    temp_dict['memory'] = round(float(temp_dict['memory']) + float(dictProcessData[pHId]['memory']),1)
                    temp_dict['instance'] = 1 + dictProcessData[pHId]['instance']
                    dictProcessData[pHId] = temp_dict
                    AgentLogger.log(AgentLogger.COLLECTOR," PHID for up process: " + str(each_process['COMMANDLINE']) + " already exists as : " + str(dictProcessData[pHId])) 
                elif pHId in dictProcessData:
                    temp_dict['instance'] = 1 + dictProcessData[pHId]['instance']
                    dictProcessData[pHId] = temp_dict
                    AgentLogger.log(AgentLogger.COLLECTOR," PHID for down process : " + str(each_process['COMMANDLINE']) + " already exists as : " + str(dictProcessData[pHId]))
                else:
                    AgentLogger.log(AgentLogger.COLLECTOR," PHID for : " + str(each_process['COMMANDLINE']) + " is new and process data added now") 
                    dictProcessData.setdefault(pHId,temp_dict)
            else:
                AgentLogger.log(AgentLogger.COLLECTOR,"Process Command line does not match args of any process under monitor" + str(each_process['COMMANDLINE']) + " with HID : " +str(pHId))
        #findDownProcesses(dictProcessData)
        AgentLogger.debug(AgentLogger.COLLECTOR,'process data finale -- {0}'.format(dictProcessData))
        listProcesses = convertProcessDict(dictProcessData)
        dictData.setdefault('process',listProcesses)
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for process node *********************************')
        traceback.print_exc()
        
def getSystemData(dictData,dictKeyData,dictConfig):
    outputDict = {}
    cpuCoreInfo = []
    try:
        if 'System Stats' in dictKeyData:
            dictData['systemstats']['1min'] = dictKeyData['System Stats'][0]['Last 1 min Avg']
            dictData['systemstats']['5min'] = dictKeyData['System Stats'][0]['Last 5 min Avg']
            dictData['systemstats']['15min'] = dictKeyData['System Stats'][0]['Last 15 min Avg']
            if dictKeyData['System Stats'][0]['Process Count']:
                counts=dictKeyData['System Stats'][0]['Process Count'].split('/')
                dictData['systemstats']['cr'] = counts[0]#cr - currently running
                dictData['systemstats']['totp'] = counts[1]#totp - total process in the system
        if 'System Uptime' in dictKeyData:
            no_of_cores = dictData['asset']['core']
            up_time=dictKeyData['System Uptime'][0]['Utime']
            idle_time=dictKeyData['System Uptime'][0]['IdleTime']
            idle_time = float(idle_time) / int(no_of_cores)
            busy_time=float(up_time)-float(idle_time)
            dictData['systemstats']['bt'] = busy_time
            dictData['systemstats']['it'] = idle_time
        dictData['systemstats']['utt'] = AgentUtil.getUptimeInChar()
        if 'Process Queue' in dictKeyData:
            dictData['systemstats']['prun'] = dictKeyData['Process Queue'][0]['Procs Running']
            dictData['systemstats']['pblck'] = dictKeyData['Process Queue'][0]['Procs Blocked']
        if 'Login Count' in dictKeyData:
            if dictKeyData['Login Count']:
                str_loginCount = dictKeyData['Login Count'][0]['Login Count']
                dictData['systemstats']['lc'] = str_loginCount.strip().split(" ")[0]
        #if 'CPU Cores Usage' in dictKeyData:
         #   updateCoreInfo(dictData,dictKeyData)
    except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for System Stats node*********************************')
            traceback.print_exc()

def updateCoreInfo(dictData,dictKeyData):
    listCores = []
    cpucore_dict={'UserModeTime':0,'NiceTime':0,'SystemModeTime':0,'IdleTime':0,'IOWaitTime':0,'InterruptServicingTime':0,'SoftirqsServicingTime':0,'OtherOsVirtualEnvTime':0,'GuestOsVirtualCpuRunTime':0,'NicedGuestRunTime':0,'PercentProcessorTime':0}
    try:
        listKeyDict = dictKeyData['CPU Cores Usage']
        AgentLogger.debug(AgentLogger.COLLECTOR,'cores usage ---- {0}'.format(json.dumps(listKeyDict)))
        for each_core in listKeyDict:
            temp_dict={}
            temp_dict['Name']=each_core['Name']
            temp_dict['UserModeTime'] = each_core['UserModeTime']
            cpucore_dict['UserModeTime']+=float(temp_dict['UserModeTime'])
            temp_dict['NiceTime'] = each_core['NiceTime']
            cpucore_dict['NiceTime']+=float(temp_dict['NiceTime'])
            temp_dict['SystemModeTime'] = each_core['SystemModeTime']
            cpucore_dict['SystemModeTime']+=float(temp_dict['SystemModeTime'])
            temp_dict['IdleTime'] = each_core['IdleTime']
            cpucore_dict['IdleTime']+=float(temp_dict['IdleTime'])
            temp_dict['IOWaitTime'] = each_core['IOWaitTime']
            cpucore_dict['IOWaitTime']+=float(temp_dict['IOWaitTime'])
            temp_dict['InterruptServicingTime'] = each_core['InterruptServicingTime']
            cpucore_dict['InterruptServicingTime']+=float(temp_dict['InterruptServicingTime'])
            temp_dict['SoftirqsServicingTime'] = each_core['SoftirqsServicingTime']
            cpucore_dict['SoftirqsServicingTime']+=float(temp_dict['SoftirqsServicingTime'])
            temp_dict['OtherOsVirtualEnvTime'] = each_core['OtherOsVirtualEnvTime']
            cpucore_dict['OtherOsVirtualEnvTime']+=float(temp_dict['OtherOsVirtualEnvTime'])
            temp_dict['GuestOsVirtualCpuRunTime'] = each_core['GuestOsVirtualCpuRunTime']
            cpucore_dict['GuestOsVirtualCpuRunTime']+=float(temp_dict['GuestOsVirtualCpuRunTime'])
            temp_dict['NicedGuestRunTime'] = each_core['NicedGuestRunTime']
            cpucore_dict['NicedGuestRunTime']+=float(temp_dict['NicedGuestRunTime'])
            temp_dict['PercentProcessorTime'] = each_core['PercentProcessorTime']
            cpucore_dict['PercentProcessorTime']+=float(temp_dict['PercentProcessorTime'])
            listCores.append(temp_dict)
        cpucore_dict['Name']='Total'
        listCores.append(cpucore_dict)
        dictData.setdefault('cpustats',listCores)
        bool_return,core_info=getCpuInfo()
        if bool_return==True:
            cpu_info=[]
            for each_info in core_info:
                info_dict={}
                info_dict['processor']=each_info['processor']
                info_dict['stepping']=each_info['stepping']
                info_dict['model']=each_info['model']
                info_dict['name']=each_info['model name']
                cpu_info.append(info_dict)
            dictData.setdefault('cpuinfo',cpu_info)
            AgentLogger.debug(AgentLogger.COLLECTOR,'dict data ---- {0}'.format(json.dumps(cpu_info)))
    except Exception as e:
            traceback.print_exc()

def getMemoryStats(dictData,dictKeyData,dictConfig):
    try:
        if 'Memory Stats' in dictKeyData:
            mem_dict=dictKeyData['Memory Stats'][0]
            dictData['memorystats']['totalmem'] =  round(int(mem_dict['Total Memory'].split(" ")[0])/1024)
            dictData['memorystats']['freemem'] =   round(int(mem_dict['Free Memory'].split(" ")[0])/1024)
            dictData['memorystats']['buffers'] =   round(int(mem_dict['Buffers'].split(" ")[0])/1024)
            dictData['memorystats']['cached'] =    round(int(mem_dict['Cached'].split(" ")[0])/1024)
            dictData['memorystats']['appused'] =   (dictData['memorystats']['totalmem']) - (dictData['memorystats']['freemem']+dictData['memorystats']['buffers']+dictData['memorystats']['cached'])  
            dictData['memorystats']['swapcached'] = round(int(mem_dict['Swap Cached'].split(" ")[0])/1024)
            dictData['memorystats']['swaptotal'] = round(int(mem_dict['Swap Total'].split(" ")[0])/1024)
            dictData['memorystats']['swapfree'] = round(int(mem_dict['Swap Free'].split(" ")[0])/1024)
            dictData['memorystats']['swapused'] = (dictData['memorystats']['swaptotal']) - (dictData['memorystats']['swapcached']+ dictData['memorystats']['swapfree'])
            dictData['memorystats']['commitLimit'] = round(int(mem_dict['Commit Limit'].split(" ")[0])/1024)
            dictData['memorystats']['committedas'] = round(int(mem_dict['Commited AS'].split(" ")[0])/1024)
            dictData['memorystats']['dirty'] = round(int(mem_dict['Dirty'].split(" ")[0])/1024)
            dictData['memorystats']['slab'] = round(int(mem_dict['Slab'].split(" ")[0])/1024)
            dictData['memorystats']['writeback'] = round(int(mem_dict['WriteBack'].split(" ")[0])/1024)
            dictData['memorystats']['anonpages'] = round(int(mem_dict['AnonPages'].split(" ")[0])/1024)
            dictData['memorystats']['mapped'] = round(int(mem_dict['Mapped'].split(" ")[0])/1024)
            dictData['memorystats']['pagetables'] = round(int(mem_dict['PageTables'].split(" ")[0])/1024)
            dictData['memorystats']['pgmajfault'] = round(int(mem_dict['Major Fault'].split(" ")[0]))
            dictData['memorystats']['pswpin'] = round(int(mem_dict['Swap In'].split(" ")[0]))
            dictData['memorystats']['pswpout'] = round(int(mem_dict['Swap Out'].split(" ")[0]))
            dictData['memorystats']['am'] = round(int(mem_dict['Active Memory'].split(" ")[0])/1024)
            dictData['memorystats']['inam'] = round(int(mem_dict['InActive Memory'].split(" ")[0])/1024)
    except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for Memory Stats node*********************************')
            traceback.print_exc()        

def getNetworkStats(dictData,dictKeyData,dictConfig):
    try:
        if 'UDP Stats' in dictKeyData:
            udp_dict=dictKeyData['UDP Stats'][0]
            dictData['networkstats']['uport'] = udp_dict['Ports']
            dictData['networkstats']['ueport'] = udp_dict['ErrorPorts']
            dictData['networkstats']['indg'] = udp_dict['InDatagrams']
            dictData['networkstats']['outdg'] = udp_dict['OutDatagrams']
            dictData['networkstats']['rcvbfer'] = udp_dict['RcvbufErrors']
            dictData['networkstats']['sndbfer'] = udp_dict['SndbufErrors']
        if 'TCP Stats' in dictKeyData:
            tcp_dict=dictKeyData['TCP Stats'][0]
            dictData['networkstats']['actop'] = tcp_dict['ActiveOpens']
            dictData['networkstats']['pasop'] = tcp_dict['PassiveOpens']
            dictData['networkstats']['inseg'] = tcp_dict['InSegs']
            dictData['networkstats']['outseg'] = tcp_dict['OutSegs']
            dictData['networkstats']['inerr'] = tcp_dict['InErrors']
            dictData['networkstats']['con'] = tcp_dict['CurrEstab']
            dictData['networkstats']['af'] = tcp_dict['AttemptFails']
            dictData['networkstats']['rtseg'] = tcp_dict['RetransSegs']
            dictData['networkstats']['outrst'] = tcp_dict['OutRsts']
            dictData['networkstats']['estres'] = tcp_dict['EstabResets']
        if 'IP Stats' in dictKeyData:
            ip_dict=dictKeyData['IP Stats'][0]
            dictData['networkstats']['ipinrx'] = ip_dict['InReceives']
            dictData['networkstats']['ipindel'] = ip_dict['InDelivers']
            dictData['networkstats']['iphdr'] = ip_dict['ipInHdrErrors']
            dictData['networkstats']['ipadr'] = ip_dict['ipInAddrErrors']
            dictData['networkstats']['fwdgm'] = ip_dict['ForwDatagrams']
            dictData['networkstats']['unknwn'] = ip_dict['InUnknownProtos']
            dictData['networkstats']['discard'] = ip_dict['InDiscards']
            dictData['networkstats']['otrq'] = ip_dict['OutRequests']
            dictData['networkstats']['ok'] = ip_dict['FragOKs']
            dictData['networkstats']['fail'] = ip_dict['FragFails']
            dictData['networkstats']['create'] = ip_dict['FragCreates']
            dictData['networkstats']['retym'] = ip_dict['ReasmTimeout']
            dictData['networkstats']['reamrq'] = ip_dict['ReasmReqds']
            dictData['networkstats']['reamok'] = ip_dict['ReasmOKs']
            dictData['networkstats']['reamf'] = ip_dict['ReasmFails']
        if 'ICMP Stats' in dictKeyData:
            icmp_dict=dictKeyData['ICMP Stats'][0]
            dictData['networkstats']['imsg'] = icmp_dict['InMsg']
            dictData['networkstats']['omsg'] = icmp_dict['OutMsg']
            dictData['networkstats']['iner'] = icmp_dict['InErrors']
            dictData['networkstats']['oter'] = icmp_dict['OutErrors']
            dictData['networkstats']['iecho'] = icmp_dict['InEchos']
            dictData['networkstats']['oecho'] = icmp_dict['OutEchos']
        dictData.setdefault('networkstats',dictData['networkstats'])
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting consolidated values for Network Stats node*********************************')
        traceback.print_exc()
        
def convertProcessDict(dictProcessData):
    defPercent = 0
    listProcesses = []
    try:
        VISITED_KEYS = []
        if dictProcessData:
            for (key,eachProcDict) in dictProcessData.items():
                if ((eachProcDict['instance'] > 1) and (eachProcDict['status'] == 1)):
                    try:
                        eachProcDict['cpu'] = round(float(eachProcDict['cpu'])/int(eachProcDict['instance']),1)
                    except ZeroDivisionError as e:
                        eachProcDict['cpu'] = defPercent
                    try:
                        eachProcDict['memory'] = round(float(eachProcDict['memory'])/int(eachProcDict['instance']),1)
                    except ZeroDivisionError as e:
                        eachProcDict['memory'] = defPercent
                    AgentLogger.log(AgentLogger.COLLECTOR," Average Cpu util and Mem util found for the process with commandline : " + eachProcDict['args'] + " with values as : " + str(eachProcDict['cpu']) + " and " + str(eachProcDict['memory']))
                else:
                    AgentLogger.log(AgentLogger.COLLECTOR,"INSTANCE COUNT IS 1 or down process for : "  + str(eachProcDict['args']))
                VISITED_KEYS.append(key)
                listProcesses.append(eachProcDict)
        KEY_DIFF = list(set(ACTIVE_PROCESS_DICT.keys())-set(VISITED_KEYS))
        for each_key in KEY_DIFF:
            tempDict = {}
            #tempID = None
            if ((each_key in ACTIVE_PROCESS_DICT) and ('id' in ACTIVE_PROCESS_DICT[each_key])):
                tempID = ACTIVE_PROCESS_DICT[each_key]['id']
            else:
                tempID = "None"
            if ((each_key in ACTIVE_PROCESS_DICT) and ('pn' in ACTIVE_PROCESS_DICT[each_key])):
                tempPN = ACTIVE_PROCESS_DICT[each_key]['pn']
            else:
                tempPN = "None"
            if ((each_key in ACTIVE_PROCESS_DICT) and ('pth' in ACTIVE_PROCESS_DICT[each_key])):
                tempPath = ACTIVE_PROCESS_DICT[each_key]['pth']
            else:
                tempPath = "None"
            if ((each_key in ACTIVE_PROCESS_DICT) and ('args' in ACTIVE_PROCESS_DICT[each_key])):
                tempArgs = ACTIVE_PROCESS_DICT[each_key]['args']
                AgentLogger.log(AgentLogger.COLLECTOR," Suspected down process info for " + str(tempArgs))
            else:
                tempArgs = "None"
            tempDict['args'] = tempArgs
            tempDict['id'] = tempID
            tempDict['name'] = tempPN
            tempDict['path'] = tempPath
            if tempArgs != "None":
                AgentLogger.log(AgentLogger.COLLECTOR,"Additional check for suspected down process: " + str(tempPN))
                str_command = AgentConstants.PROCESS_STATUS_COMMAND + " \"" + tempArgs.strip() + "\" | wc -l"
                isSuccess, str_output = AgentUtil.executeCommand(str_command)
                AgentLogger.log(AgentLogger.COLLECTOR," Printing output from additional check command " + str_command + " : " + str_output)
                if isSuccess:
                    try:
                        if int(str_output) > 0:
                            tempDict['status'] = 1
                        else:
                            tempDict['status'] = 0
                    except Exception as e:
                        tempDict['status'] = 0
            else:
                tempDict['status'] = 0
            listProcesses.append(tempDict)
    except Exception as e:
        AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while converting process dict to list for process node *********************************')
        traceback.print_exc()
    finally:
        return listProcesses

def processReCheck(processDict):
    returnDict = {}
    str_args = str(processDict['args'])
    AgentLogger.log(AgentLogger.CHECKS,"Retry Check for suspected down process : " + str(processDict['pn']) + " with args : " + str_args)
    str_command = AgentConstants.PROCESS_STATUS_COMMAND + " \"" + str_args.strip() + "\" | wc -l"
    AgentLogger.log(AgentLogger.CHECKS,"Process Retry command : "+ str_command)
    executorObj = AgentUtil.Executor()
    executorObj.setLogger(AgentLogger.CHECKS)
    executorObj.setTimeout(7)
    executorObj.setCommand(str_command)
    executorObj.executeCommand()
    str_output = str(executorObj.getStdOut())
    isSuccess = executorObj.isSuccess()            
    AgentLogger.log(AgentLogger.CHECKS,"Output of Process Retry command : " + str_output)
    if isSuccess:
        try:
            if int(str_output) > 0:
                returnDict['status'] = 1
                returnDict['args'] = processDict['args']
                returnDict['id']=processDict['id']
            else:
                returnDict['status'] = 0
                returnDict['args'] = processDict['args']
                returnDict['id']=processDict['id']
        except Exception as e:
            AgentLogger.log(AgentLogger.CHECKS,"Exception Occured in process ReCheck ")
            traceback.print_exc()
    AgentLogger.log(AgentLogger.CHECKS,"Final Recheck Output : " + str(returnDict))
    return returnDict


def addDownProcCheck(listProcessNames):
    bool_toUpdate = False
    for each_key in ACTIVE_PROCESS_DICT.keys():
        if ACTIVE_PROCESS_DICT[each_key]['pn'] in listProcessNames:
            str_args = str(ACTIVE_PROCESS_DICT[each_key]['args'])
            AgentLogger.log(AgentLogger.COLLECTOR,"Additional check for suspected down process : " + str(ACTIVE_PROCESS_DICT[each_key]['pn']) + " with args : " + str_args)
            str_command = AgentConstants.PROCESS_STATUS_COMMAND + " \"" + str_args.strip() + "\" | wc -l"
            #isSuccess, str_output = AgentUtil.executeCommand(str_command)
            AgentLogger.log(AgentLogger.COLLECTOR,"TEST_PROCESS_DOWN_COMMAND : "+ str_command)
            executorObj = AgentUtil.Executor()
            executorObj.setLogger(AgentLogger.COLLECTOR)
            executorObj.setTimeout(7)
            executorObj.setCommand(str_command)
            #executorObj.redirectToFile(True)
            executorObj.executeCommand()
            str_output = str(executorObj.getStdOut())
            isSuccess = executorObj.isSuccess()            
            AgentLogger.log(AgentLogger.COLLECTOR," Printing output from additional check command : " + str_output)
            if isSuccess:
                try:
                    if int(str_output) > 0:
                        pass
                    else:
                        bool_toUpdate = True
                except Exception as e:
                    bool_toUpdate = True
    AgentLogger.log(AgentLogger.COLLECTOR," Final value of boolean variable toUpdate is : " + str(bool_toUpdate))
    return bool_toUpdate
            

class ConsolidatorCollector():
    dictData = None
    def __init__(self):
        self.dictData = {}
        self.setDefaultValues(self.dictData)
        self.setResourceValues(self.dictData,CONFIG_OBJECTS)
    def setDefaultValues(self,dictData):
        try:
            self.dictData.setdefault('avail', 1)
            self.dictData.setdefault('reason', "Server up")
            ctime = str(AgentUtil.getTimeInMillis())
            self.dictData.setdefault('dc' , ctime)
            self.dictData.setdefault('asset',{})
            self.dictData.setdefault('TOPCPUPROCESS',{})
            self.dictData.setdefault('TOPMEMORYPROCESS',{})
            self.dictData.setdefault('systemstats',{})
            self.dictData.setdefault('memorystats',{})
            self.dictData.setdefault('networkstats',{})
            self.dictData['asset'].setdefault('hostname', AgentConstants.HOST_NAME)
            self.dictData['asset'].setdefault('ip', AgentConstants.IP_ADDRESS)
            self.dictData.setdefault('memory',{})
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting default consolidated values *********************************')
            traceback.print_exc()
    def setResourceValues(self,dictData,dictConfig):
        listURLs = []
        listPorts = []
        listFiles = []
        listScripts = []
        listNFS = []
        #listDirs = []
        listSysLogs = []
        dictURLData = None
        dictPortData = None
        dictFileData = None
        #dictDirData = None
        dictScriptData = None
        dictNFSData = None
        dictSysLogData = None
        try:
            #AgentLogger.log(AgentLogger.CHECKS,'previous checks data in dc '+repr(BasicClientHandler.CHECKS_DATA))
            with BasicClientHandler.globalDClock:
                if 'url' in BasicClientHandler.CHECKS_DATA:
                    dictURLData = BasicClientHandler.CHECKS_DATA['url']
                if 'port' in BasicClientHandler.CHECKS_DATA:
                    dictPortData = BasicClientHandler.CHECKS_DATA['port']
                if 'file' in BasicClientHandler.CHECKS_DATA:
                    dictFileData = BasicClientHandler.CHECKS_DATA['file']
                #if 'dir' in BasicClientHandler.CHECKS_DATA:
                #    dictDirData = BasicClientHandler.CHECKS_DATA['dir']
                if 'logrule' in BasicClientHandler.CHECKS_DATA:
                    dictSysLogData = BasicClientHandler.CHECKS_DATA['logrule']
                if 'script' in BasicClientHandler.CHECKS_DATA:
                    dictScriptData = BasicClientHandler.CHECKS_DATA['script']
                if 'nfs' in BasicClientHandler.CHECKS_DATA:
                    dictNFSData = BasicClientHandler.CHECKS_DATA['nfs']
            if dictURLData:
                for each_check_id in dictURLData:
                    temp_dict = {}
                    temp_dict = dict(dictURLData[each_check_id])
                    if ((dictConfig) and ('URL' in dictConfig) and (str(each_check_id) in dictConfig['URL'])):
                        temp_dict['id'] = dictConfig['URL'][str(each_check_id)]
                    else:
                        temp_dict['id'] = "None"
                    #temp_dict['CHECK_ID'] = each_check_id
                    #temp_dict['URL'] = eachURL['URL']
                    #temp_dict['Status'] = eachURL['STATE']
                    listURLs.append(temp_dict)
            self.dictData.setdefault('url',listURLs)
            if dictPortData:
                for each_check_id in dictPortData:
                    temp_dict = {}
                    temp_dict = dict(dictPortData[each_check_id])
                    if ((dictConfig) and ('PORT' in dictConfig) and (str(each_check_id) in dictConfig['PORT'])):
                        temp_dict['id'] = dictConfig['PORT'][str(each_check_id)]
                    else:
                        temp_dict['id'] = "None"
                    listPorts.append(temp_dict)
            self.dictData.setdefault('port',listPorts)
            if dictFileData:
                for each_check_id in dictFileData:
                    temp_dict_file = {}
                    #temp_dict = dict(dictFileData[each_check_id])
                    temp_dict_file = dict(dictFileData[each_check_id])
                    #a = del temp_dict_file['c_type']
                    if (dictConfig and ('FILE' in dictConfig) and (str(each_check_id) in dictConfig['FILE'])):
                        temp_dict_file['id'] = dictConfig['FILE'][str(each_check_id)]
                    else:
                        temp_dict_file['id'] = "None"
                    listFiles.append(temp_dict_file)
            self.dictData.setdefault('file',listFiles)
            if dictScriptData:
                for each_check_id in dictScriptData:
                    temp_dict = {}
                    temp_dict = dict(dictScriptData[each_check_id])
                    if ((dictConfig) and ('SCRIPT' in dictConfig) and (str(each_check_id) in dictConfig['SCRIPT'])):
                        temp_dict['id'] = dictConfig['SCRIPT'][str(each_check_id)]
                    else:
                        temp_dict['id'] = "None"
                    listScripts.append(temp_dict)
            self.dictData.setdefault('script',listScripts)
            if dictNFSData:
                for each_check_id in dictNFSData:
                    temp_dict = {}
                    temp_dict = dict(dictNFSData[each_check_id])
                    if ((dictConfig) and ('NFS' in dictConfig) and (str(each_check_id) in dictConfig['NFS'])):
                        temp_dict['id'] = dictConfig['NFS'][str(each_check_id)]
                    else:
                        temp_dict['id'] = "None"
                    listNFS.append(temp_dict)
            self.dictData.setdefault('nfs',listNFS)
            '''if dictDirData:
                for each_check_id in dictDirData:
                    temp_dict_dir = {}
                    #temp_dict = dict(dictFileData[each_check_id])
                    temp_dict_dir = dict(dictDirData[each_check_id])
                    del temp_dict_dir['c_type']
                    if (dictConfig and ('DIR' in dictConfig) and (str(each_check_id) in dictConfig['DIR'])):
                        temp_dict_dir['id'] = dictConfig['DIR'][str(each_check_id)]
                    else:
                        temp_dict_dir['id'] = "None"
                    listDirs.append(temp_dict_dir)
            self.dictData.setdefault('dir',listDirs)'''
            if dictSysLogData:
                for each_log in dictSysLogData:
                    temp_dict_syslog = {}
                    temp_dict_syslog = dictSysLogData[each_log]
                    listSysLogs.append(temp_dict_syslog)
            self.dictData.setdefault('logrule',listSysLogs)
            #CHECKS_DATA_DC['port'] = listPorts
            #CHECKS_DATA_DC['url'] = listURLs
            #CHECKS_DATA_DC['file'] = listFiles
            #CHECKS_DATA_DC['dir'] = listDirs
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while setting default resource values *********************************')
            traceback.print_exc()
    def addAdditionalMetrics(self,dictCollectedData):
        try:
            for each_key in dictCollectedData:
                if 'parseTag' in dictCollectedData[each_key]:
                    AgentLogger.debug(AgentLogger.COLLECTOR,'Found parseTag : ' + str(dictCollectedData[each_key]['parseTag']) + ' in key : ' + str(each_key))
                    parseTag = dictCollectedData[each_key]['parseTag']
                    parseTags = parseTag.split(',')
                    for each_tag in parseTags:
                        task = PARSE_IMPL[each_tag]
                        task(self.dictData, dictCollectedData[each_key], CONFIG_OBJECTS)
            return self.dictData
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while adding metrics in consolidated data *********************************')
            traceback.print_exc()
    
class DataHandler():
    def __init__(self):
        pass
    def createUploadData(self,dictCollectedData):
        dictData = {}
        try:
            collector = ConsolidatorCollector()
            dictData = collector.addAdditionalMetrics(dictCollectedData)
            if RcaHandler.RCA_DICT is not None and 'TOPPROCESSMEM' in RcaHandler.RCA_DICT and RcaHandler.RCA_DICT['TOPPROCESSMEM']:
                dictData['TOPMEMORYPROCESS']=RcaHandler.RCA_DICT['TOPPROCESSMEM']
            if RcaHandler.RCA_DICT is not None and 'TOPPROCESSCPU' in  RcaHandler.RCA_DICT and RcaHandler.RCA_DICT['TOPPROCESSCPU']:
                dictData['TOPCPUPROCESS']=RcaHandler.RCA_DICT['TOPPROCESSCPU']
        except Exception as e:
            AgentLogger.log([AgentLogger.COLLECTOR,AgentLogger.STDERR], '*************************** Exception while creating consolidated data *********************************')
            traceback.print_exc()
        finally:
            return dictData
