#$Id$
import json
import os
import time
import traceback
import threading
from urllib.parse import urlencode
import com
from com.manageengine.monagent import AgentConstants
#from com.manageengine.monagent.communication import CommunicationHandler
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentBuffer
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util import DesignUtils
from com.manageengine.monagent.util.AgentUtil import ZipUtil, FileUtil, FileZipAndUploadInfo, Executor

ScriptUtil = None

class Script():
    def __init__(self):
        self.iTime = None
        self.sID = None
        self.pth = None
        self.args = None
        self.type = None
        self.cmd = None
        self.timeout = 10
        self.neededFlag = None 
        self.origin = None

    def setScriptDetails(self,dictDetails):
        boolStatus = True
        
        self.type = dictDetails['TYPE']
        if self.type == 204:
            self.cmd = dictDetails['COMMAND']
        else:
            if '$$' in dictDetails['PATH']:
                file = dictDetails['PATH'].split('$$')[2]
                dictDetails['PATH'] = AgentConstants.AGENT_WORKING_DIR + file
            if not os.path.exists(dictDetails['PATH']):
                  if 'DFS_BLOCK_ID' in dictDetails and (dictDetails['DFS_BLOCK_ID'] is not None or dictDetails['DFS_BLOCK_ID']!='') and 'DFS_FILE_PATH' in dictDetails and (dictDetails['DFS_FILE_PATH'] is not None or dictDetails['DFS_FILE_PATH']!=''):
                      dict_task = {}
                      dict_task['DESTINATION'] = os.path.split(dictDetails['PATH'])[0]   
                      dict_task['FILE_NAME'] = 'temp.zip'      
                      if not os.path.exists(dict_task['DESTINATION']):        
                          os.makedirs(dict_task['DESTINATION'])                  
                      com.manageengine.monagent.actions.AgentAction.constructUrlAndDeploy(dictDetails['DFS_BLOCK_ID'],dictDetails['DFS_FILE_PATH'],dict_task)
            if os.path.exists(dictDetails['PATH']):
                self.pth = dictDetails['PATH']
                os.chmod(self.pth, 0o755)
                self.cmd = dictDetails['COMMAND'] + " " + self.pth
            else:
                boolStatus = False
        self.iTime = dictDetails['INIT_TIME']
        self.sID = dictDetails['SCRIPT_ID']
        if 'ARGS' in dictDetails:
            self.args = dictDetails['ARGS']
            if boolStatus:
                self.cmd = self.cmd + " " + self.args

        if 'TIMEOUT' in dictDetails:
            self.timeout = dictDetails['TIMEOUT']
        if 'SCRIPT_OUTPUT_NEEDED' in dictDetails:
            self.neededFlag = dictDetails['SCRIPT_OUTPUT_NEEDED']
        if 'ORIGIN' in dictDetails:
            self.origin = dictDetails['ORIGIN']
        return boolStatus
        
        '''Recieved WMS request to execute action script for : {'RESPONSE_NEEDED': 'YES', 'SCRIPT_ID': '4000000321013', 'TYPE': 200, 
        'PATH': '/opt/site24x7/monagent/customscripts/sample.sh', 'TIMEOUT': 30, 'REQUEST_TYPE': 'SCRIPT_RUN', 'INIT_TIME': 1436953880669,
        'AGENT_KEY': '288888983689495049', 'AGENT_REQUEST_ID': '1', 'COMMAND': 'sh', 'SCRIPT_OUTPUT_NEEDED': False}'''

    def getErrorResp(self):
        dictToReturn = {}
        dictToReturn['status'] = False
        dictToReturn['response'] = None
        dictToReturn['start_time'] = AgentUtil.getTimeInMillis()
        dictToReturn['duration'] = 0
        dictToReturn['Return Code'] = 404
        dictToReturn['Error'] = "File not found"
        if self.origin is not None:
            dictToReturn['origin'] = self.origin
        dictToReturn['script_id'] = self.sID
        dictToReturn['init_time'] = self.iTime
        return dictToReturn

    def executeScript(self):
        dictToReturn = {}
        try:
            executorObj = AgentUtil.Executor()
            executorObj.setLogger(AgentLogger.STDOUT)
            executorObj.setTimeout(self.timeout)
            executorObj.setCommand(self.cmd)
            startTime = AgentUtil.getTimeInMillis()
            executorObj.executeCommand()
            endTime = AgentUtil.getTimeInMillis()
            timeDiff = endTime - startTime
            tuple_commandStatus = executorObj.isSuccess()
            dictToReturn['status'] = tuple_commandStatus
            dictToReturn['response'] = AgentUtil.getModifiedString(executorObj.getStdOut(),100,100)
            dictToReturn['start_time'] = startTime
            dictToReturn['duration'] = timeDiff
            retVal = executorObj.getReturnCode()
            if ((retVal == 0) or (retVal is not None)):
                dictToReturn['Return Code'] = retVal
                errorString = executorObj.getStdErr()
                if errorString:
                    if len(errorString) > 200:
                        pass
                dictToReturn['Error'] =  AgentUtil.getModifiedString(executorObj.getStdErr(),100,100)
            else:
                dictToReturn['Return Code'] = 408
                dictToReturn['Error'] = 'Timeout error occured'
            if self.origin is not None:
                dictToReturn['origin'] = self.origin
            dictToReturn['script_id'] = self.sID
            dictToReturn['init_time'] = self.iTime
        except Exception as e:
            AgentLogger.log(AgentLogger.STDOUT,' Exception in executing script')
            traceback.print_exc()
        finally:
            return dictToReturn

class scriptHandler(threading.Thread):
    dict_wmsParams = None
    def __init__(self,dictParams=None):
        threading.Thread.__init__(self)
        if dictParams:
            self.dict_wmsParams = {}
            self.dict_wmsParams = dictParams
        #AgentLogger.log(AgentLogger.STDOUT,'=================== SCRIPT HANDLER THREAD STARTED ==================')
    
    def run(self):
        self.handleWMSRequest()
    
    def addScript(self,dict_wmsParams):
        toReturn = True
        script = None
        try:
            script = Script()
            boolStatus = script.setScriptDetails(dict_wmsParams)
            if boolStatus == False:
                toReturn = False
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR], ' *************************** Exception while setting action script details *************************** '+ repr(e))
            traceback.print_exc()
        finally:
            return script,toReturn

    def handleWMSRequest(self):
        ######
        AgentLogger.log(AgentLogger.STDOUT,'========= Recieved WMS request to execute action script for : ' + str(self.dict_wmsParams) +'========')
        sc,toExec = self.addScript(self.dict_wmsParams)
        if toExec:
            dictResponse = sc.executeScript()
        else:
            dictResponse = sc.getErrorResp()
        AgentLogger.log(AgentLogger.STDOUT,'========= Uploading action script execution response : ' + str(json.dumps(dictResponse)) +' ========')
        self.uploadResponse(dictResponse)
        
    def uploadResponse(self,dictData):
        dict_requestParameters = {}
        try:
            zipAndUploadInfo = FileZipAndUploadInfo()
            zipAndUploadInfo.filesToZip = None
            dict_requestParameters['agentKey'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'agent_key')
            dict_requestParameters['custID'] = AgentUtil.AGENT_CONFIG.get('AGENT_INFO', 'customer_id')
            dict_requestParameters['dc'] = AgentUtil.getCurrentTimeInMillis()
            dict_requestParameters['action'] = 'ACTION_SCRIPT_RESULT'
            dict_requestParameters['bno'] = AgentConstants.AGENT_VERSION
            zipAndUploadInfo.uploadRequestParameters = dict_requestParameters
            zipAndUploadInfo.uploadServlet = AgentConstants.SCRIPT_RESULT_SERVLET
            zipAndUploadInfo.uploadData = json.dumps(dictData)
            AgentBuffer.getBuffer(AgentConstants.FILES_TO_UPLOAD_BUFFER).add(zipAndUploadInfo)
            #AgentLogger.log(AgentLogger.CHECKS,'upload data instant '+repr(json.dumps(dictData)))
        except Exception as e:
            AgentLogger.log([AgentLogger.CHECKS,AgentLogger.STDERR], ' *************************** Exception while checking setting upload details for checks monitoring *************************** '+ repr(e))
            traceback.print_exc()