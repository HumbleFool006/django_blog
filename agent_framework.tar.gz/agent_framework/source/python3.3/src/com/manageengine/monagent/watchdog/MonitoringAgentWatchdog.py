# $Id$
import sys

import os
import logging
import logging.handlers
import time
import threading
try:
    import configparser
except Exception as e:
    import ConfigParser as configparser
import traceback
import subprocess, signal
from six.moves.urllib.parse import urlencode
from datetime import datetime
import json

from com.manageengine.monagent import AgentConstants
import fcntl
try:
    AgentConstants.WATCHDOG_APPLICATION_LOCK = open(AgentConstants.AGENT_WATCHDOG_LOCK_FILE, 'w')
    try:
        fcntl.lockf(AgentConstants.WATCHDOG_APPLICATION_LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError:
        print('Site24x7 monitoring agent watchdog is already running')
        sys.exit(1)
except Exception as e:
    print('Please login as root or use sudo to run Site24x7 monitoring agent watchdog')
    traceback.print_exc()
    sys.exit(1)

from com.manageengine.monagent import watchdog
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentArchiver
#from com.manageengine.monagent.communication import CommunicationHandler

#Watchdog Constants
MON_AGENT_WORKING_DIR = '/opt/site24x7/monagent'

MON_AGENT_BIN_DIR = MON_AGENT_WORKING_DIR + '/bin'
MON_AGENT_LOG_DIR = MON_AGENT_WORKING_DIR + '/logs'
MON_AGENT_DETAILS_LOG_DIR = MON_AGENT_LOG_DIR + '/details'
MON_AGENT_CONF_DIR = MON_AGENT_WORKING_DIR + '/conf'
MON_AGENT_UPGRADE_DIR = MON_AGENT_WORKING_DIR + '/upgrade'
MON_AGENT_TEMP_DIR = MON_AGENT_WORKING_DIR + '/temp'
MON_AGENT_UPGRADE_FLAG_FILE = MON_AGENT_UPGRADE_DIR + '/upgrade.txt'
MON_AGENT_UPGRADED_FLAG_FILE = MON_AGENT_TEMP_DIR + '/monagent_upgraded.txt'

MON_AGENT_WATCHDOG_CONF_FILE = MON_AGENT_CONF_DIR+'/monagentwatchdog.cfg'

MON_AGENT_WATCHDOG_SLEEP_INTERVAL = 300

MON_AGENT_STOP_RETRY_COUNT = 5

MON_AGENT_BOOT_FILE = MON_AGENT_BIN_DIR + '/monagent'
MON_AGENT_WATCHDOG_BOOT_FILE = MON_AGENT_BIN_DIR + '/monagentwatchdog'
MON_AGENT_UPGRADE_SCRIPT = MON_AGENT_BIN_DIR + '/upgrade.sh'

MON_AGENT_START = 'start'
MON_AGENT_STOP = 'stop'
MON_AGENT_STATUS = 'status'
MON_AGENT_RESTART = 'restart'

MON_AGENT_WATCHDOG_SERVICE_UP_MESSAGE='monitoring agent watchdog service is up'
MON_AGENT_WATCHDOG_SERVICE_DOWN_MESSAGE='monitoring agent watchdog service is down'
MON_AGENT_WATCHDOG_SERVICE_STARTED_MESSAGE='monitoring agent watchdog service started successfully'
MON_AGENT_WATCHDOG_SERVICE_STOPPED_MESSAGE='monitoring agent watchdog service stopped successfully'

MON_AGENT_SERVICE_UP_MESSAGE='monitoring agent service is up'
MON_AGENT_SERVICE_DOWN_MESSAGE='monitoring agent service is down'
MON_AGENT_SERVICE_STARTED_MESSAGE='monitoring agent service started successfully'
MON_AGENT_SERVICE_STOPPED_MESSAGE='monitoring agent service stopped successfully'

MON_AGENT_START_COMMAND = MON_AGENT_BOOT_FILE+' '+MON_AGENT_START
MON_AGENT_STOP_COMMAND = MON_AGENT_BOOT_FILE+' '+MON_AGENT_STOP
MON_AGENT_STATUS_COMMAND = MON_AGENT_BOOT_FILE+' '+MON_AGENT_STATUS
MON_AGENT_RESTART_COMMAND = MON_AGENT_BOOT_FILE+' '+MON_AGENT_RESTART
MON_AGENT_DETAILS_COMMAND = '"' + AgentConstants.AGENT_SCRIPTS_DIR + '/agentdetails.sh"'
MON_AGENT_WATCHDOG_DETAILS_COMMAND = '"' + AgentConstants.AGENT_SCRIPTS_DIR + '/agentwatchdogdetails.sh"'

DETAILS_COMMAND_LIST = []
DETAILS_COMMAND_LIST.append(MON_AGENT_DETAILS_COMMAND)
DETAILS_COMMAND_LIST.append(MON_AGENT_WATCHDOG_DETAILS_COMMAND)

TERMINATE_WATCHDOG = False
TERMINATE_WATCHDOG_NOTIFIER = threading.Event()

WatchdogConfig = None
#print('PATH : ',sys.path)

AGENT_CONFIG = configparser.RawConfigParser()

UPDATE_INTERVAL = 3600

RESTART_TIME = None

AGENT_MEMORY_THRESHOLD = 25

AGENT_CPU_THRESHOLD = 25

AGENT_THREAD_THRESHOLD = 50

AGENT_ZOMBIES_THRESHOLD = 200

AGENT_PID=None

def main():    
    try:
        initialize()
        watchdogServiceThread = WatchdogService()
        watchdogServiceThread.start()     
        while not TERMINATE_WATCHDOG:                      
            TERMINATE_WATCHDOG_NOTIFIER.wait(MON_AGENT_WATCHDOG_SLEEP_INTERVAL)                
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' *************************** Exception while starting watchdog service *************************** '+ repr(e))
        traceback.print_exc()

def initialize():
    global WatchdogConfig, MON_AGENT_WATCHDOG_SLEEP_INTERVAL,AGENT_CPU_THRESHOLD,AGENT_MEMORY_THRESHOLD,AGENT_THREAD_THRESHOLD,AGENT_ZOMBIES_THRESHOLD,UPDATE_INTERVAL
    AgentLogger.initialize(AgentConstants.WATCHDOG_LOGGING_CONF_FILE, AgentConstants.AGENT_LOG_DIR)
    AgentLogger.log(AgentLogger.STDOUT,'========================== STARTING MONITORING AGENT WATCHDOG ================================ \n\n')
    WatchdogConfig = configparser.RawConfigParser()
    WatchdogConfig.read(MON_AGENT_WATCHDOG_CONF_FILE)
    if not os.path.exists(MON_AGENT_LOG_DIR):
        os.makedirs(MON_AGENT_LOG_DIR)
    if not os.path.exists(MON_AGENT_DETAILS_LOG_DIR):
        os.makedirs(MON_AGENT_DETAILS_LOG_DIR)
    if WatchdogConfig.has_section('WATCHDOG_PARAMS'):
        MON_AGENT_WATCHDOG_SLEEP_INTERVAL = int(WatchdogConfig.get('WATCHDOG_PARAMS','WATCHDOG_INTERVAL'))
    AgentLogger.log(AgentLogger.STDOUT,'WATCHDOG CONSTANTS :')            
    list_sections = WatchdogConfig.sections()
    for sec in list_sections:
        for key, value in WatchdogConfig.items(sec):
            AgentLogger.log(AgentLogger.STDOUT,key+' : '+repr(value))
    if WatchdogConfig.has_section('AGENT_THRESHOLD'):
        AGENT_CPU_THRESHOLD = int(WatchdogConfig.get('AGENT_THRESHOLD','CPU'))
        AGENT_MEMORY_THRESHOLD = int(WatchdogConfig.get('AGENT_THRESHOLD','MEMORY'))
        AGENT_THREAD_THRESHOLD = int(WatchdogConfig.get('AGENT_THRESHOLD','THREADS'))
        AGENT_ZOMBIES_THRESHOLD = int(WatchdogConfig.get('AGENT_THRESHOLD','ZOMBIES'))     
        UPDATE_INTERVAL = int(WatchdogConfig.get('AGENT_THRESHOLD','UPDATE_INTERVAL'))
        
def TerminateWatchdogService():
    global TERMINATE_WATCHDOG
    if not TERMINATE_WATCHDOG:
        AgentLogger.log(AgentLogger.STDOUT,'TERMINATE WATCHDOG : ======================================== SHUTTING DOWN WATCHDOG SERVICE ========================================')
        TERMINATE_WATCHDOG = True
        TERMINATE_WATCHDOG_NOTIFIER.set()# checking interval in seconds

def executeCommand(str_command, int_timeout=14):    
    bool_isSuccess = False
    str_CommandOutput = None
    int_timeoutCounter = 0
    isTerminated = False
    def captureOutput(process):
        isSuccess = False
        out, err = process.communicate()
        if process.returncode is not None:
            AgentLogger.debug(AgentLogger.STDOUT,'Return code : '+str(process.returncode)+' Command \''+str(str_command)+'\' executed successfully')
            isSuccess = True
            output = out
        else:
            AgentLogger.log(AgentLogger.STDOUT,'Return code : '+str(process.returncode)+' Error while executing the command \''+str(str_command)+'\'')
            isSuccess = False
            output = err    
        return isSuccess, output
    list_commandArgs = [str_command]
    proc = subprocess.Popen(list_commandArgs, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    processId = proc.pid    
    try:
        while int_timeoutCounter <= int_timeout:      
            int_timeoutCounter +=.5                
            time.sleep(.5)
            AgentLogger.debug(AgentLogger.STDOUT,'Polling process, return code : '+str(proc.poll()))
            if proc.poll() is not None:
                bool_isSuccess, byte_CommandOutput = captureOutput(proc)
                str_CommandOutput = byte_CommandOutput.decode('UTF-8')
                isTerminated = True
                break
        if not isTerminated:
            AgentLogger.log(AgentLogger.STDOUT,'Process failed to terminate, Hence issuing \'kill\' command')   
            os.kill(processId, signal.SIGKILL)              
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,'***************************** Exception while executing command : '+str(str_command)+' *****************************')
        traceback.print_exc()        
    return bool_isSuccess, str_CommandOutput


class WatchdogService(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.name = 'WatchdogServiceThread'
    def run(self):                
        try:
            time.sleep(20)
            AGENT_CONFIG.read(AgentConstants.AGENT_CONF_FILE)
            while not TERMINATE_WATCHDOG:
                try:
                    handleUpgrade()
                    TERMINATE_WATCHDOG_NOTIFIER.wait(MON_AGENT_WATCHDOG_SLEEP_INTERVAL) # This wait is before monitorService() to avoid the race condition in starting agent service via /etc/init.d 
                    monitorService()     
                except Exception as e:
                    AgentLogger.log(AgentLogger.STDOUT,' *************************** Exception while running watchdog service thread *************************** '+ repr(e))
                    traceback.print_exc()                           
        except Exception as e:
            AgentLogger.log(AgentLogger.STDERR,' *************************** Exception while executing watchdog service thread *************************** '+ repr(e))
            traceback.print_exc()

def getAgentPid(str_output):
    global AGENT_PID
    try:
        str_output=str_output.strip()
        sub_String=":"
        indexString = "process id"
        indexValue = str_output.rindex(indexString)
        process = str_output[indexValue:len(str_output)].strip('()')
        process_id = process[process.index(sub_String) + len(sub_String):].strip()
        AGENT_PID = process_id
    except Exception as e:
        traceback.print_exc()
        AgentLogger.log(AgentLogger.STDOUT,'exception while getting agent process id ')
        isSuccess, pid_output = executeCommand(AgentConstants.AGENT_PID_COMMAND)
        AGENT_PID = pid_output.strip()
        AgentLogger.log(AgentLogger.STDOUT,'agent process id  via command --> '+repr(pid_output))
        
def monitorService():
    str_output = None
    try:
        AgentLogger.debug(AgentLogger.STDOUT,'MONITOR SERVICE : ======================================== MONITORING AGENT SERVICE ========================================')
        if os.path.exists(AgentConstants.AGENT_RESTART_FLAG_FILE):
            AgentLogger.log(AgentLogger.STDOUT,'Restarting Agent - Flag file : '+repr(AgentConstants.AGENT_RESTART_FLAG_FILE))
            isSuccess, str_output = executeCommand(MON_AGENT_RESTART_COMMAND)
            if MON_AGENT_SERVICE_STARTED_MESSAGE in str_output:
                AgentLogger.log(AgentLogger.STDOUT,'RESTART SERVICE : ======================= Agent service started successfully ==========================')
                AgentLogger.log(AgentLogger.STDOUT,'RESTART SERVICE : Deleting agent restart flag file : '+repr(AgentConstants.AGENT_RESTART_FLAG_FILE))
                os.remove(AgentConstants.AGENT_RESTART_FLAG_FILE)
            else:
                AgentLogger.log(AgentLogger.STDOUT,'RESTART SERVICE : *********************** Failed to restart monitoring agent service ***********************')
        else:
            isSuccess, str_output = executeCommand(MON_AGENT_STATUS_COMMAND)
            if MON_AGENT_SERVICE_DOWN_MESSAGE in str_output:
                AgentLogger.log(AgentLogger.STDOUT,'MONITOR SERVICE : Agent service is DOWN, Hence starting it!! ')    
                isSuccess, str_output = executeCommand(MON_AGENT_START_COMMAND)
                if MON_AGENT_SERVICE_UP_MESSAGE in str_output:
                    AgentLogger.log(AgentLogger.STDOUT,'MONITOR SERVICE : ======================= Agent service started successfully ==========================')                
            else:
                isSuccess, str_output = executeCommand(MON_AGENT_START_COMMAND)
                if MON_AGENT_SERVICE_UP_MESSAGE in str_output:
                    AgentLogger.log(AgentLogger.STDOUT,'MONITOR SERVICE : ======================= Agent service started successfully ==========================')
            AgentLogger.log(AgentLogger.STDOUT,'MONITOR SERVICE : Agent status message : '+repr(str_output))
        
        getAgentPid(str_output)
        checkZombieProcessCount()
        checkDetails()
    except Exception as e:
            AgentLogger.log(AgentLogger.STDERR,' *************************** Exception while monitoring agent service *************************** '+ repr(e))
            traceback.print_exc()

def parseProcDetails(strOutput):
    tempDict = {}
    try:
        listOutput = strOutput.split(" ")
        tempDict.setdefault('pcpu', listOutput[2])
        tempDict.setdefault('pmem', listOutput[3])
        tempDict.setdefault('threads', listOutput[4])
        tempDict.setdefault('pArgs', str(listOutput[7]).replace('\n',''))
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' *************************** Exception while parsing process output details *************************** '+ repr(e))
        traceback.print_exc()
    finally:
        return tempDict

def checkDetails():
    global AGENT_CPU_THRESHOLD,AGENT_MEMORY_THRESHOLD,AGENT_THREAD_THRESHOLD
    isSuccess=False
    try:
        for each_command in DETAILS_COMMAND_LIST:
            isSuccess, strOutput = executeCommand(each_command, 10)
            if isSuccess:
                dictProcessDetails = parseProcDetails(strOutput)
                if ( (float(dictProcessDetails['pcpu']) > AGENT_CPU_THRESHOLD) or (float(dictProcessDetails['pmem']) > AGENT_MEMORY_THRESHOLD) or (float(dictProcessDetails['threads']) > AGENT_THREAD_THRESHOLD)):
                    AgentLogger.log(AgentLogger.STDOUT,' output of '+each_command+'--> ' + strOutput)
                    AgentLogger.log(AgentLogger.STDOUT,'attribute threshold violation !!!!')
                    invokeRestart()
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' Exception while checking agent details by watchdog: ' + strOutput)
        traceback.print_exc()

def checkZombieProcessCount():
    global AGENT_ZOMBIES_THRESHOLD,AGENT_PID
    try:
        ZOMBIE_PROCESS_COUNT_COMMAND = 'ps -eo args,comm,command,pid,ppid | grep -v grep | grep -i "[sh] <defunct>" | grep '+AGENT_PID+' | wc -l'
        isSuccess, strOutput = executeCommand(ZOMBIE_PROCESS_COUNT_COMMAND, 10)
        AgentLogger.debug(AgentLogger.STDOUT,'zombie process count command run by agent watchdog ' + strOutput)
        if isSuccess:
            if strOutput:
                zCount = 0
                try:
                    zCount = int(strOutput)
                except Exception as e:
                    AgentLogger.log(AgentLogger.STDOUT,' Unknown string returned while fetching zombie process count by watchdog: ' + strOutput)
                    traceback.print_exc()
                if zCount > AGENT_ZOMBIES_THRESHOLD:
                    AgentLogger.log(AgentLogger.STDOUT,'zombie process count threshold violation !!!!  '+repr(zCount))
                    zombieDict = {'zombies': zCount}
                    invokeRestart()
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' Exception occured while fetching zombie process count by watchdog: ' + strOutput)
        traceback.print_exc()
                
def invokeRestart():                
    global RESTART_TIME
    if not RESTART_TIME==None: 
        current_time = time.time()
        if current_time - RESTART_TIME > UPDATE_INTERVAL:
            AgentLogger.log(AgentLogger.STDOUT,' current time ' + repr(current_time))
            AgentLogger.log(AgentLogger.STDOUT,' restart time ' + repr(RESTART_TIME))
            silentRestart()
            RESTART_TIME = time.time()
    else:
        RESTART_TIME = time.time()
        silentRestart()
        AgentLogger.log(AgentLogger.STDOUT,' initial restart time ' + repr(RESTART_TIME))
    
def silentRestart():
    try:
        AgentLogger.log(AgentLogger.STDOUT,'=======================================SILENTLY RESTARTING AGENT : CREATING WATCHDOG RESTART FLAG =======================================')
        str_uninstallTime = 'Restart : '+repr(datetime.fromtimestamp(time.time()).strftime("%Y-%m-%d %H:%M:%S"))
        file_obj = open(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE,'w')
        file_obj.write(str_uninstallTime)
        if not file_obj == None:
            file_obj.close()
        AgentLogger.log(AgentLogger.STDOUT,'Restarting Agent - Flag file : '+repr(AgentConstants.AGENT_WATCHDOG_SILENT_RESTART_FLAG_FILE))
        isSuccess, str_output = executeCommand(MON_AGENT_RESTART_COMMAND)
        if MON_AGENT_SERVICE_STARTED_MESSAGE in str_output:
            AgentLogger.log(AgentLogger.STDOUT,'RESTART SERVICE : ======================= Agent service started successfully ==========================')
        else:
            AgentLogger.log(AgentLogger.STDOUT,'RESTART SERVICE : *********************** Failed to restart monitoring agent service ***********************')
    except Exception as e:        
        AgentLogger.log(AgentLogger.STDERR,' ************************* Exception while creating silent watchdog restart flag file!!! ************************* '+ repr(e))
        traceback.print_exc()

def notifyServer(strType, dictOutput):
    AgentLogger.log(AgentLogger.STDOUT, 'NOTIFY SERVER : ' + str(strType) + ' and output ' + str(dictOutput))
    notifySuccess=False
    try:
        AgentLogger.log(AgentLogger.STDOUT,'=============================================UPDATING SERVER =============================================')
        str_url = None
        str_servlet = AgentConstants.AGENT_WATCHDOG_SERVLET
        dict_requestParameters = {
            'agentKey' : AGENT_CONFIG.get('AGENT_INFO', 'agent_key'),
            'serviceName' : AgentConstants.AGENT_NAME,
            'CUSTOMERID' :  AGENT_CONFIG.get('AGENT_INFO', 'customer_id'),
            'bno' : 1540,
            'reason':strType,
        }
        if not dict_requestParameters == None:
            str_requestParameters = urlencode(dict_requestParameters)
            str_url = str_servlet + str_requestParameters
        str_dataToSend = json.dumps(dictOutput)
        str_contentType = 'application/json'
        requestInfo = CommunicationHandler.RequestInfo()
        requestInfo.set_data(str_dataToSend)
        requestInfo.set_dataType(str_contentType)
        requestInfo.add_header("Content-Type", str_contentType)
        requestInfo.add_header("Accept", "text/plain")
        requestInfo.set_loggerName(AgentLogger.STDOUT)
        requestInfo.set_method(AgentConstants.HTTP_POST)
        requestInfo.set_url(str_url)
        requestInfo.set_timeout(10)
        bool_toReturn, int_errorCode, dict_responseHeaders, dict_responseData = CommunicationHandler.sendRequest(requestInfo)
        if bool_toReturn==True and int_errorCode==0:
            notifySuccess=True
    except Exception as e:
        traceback.print_exc()
        notifySuccess=False
    return notifySuccess

def handleUpgrade():
    try:        
        monAgentUpgrader = MonAgentUpgrader()
        monAgentUpgrader.setLogger(AgentLogger)   
        monAgentUpgrader.upgrade()
        if monAgentUpgrader.isUpgradeSuccess():
            os.remove(MON_AGENT_UPGRADE_FLAG_FILE)            
        else:
            if os.path.exists(MON_AGENT_UPGRADE_FLAG_FILE):
                AgentLogger.log(AgentLogger.STDOUT,'*************************** Failed to upgrade monitoring agent service ***************************')
    except Exception as e:
        AgentLogger.log(AgentLogger.STDERR,' *************************** Exception while handling upgrade *************************** '+ repr(e))
        traceback.print_exc()
    finally:
        dict_upgradeProps = None
        monAgentUpgrader = None

class FileObject:
    def __init__(self):
        self.str_fileName = None
        self.str_filePath = None
        self.data = None
        self.str_dataType = None
        self.str_dataEncoding = None
        self.str_mode = 'w'
        self.str_loggerName = None
        self.bool_changePermission = False
        self.bool_logging = True
        self.bool_forceSave = False
    def set_fileName(self, str_fileName):
        self.str_fileName = str_fileName
    def get_fileName(self):
        return self.str_fileName
    def set_filePath(self, str_filePath):
        self.str_filePath = str_filePath
    def get_filePath(self):
        return self.str_filePath
    def set_data(self, data):
        self.data = data
    def get_data(self):
        return self.data
    def set_dataType(self, str_dataType):
        self.str_dataType = str_dataType
    def get_dataType(self):
        return self.str_dataType
    def set_dataEncoding(self, str_dataEncoding):
        self.str_dataEncoding = str_dataEncoding
    def get_dataEncoding(self):
        return self.str_dataEncoding
    def set_mode(self, str_mode):
        self.str_mode = str_mode
    def get_mode(self):
        return self.str_mode
    def set_logging(self, bool_logging):
        self.bool_logging = bool_logging
    def get_logging(self):
        return self.bool_logging
    def set_loggerName(self, str_loggerName):
        self.str_loggerName = str_loggerName
    def get_loggerName(self):
        return self.str_loggerName
    def set_changePermission(self, bool_changePermission):
        self.bool_changePermission = bool_changePermission
    def get_changePermission(self):
        return self.bool_changePermission
    def set_forceSave(self, bool_value):
        self.bool_forceSave = bool_value
    def get_forceSave(self):
        return self.bool_forceSave
    
class Upgrader(object):
    def __init__(self):
        self.bool_isSuccess = False
        self.bool_inProgress = False
        self.str_upgradeFile = None
        self.logger = None
        self.dict_upgradeProps = None
    def setIsUpgradeSuccess(self, bool_isSuccess):
        self.bool_isSuccess = bool_isSuccess
    def isUpgradeSuccess(self):
        return self.bool_isSuccess
    def initiateUpgrade(self):
        return self.bool_initiateUpgrade
    def setUpgradeFile(self, str_upgradeFile):
        self.str_upgradeFile = str_upgradeFile
    def getUpgradeFile(self):
        return self.str_upgradeFile
    def setUpgradeProps(self, dict_upgradeProps):
        self.dict_upgradeProps = dict_upgradeProps
    def getUpgradeProps(self):
        return self.dict_upgradeProps
    def setLogger(self, logger):
        self.logger = logger
    def getLogger(self):
        return self.logger
    def log(self, str_message):
        if self.logger:
            self.logger.log(self.logger.STDOUT, str_message)
    def setIsUpgradeInProgress(self, bool_inProgress):
        self.bool_inProgress = bool_inProgress
    def isUpgradeInProgress(self):
        return self.bool_inProgress
    def upgrade(self):
        raise NotImplementedError
    def preUpgrade(self):
        raise NotImplementedError
    def postUpgrade(self):
        raise NotImplementedError
    def upgradeAction(self):
        raise NotImplementedError

class MonAgentUpgrader(Upgrader):
    def __init__(self):
        super(MonAgentUpgrader, self).__init__()
    # Check if upgrade_flag_file exists and read it to fetch upgrade file name.
    def initiateUpgrade(self):
        bool_isSuccess = True
        file_obj = None
        str_upgradeFileName = None
        str_upgradeFilePath = None
        try:
            if os.path.exists(MON_AGENT_UPGRADE_FLAG_FILE):
                file_obj = open(MON_AGENT_UPGRADE_FLAG_FILE, 'rU')                
                str_upgradeFileName = file_obj.read()
                self.log('INITIATE UPGRADE : Upgrade file name fetched from upgrade_flag_file : '+str(str_upgradeFileName))
                if str_upgradeFileName:
                    str_upgradeFilePath = MON_AGENT_UPGRADE_DIR+'/'+str_upgradeFileName
                    self.setUpgradeFile(str_upgradeFilePath)
                    self.setIsUpgradeInProgress(True)
                    self.log('UPGRADE : =========================== UPGRADE INITIATED ============================')
                else:
                    self.setIsUpgradeInProgress(False)
                    self.setIsUpgradeSuccess(False)
                    bool_isSuccess = False
                    self.log('INITIATE UPGRADE : Cannot initiate upgrade since upgrade file name is : '+str(str_upgradeFileName))
            else:
                self.setIsUpgradeInProgress(False)
                self.setIsUpgradeSuccess(False)
                bool_isSuccess = False
                self.log('INITIATE UPGRADE : Cannot initiate upgrade since upgrade flag file : '+str(MON_AGENT_UPGRADE_FLAG_FILE)+' does not exist')
        except Exception as e:
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)
            bool_isSuccess = False
            self.log('INITIATE UPGRADE : *********************** Exception while trying to initiate upgrade *****************************')
            traceback.print_exc()
        finally:
            if not file_obj == None:
                file_obj.close()
        return bool_isSuccess
    # Stop monitoring agent service
    def preUpgrade(self):
        global MON_AGENT_STOP_RETRY_COUNT
        bool_isSuccess = True
        int_monAgentStopTryCount = 0
        try:     
            while int_monAgentStopTryCount < MON_AGENT_STOP_RETRY_COUNT:  
                int_monAgentStopTryCount+=1  
                isSuccess, str_output = executeCommand(MON_AGENT_STATUS_COMMAND)
                self.log('PRE UPGRADE : Monitoring agent status : '+str(str_output))
                if MON_AGENT_SERVICE_UP_MESSAGE in str_output:
                    isSuccess, str_output = executeCommand(MON_AGENT_STOP_COMMAND)
                    if isSuccess and MON_AGENT_SERVICE_STOPPED_MESSAGE in str_output:
                        self.log('PRE UPGRADE : Monitoring agent service stopped successfully for upgrade')
                        break
                    else:
                        time.sleep(5)                        
                        self.log('PRE UPGRADE : ***************************** Monitoring agent service is up. Will retry to stop it after 5 seconds to start upgrade *****************************')
            isSuccess, str_output = executeCommand(MON_AGENT_STATUS_COMMAND)
            self.log('PRE UPGRADE : Monitoring agent status : '+str(str_output))
            if MON_AGENT_SERVICE_DOWN_MESSAGE in str_output:
                self.log('PRE UPGRADE : Monitoring agent service is down. Proceed with upgrade')                
            else:
                self.setIsUpgradeInProgress(False)
                self.setIsUpgradeSuccess(False)
                bool_isSuccess = False
                self.log('PRE UPGRADE : *********************** Error while stopping monitoring agent service for upgrade *****************************')
        except Exception as e:
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)
            bool_isSuccess = False
            self.log('PRE UPGRADE : *********************** Exception while trying to stop monitoring agent service for upgrade *****************************')
            traceback.print_exc() 
        return bool_isSuccess
    # Extract Agent upgrade file
    def upgradeAction(self):
        bool_isSuccess = True
        try:
            self.log('UPGRADE : Extracting upgrade tar file : '+repr(self.getUpgradeFile()))  
            tarHandle = AgentArchiver.getArchiver(AgentArchiver.TAR)
            tarHandle.setFile(self.getUpgradeFile())
            tarHandle.setPath(MON_AGENT_WORKING_DIR)
            tarHandle.setMode('r:gz')
            tarHandle.decompress()
            tarHandle.close()
            self.log('UPGRADE : Tar Extraction Successful')
        except Exception as e:
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)
            bool_isSuccess = False
            self.log('UPGRADE : *********************** Exception while extracting Tar file *****************************')
            traceback.print_exc() 
        return bool_isSuccess
    # Start monitoring agent service
    def postUpgrade(self):
        bool_isSuccess = True
        try:  
            def createMonAgentUpgradedFlagFile():
                bool_toReturn = True
                file_obj = None
                try:
                    file_obj = open(AgentConstants.MON_AGENT_UPGRADED_FLAG_FILE,'w')
                    file_obj.write('')                  
                except:
                    self.log('POST UPGRADE : ************************* Exception while creating MonAgent Upgraded Flag File : '+AgentConstants.MON_AGENT_UPGRADED_FLAG_FILE+' ************************* ')
                    traceback.print_exc()
                    bool_toReturn = False
                finally:        
                    if not file_obj == None:
                        file_obj.close()
                return bool_toReturn
            createMonAgentUpgradedFlagFile()
            os.chmod(MON_AGENT_UPGRADE_SCRIPT, 0o755)
            isSuccess, str_output = executeCommand(MON_AGENT_UPGRADE_SCRIPT)
            self.log('POST UPGRADE : Upgrade script output : '+repr(str_output))
            isSuccess, str_output = executeCommand(MON_AGENT_START_COMMAND)
            if isSuccess and MON_AGENT_SERVICE_STARTED_MESSAGE in str_output:
                self.log('POST UPGRADE : Monitoring agent service started successfully after upgrade')
                self.setIsUpgradeInProgress(False)
                self.setIsUpgradeSuccess(True)
                self.log('POST UPGRADE : ======================= MONITORING AGENT UPGRADE SUCCESSFUL ==========================')                
            else:
                self.setIsUpgradeInProgress(False)
                self.setIsUpgradeSuccess(False)
                bool_isSuccess = False
                self.log('POST UPGRADE : *************************** Failed to start monitoring agent service after upgrade ***************************')            
        except Exception as e:
            self.setIsUpgradeInProgress(False)
            self.setIsUpgradeSuccess(False)
            bool_isSuccess = False
            self.log('POST UPGRADE : *********************** Exception while starting monitoring agent service after upgrade *****************************')
            traceback.print_exc() 
        return bool_isSuccess
    def upgrade(self):
        if self.initiateUpgrade():
            if self.preUpgrade():
                if self.upgradeAction():
                    return self.postUpgrade()


main()
