import json
import os
import time
import traceback
import threading
import platform
from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.util import AgentUtil
from com.manageengine.monagent.util.AgentUtil import FileUtil
import com
#from com.manageengine.monagent.plugins.PluginMonitoring import PluginHandler


thread_Lock=threading.Lock()
update_File_Lock=threading.Lock()
PLUGIN_CONF_DICT={}

def executeScript(cmd):
        dictToReturn = {}
        result = True
        try:
            executorObj = AgentUtil.Executor()
            executorObj.setLogger(AgentLogger.PLUGINS)
            executorObj.setTimeout(30)
            if cmd is not None:
                AgentLogger.log(AgentLogger.PLUGINS, 'Script Command ======>' + repr(cmd))
                executorObj.setCommand(cmd)
                executorObj.executeCommand()
                dictToReturn['result'] = executorObj.isSuccess()
                retVal = executorObj.getReturnCode()
                #AgentLogger.log(AgentLogger.PLUGINS, 'Return Value ======>' + repr(retVal))
                if retVal is not None:
                    dictToReturn['status'] = retVal
                dictToReturn['output'] = executorObj.getStdOut().rstrip('\n')
                dictToReturn['error'] = AgentUtil.getModifiedString(executorObj.getStdErr(), 100, 100)
            else:
                #AgentLogger.log(AgentLogger.PLUGINS, 'Command is NULL for the Plugin ==== {0}'.format(self.name))
                result = False
        except Exception as e:
            AgentLogger.log([AgentLogger.PLUGINS, AgentLogger.STDERR], '********* Exception While Executing the Script*********' + repr(e))
            traceback.print_exc()
        finally:
            return dictToReturn, result


def getPluginsConfFileObj(): 
    fileObj = AgentUtil.FileObject()
    fileObj.set_filePath(AgentConstants.AGENT_PLUGINS_CONF_FILE)
    fileObj.set_dataType('json')
    fileObj.set_mode('rb')
    fileObj.set_dataEncoding('UTF-8')
    fileObj.set_loggerName(AgentLogger.PLUGINS)
    fileObj.set_logging(False)
    return fileObj

def getPluginsIdFileObj():
    fileObj = AgentUtil.FileObject()
    fileObj.set_filePath(AgentConstants.AGENT_PLUGINS_SITE24X7ID)
    fileObj.set_dataType('json')
    fileObj.set_mode('rb')
    fileObj.set_dataEncoding('UTF-8')
    fileObj.set_loggerName(AgentLogger.PLUGINS)
    fileObj.set_logging(False)
    return fileObj

def getPluginsListFileObj(): 
    fileObj = AgentUtil.FileObject()
    fileObj.set_filePath(AgentConstants.AGENT_PLUGINS_LISTS_FILE)
    fileObj.set_dataType('json')
    fileObj.set_mode('rb')
    fileObj.set_dataEncoding('UTF-8')
    fileObj.set_loggerName(AgentLogger.PLUGINS)
    fileObj.set_logging(False)
    return fileObj

def updatePluginJson(dict_Site24X7Id):
    ''' Function will update plugin id in the pluginid file '''
    try:
        thread_Lock.acquire()
        global PLUGIN_CONF_DICT
        str_pluginName = None
        responseDict=json.loads(dict_Site24X7Id)
        for key,value in responseDict.items():
            str_pluginName = key
            if key in PLUGIN_CONF_DICT:
                oldDict={}
                oldDict = PLUGIN_CONF_DICT.pop(key)
                oldDict.update(value)
        PLUGIN_CONF_DICT.setdefault(str_pluginName,{})
        PLUGIN_CONF_DICT[str_pluginName]=oldDict
        if not os.path.exists(AgentConstants.AGENT_PLUGINS_SITE24X7ID):
            AgentUtil.FileUtil.createFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID,AgentLogger.PLUGINS)
        bool_FileLoaded, tempDict = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID)
        if tempDict==None:
            tempDict={}
        if tempDict and str_pluginName in tempDict:
            existingDict={}
            existingDict = tempDict.pop(key)
            existingDict.update(value)
            tempDict.setdefault(str_pluginName,{})
            if 'error_msg' in existingDict and 'status' in existingDict and existingDict['status']==0:
                existingDict.pop('error_msg')
            tempDict[str_pluginName]=existingDict
        else:
            tempDict.setdefault(str_pluginName,{})
            tempDict[str_pluginName]=oldDict
    #    AgentLogger.log(AgentLogger.PLUGINS,'final dict -- {0}'.format(tempDict))
        bool_FileSaved = AgentUtil.writeDataToFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID, tempDict)
        if(not bool_FileSaved):
            AgentLogger.log(AgentLogger.PLUGINS, "PLUGINS ID" + "Unable to update id file")
    except Exception as e:
        traceback.print_exc()
    finally:
        thread_Lock.release()

def updateDictToFile(d1):
    update_File_Lock.acquire()
    try:
        bool_FileLoaded, tempDict = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID)
        #AgentLogger.log(AgentLogger.COLLECTOR, "temp dict -- {0}".format(tempDict))
        for key,value in d1.items():
            tempDict.pop(key)
        d1.update(tempDict)
        bool_FileSaved = AgentUtil.writeDataToFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID, d1)
        if(not bool_FileSaved):
            AgentLogger.log(AgentLogger.PLUGINS, "PLUGINS ID" + "Unable to update id file")
    except Exception as e:
        traceback.print_exc()
    finally:
        update_File_Lock.release()
    
def updatePluginConfigDict():
    try:
        if os.path.exists(AgentConstants.AGENT_PLUGINS_SITE24X7ID):
            fileObj = AgentUtil.FileObject()
            fileObj.set_filePath(AgentConstants.AGENT_PLUGINS_SITE24X7ID)
            fileObj.set_dataType('json')
            fileObj.set_mode('rb')
            fileObj.set_dataEncoding('UTF-8')
            fileObj.set_loggerName(AgentLogger.PLUGINS)
            fileObj.set_logging(False)
            global PLUGIN_CONF_DICT
            bool_FileLoaded, PLUGIN_CONF_DICT = FileUtil.readData(fileObj)
            AgentLogger.log(AgentLogger.PLUGINS, "UPDATED PLUGIN_CONF_DICT ===> {0}".format(PLUGIN_CONF_DICT))
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "Exception Occured while updating plugin conf dictionary")
        AgentLogger.log(AgentLogger.PLUGINS, "UPDATED PLUGIN_CONF_DICT ===> {0}".format(PLUGIN_CONF_DICT))

def getPluginConfDict():
    global PLUGIN_CONF_DICT
    return PLUGIN_CONF_DICT

def rediscoverPlugins(dict_task):
    rediscoverDeletedPlugins(dict_task)
    com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.reRegisterAllPlugins(dict_task)

def rediscoverDeletedPlugins(dict_task):
    try:
        AgentLogger.log(AgentLogger.PLUGINS, "removing plugin delete entry")
        fileObj = getPluginsIdFileObj()
        bool_toReturn, dict_monitorsInfo = FileUtil.readData(fileObj)
        pname = dict_task['PLUGIN_NAME'] if 'PLUGIN_NAME' in dict_task else None
        if not pname==None:
            if pname in dict_monitorsInfo:
                if dict_monitorsInfo[pname]['status'] in [3,2]:
                    dict_monitorsInfo.pop(pname)
            else:
                AgentLogger.log(AgentLogger.PLUGINS, "plugin not present in delete list")
        else:
            for key in dict_monitorsInfo:
                idValue = dict_monitorsInfo[key]
                if idValue['status'] in [3,2]:
                    dict_monitorsInfo.pop(key)
        AgentUtil.writeDataToFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID,dict_monitorsInfo)
        updatePluginConfigDict()
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "-- Unable to re discover deleted plugins --")
        traceback.print_exc()

def updatePluginStatus(str_plugName,status):
    ''' Function will update plugin id in the pluginid file '''
    AgentLogger.log(AgentLogger.PLUGINS, "--- Plugin Coniguration Update ---")
    bool_FileSaved = False
    bool_FileLoaded, tempDict = AgentUtil.loadDataFromFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID)
    if bool_FileLoaded:
        if tempDict and str_plugName in tempDict:
            tempDict[str_plugName]['status']=status
            bool_FileSaved = AgentUtil.writeDataToFile(AgentConstants.AGENT_PLUGINS_SITE24X7ID, tempDict)
        else:
            AgentLogger.log(AgentLogger.PLUGINS, "Plugin entry is not available ")
    else:
        AgentLogger.log(AgentLogger.PLUGINS,'Plugin id mapper file not found')
    if(not bool_FileSaved):
        AgentLogger.log(AgentLogger.PLUGINS, "Unable to update status in id mapper file")
    return bool_FileSaved

def getNagiosPluginName(pluginCommand):
    pluginName = pluginCommand.split(" ")
    name = pluginName[0]
    return name.split("/")[-1]

def getDefaultPluginName(pluginCommand):
    return pluginCommand.split("/")[-1]

def fetchPluginName(pluginCommand,pluginType):
    if pluginType=='nagios':
        return getNagiosPluginName(pluginCommand)
    else:
        return getDefaultPluginName(pluginCommand)
    

def fetchExecutablePlugins():
    pluginFiles=[]
    SUCCESS_LIST=[]
    inv_dict={}
    for dirname, dirnames, filenames in os.walk(AgentConstants.AGENT_PLUGINS_DIR):
        dir_name=''
        if dirname and filenames==[]:
                dir_name = dirname.split('/')[-1].lower()
                inv_dict[dir_name]={}
                inv_dict[dir_name]['error_msg']='no plugin found in the directory'
                inv_dict[dir_name]['status'] = 2
        for file in filenames:
            if dirname.split('/')[-1].lower()==os.path.splitext(file)[0].lower():
                if not file.startswith('.') and not file == AgentConstants.AGENT_PLUGINS_NAGIOS_FILE and not file.endswith('~') and not file.endswith('.swp') and not file.endswith('.swo'):
                    pluginFiles.append(os.path.join(dirname, file))
                    SUCCESS_LIST.append(os.path.splitext(file)[0].lower())
                try:
                    fileName=os.path.join(dirname, file)
                    os.chmod(fileName,0o755)
                except Exception as e:
                    AgentLogger.log(AgentLogger.PLUGINS, "Exception while changing file permission ====>"+repr(fileName))
            elif dirname == AgentConstants.AGENT_PLUGINS_DIR and os.path.splitext(file)[1] in ['.py','.sh']:
                    inv_dict[file]={}
                    inv_dict[file]['error_msg']='plugin file is not in a separate folder'
                    inv_dict[file]['status'] = 2
            else:
                if dirname==AgentConstants.AGENT_PLUGINS_DIR:
                    continue
                dir_name = dirname.split('/')[-1].lower()
                inv_dict[dir_name]={}
                inv_dict[dir_name]['error_msg']="plugin file name is not matched with directory name"
                inv_dict[dir_name]['status'] = 2

    DELETE_LIST=[]
    for key in inv_dict.keys():
        if key in SUCCESS_LIST:
            DELETE_LIST.append(key)
    for each in DELETE_LIST:
        inv_dict.pop(each)
    AgentConstants.PLUGIN_FOLDER_DICT=inv_dict
    com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.updateInventoryToServer()
#     for dirname, dirnames, filenames in os.walk(AgentConstants.AGENT_PLUGINS_DIR):
#         for file in filenames:
#             if dirname.split('/')[-1]==os.path.splitext(file)[0] or dirname.split('/')[-1]==os.path.splitext(file)[0].lower():
#                 if not file.startswith('.') and not file == AgentConstants.AGENT_PLUGINS_NAGIOS_FILE and not file.endswith('~') and not file.endswith('.swp') and not file.endswith('.swo'):
#                     pluginFiles.append(os.path.join(dirname, file))
#                     try:
#                         fileName=os.path.join(dirname, file)
#                         os.chmod(fileName,0o755)
#                     except Exception as e:
#                         AgentLogger.log(AgentLogger.PLUGINS, "Exception while changing mod to file ====>"+repr(fileName))
#             else:
#                 AgentLogger.log(AgentLogger.PLUGINS, "File Not Added to List === {0}".format(file))
    AgentLogger.log(AgentLogger.PLUGINS,'Executable Plugins List -- {0}'.format(pluginFiles))
    return pluginFiles

def reloadPlugins():
    PluginMonitoring.pluginUtil.loadPlugins()
    PluginMonitoring.pluginUtil.doPluginDC()
    
#check for service status
def levelOneCheck(pluginName):
    bool_isSuccess = False
    service_check = AgentConstants.AGENT_SERVICE_CMD+pluginName+' '+'status'
    AgentLogger.log(AgentLogger.PLUGINS,'Service Command =====> {0}'.format(service_check))
    dictReturn,result = executeScript(service_check)
    AgentLogger.log(AgentLogger.PLUGINS,'Result Obtained =====> {0}'.format(dictReturn))
    AgentLogger.log(AgentLogger.PLUGINS,'Not Found =====>{0}'.format('not found' in dictReturn['error']))
    AgentLogger.log(AgentLogger.PLUGINS,'Status =====>{0}'.format(dictReturn['status']))
    if not dictReturn['output'] and 'not found' in dictReturn['error'] and dictReturn['status']!=0:
        AgentLogger.log(AgentLogger.PLUGINS,'==== Service Not installed for {} ===='.format(pluginName))
    else:
        bool_isSuccess = True
    return bool_isSuccess

#check for data directory exists for a plugin
def levelTwoCheck(pluginName):
    bool_isSuccess = False
    AgentLogger.log(AgentLogger.PLUGINS,'L2 Data Dir Check =====> {0}'.format(AgentConstants.AGENT_VAR_LIB_DIR+pluginName))
    if os.path.exists(AgentConstants.AGENT_VAR_LIB_DIR+pluginName):
        bool_isSuccess=True
    else:
        AgentLogger.log(AgentLogger.PLUGINS,'L2 Data Dir Check Failed For =====> {0}'.format(AgentConstants.AGENT_VAR_LIB_DIR+pluginName))
    return bool_isSuccess


#check for port status
def levelThreeCheck(pluginName):
    bool_isSuccess = False
    fileObj = getPluginsConfFileObj()
    bool_toReturn, dict_monitorsInfo = FileUtil.readData(fileObj)
    plugin_Ports = dict_monitorsInfo['Ports']
    port_Check = AgentConstants.AGENT_PORT_CHECK_CMD+' '+plugin_Ports[pluginName]
    AgentLogger.log(AgentLogger.PLUGINS,'L3 Port Check =====> {0}'.format(port_Check))
    dictReturn,result = executeScript(port_Check)
    AgentLogger.log(AgentLogger.PLUGINS,'L3 Result Obtained =====> {0}'.format(dictReturn))
    AgentLogger.log(AgentLogger.PLUGINS,'L3 Not Found =====>{0}'.format('not found' in dictReturn['error']))
    AgentLogger.log(AgentLogger.PLUGINS,'L3 Status =====>{0}'.format(dictReturn['status']))
    if dictReturn['output']:
        bool_isSuccess = True
    else:
        AgentLogger.log(AgentLogger.PLUGINS,'==== Port Check failed for {} ===='.format(pluginName))
    return bool_isSuccess

def removePluginConfig(pluginName):
    global PLUGIN_CONF_DICT
    AgentLogger.log(AgentLogger.PLUGINS,'==== Removing Plugin Config ===='+repr(pluginName))
    if pluginName in PLUGIN_CONF_DICT:
        PLUGIN_CONF_DICT.pop(pluginName)
    AgentLogger.log(AgentLogger.PLUGINS,'==== Plugin Config after removal ===='+repr(PLUGIN_CONF_DICT))

#create an ignore txt file which will decide plugin to execute or not
def createignoreFile(errorDict):
    try:
        if not errorDict==None:
            AgentLogger.log(AgentLogger.PLUGINS,'==== Ignore File Creation for Plugin  ===={0}'.format(errorDict))
            pluginName = errorDict['plugin_name']
            error_msg = errorDict['error_msg']
            file_name=AgentConstants.AGENT_PLUGINS_DIR+pluginName+'_error.txt'
            AgentUtil.FileUtil.createFile(file_name,AgentLogger.PLUGINS)
            towrite=getIgnoreFileContent(error_msg)
            with open(file_name, "w") as text_file:
                text_file.write(towrite)
        else:
            AgentLogger.log(AgentLogger.PLUGINS,'==== Error Dictionary is Empty Not Proceeding ====')
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS,'==== Exception while creating ignore file ====')
        traceback.print_exc()
        
def getIgnoreFileContent(error):
    fileContent="Plugin Registration Failed \n"
    fileContent+='\nError Obtained - '+error+'\n'
    fileContent+='\nKindly fix the above error \n'
    fileContent+='\nOnce Fixed Remove this file to mark the plugin for monitoring \n'
    return fileContent

def processSAM(dict_task):
    str_requestType = 5
    str_mtype = dict_task['mtype']
    if str_mtype == 'PLUGIN':
        bool_updateStatus = updatePluginStatus(dict_task['configuration']['plugin_name'],str_requestType)
        if bool_updateStatus:
            updatePluginConfigDict()
            AgentConstants.UPDATE_PLUGIN_INVENTORY=True
            #com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.updateInventoryToServer()
    elif str_mtype =='DOCKER':
        com.manageengine.monagent.docker.DockerAgent.suspendMonitoring()
    else:
        AgentLogger.log(AgentLogger.PLUGINS,' monitor type not supported for this action ---> '+repr(dict_task))
    

def processAAM(dict_task):
    str_requestType = 0
    str_mtype = dict_task['mtype']
    if str_mtype == 'PLUGIN':
        bool_updateStatus = updatePluginStatus(dict_task['configuration']['plugin_name'],str_requestType)
        if bool_updateStatus:
            updatePluginConfigDict()
            AgentConstants.UPDATE_PLUGIN_INVENTORY=True
            #com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.updateInventoryToServer() 
    elif str_mtype =='DOCKER':
        com.manageengine.monagent.docker.DockerAgent.activateDocker()
    else:
        AgentLogger.log(AgentLogger.PLUGINS,' monitor type not supported for this action ---> '+repr(dict_task))

    
def processDAM(dict_task):
    AgentLogger.log(AgentLogger.PLUGINS,' in DAM --- '+repr(dict_task))
    str_requestType = 3
    str_mtype = dict_task['mtype']
    if str_mtype == 'PLUGIN':
        bool_updateStatus = updatePluginStatus(dict_task['configuration']['plugin_name'],str_requestType)
        if bool_updateStatus:
            updatePluginConfigDict()
            AgentConstants.UPDATE_PLUGIN_INVENTORY=True
            #com.manageengine.monagent.plugins.PluginMonitoring.pluginUtil.updateInventoryToServer()
    elif str_mtype =='DOCKER':
        com.manageengine.monagent.docker.DockerAgent.deleteMonitoring()
    else:
        AgentLogger.log(AgentLogger.PLUGINS,' monitor type not supported for this action ---> '+repr(dict_task))
       
def deployPlugin(dict_task):
    """This method is to place a plugin under plugins directory from temp directory."""
    AgentLogger.log(AgentLogger.PLUGINS,' Deploying Plugin ---> '+repr(dict_task))
    str_pluginName = dict_task['name']
    str_pluginName=str_pluginName.lower()
    try:
        if str_pluginName not in PLUGIN_CONF_DICT:
            from_dir = AgentConstants.AGENT_PLUGINS_TMP_DIR+str_pluginName
            to_dir = AgentConstants.AGENT_PLUGINS_DIR+str_pluginName
            shutil.copytree(from_dir,to_dir)
        else:
            AgentLogger.log(AgentLogger.PLUGINS, "-- Plugin already deployed -- {0}".format(PLUGIN_CONF_DICT[str_pluginName]))
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "-- Unable to deploy plugin --")
        traceback.print_exc()    

def disablePlugins(dict_task):
    """ This method is to disable plugins """
    AgentLogger.log(AgentLogger.PLUGINS,' Disabling Plugins ---> '+repr(dict_task))
    str_section=AgentConstants.PLUGINS_SECTION
    str_option=AgentConstants.PLUGINS_ENABLED_KEY
    try:
        if AgentUtil.AGENT_CONFIG.has_section(str_section) and AgentUtil.AGENT_CONFIG.has_option(str_section,str_option):
            if AgentUtil.AGENT_CONFIG.get(str_section, str_option)=='1':
                AgentUtil.AGENT_CONFIG.set(str_section, str_option,'0')
                confFile = open(AgentConstants.AGENT_CONF_FILE,"w") 
                AgentUtil.AGENT_CONFIG.write(confFile)   
            else:
                AgentLogger.log(AgentLogger.PLUGINS,' Plugins Already Disabled ---> {0}'.format(AgentUtil.AGENT_CONFIG.get(str_section, str_option)))
        else:
            AgentUtil.AGENT_CONFIG.add_section(str_section)
            AgentUtil.AGENT_CONFIG.set(str_section,str_option,'0')
            confFile = open(AgentConstants.AGENT_CONF_FILE,"w") 
            AgentUtil.AGENT_CONFIG.write(confFile)   
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "-- Exception while disabling plugin --")
        traceback.print_exc()
        
def enablePlugins(dict_task):
    """ This method is to enable plugins """
    AgentLogger.log(AgentLogger.PLUGINS,' Enabling Plugins ---> '+repr(dict_task))
    str_section=AgentConstants.PLUGINS_SECTION
    str_option=AgentConstants.PLUGINS_ENABLED_KEY
    try:
        if AgentUtil.AGENT_CONFIG.has_section(str_section) and AgentUtil.AGENT_CONFIG.has_option(str_section,str_option):
            AgentUtil.AGENT_CONFIG.remove_section(AgentConstants.PLUGINS_SECTION)
            confFile = open(AgentConstants.AGENT_CONF_FILE,"w") 
            AgentUtil.AGENT_CONFIG.write(confFile)
        else:
            AgentLogger.log(AgentLogger.PLUGINS,' Plugins Already Enabled ---> {0}'.format(AgentUtil.AGENT_CONFIG.get(str_section, str_option)))
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "-- Exception while enabling plugin --")
        traceback.print_exc()

def configurePluginCount(dict_task):
    """ This method is to configure plugin count """
    AgentLogger.log(AgentLogger.PLUGINS,' Plugin Count Configuration ---> '+repr(dict_task))
    try:
        if dict_task['count'] and dict_task['count'].isdigit():
            AgentUtil.AGENT_CONFIG.set('AGENT_INFO','count',dict_task['count'])
            confFile = open(AgentConstants.AGENT_CONF_FILE,"w") 
            AgentUtil.AGENT_CONFIG.write(confFile)
        else:
            AgentLogger.log(AgentLogger.PLUGINS,' Plugin Configuration Not Updated ---> ')
            AgentLogger.log(AgentLogger.PLUGINS,' Count Value Not a Number ---> '+repr(dict_task))
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "-- Exception while modifying plugin count --")
        traceback.print_exc()
    
def CleanPluginFolder(dict_task):
    bool_CleanUp=False
    folderToDelete=None
    import shutil
    try:
        pluginName = dict_task['PLUGIN_NAME']
        folderToDelete,fileExt = os.path.splitext(pluginName)
        toCleanUp = AgentConstants.AGENT_PLUGINS_DIR+folderToDelete
        if '.' not in toCleanUp:
            if os.path.exists(toCleanUp):
               shutil.rmtree(AgentConstants.AGENT_PLUGINS_DIR+folderToDelete)
            rediscoverDeletedPlugins(dict_task)
            bool_CleanUp=True
        else:
            AgentLogger.log(AgentLogger.PLUGINS, "Clean up failed due to illegal plugin file name")
    except Exception as e:
        AgentLogger.log(AgentLogger.PLUGINS, "-- Exception while deleting plugin folder --")
        traceback.print_exc()
    finally:
        if bool_CleanUp:
            AgentLogger.log(AgentLogger.PLUGINS, "Plugin Cleaned Up Successfully {0}".format(folderToDelete))
