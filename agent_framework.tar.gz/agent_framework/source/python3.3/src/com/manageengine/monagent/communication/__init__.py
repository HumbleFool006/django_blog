#$Id$
import traceback

from com.manageengine.monagent import AgentConstants
from com.manageengine.monagent.logger import AgentLogger
import com.manageengine.monagent.communication.UdpHandler
from com.manageengine.monagent.communication.UdpHandler import SysLogParser, SysLogCollector, UdpServer
from com.manageengine.monagent.communication.BasicClientHandler import PortHandler,URLHandler, FileHandler


def initialize():
    try:
        UdpHandler.SysLogUtil = SysLogParser()
        BasicClientHandler.PortUtil = PortHandler()
        BasicClientHandler.URLUtil = URLHandler()
        AgentLogger.log(AgentLogger.MAIN,'==== FILE MONITORING NOT SUPPORTED {} ==== {}'.format(repr(AgentConstants.OS_NAME), str(AgentConstants.FILE_MON_SUPPORTED)))
        if AgentConstants.OS_NAME in AgentConstants.FILE_MON_SUPPORTED:
            BasicClientHandler.FileMonUtil = FileHandler()
        UdpHandler.SysLogStatsUtil = SysLogCollector()
        UdpHandler.UDP_SERVER = UdpServer(AgentConstants.UDP_SERVER_IP, AgentConstants.UDP_PORT)
        UdpHandler.UDP_SERVER.start()
    except Exception as e:
        AgentLogger.log([AgentLogger.STDERR], ' *************************** Exception while initialising communication module *************************** '+ repr(e))
        traceback.print_exc()

#initialize()
