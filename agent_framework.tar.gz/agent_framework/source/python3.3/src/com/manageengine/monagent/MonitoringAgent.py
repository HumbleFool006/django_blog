#$Id$
import traceback
import os
import fcntl
import sys
AGENT_WORKING_DIR = os.path.dirname(os.path.dirname(os.path.realpath(sys.argv[0])))
if os.path.isfile(os.path.join(AGENT_WORKING_DIR, "virtual_env")):
    AGENT_VENV_DIR = os.path.dirname(os.path.dirname(AGENT_WORKING_DIR))
    sys.path.append(AGENT_VENV_DIR)
from com.manageengine.monagent import AgentConstants

from com.manageengine import monagent

from com.manageengine.monagent.logger import AgentLogger
AgentLogger.initialize(AgentConstants.AGENT_LOGGING_CONF_FILE, AgentConstants.AGENT_LOG_DIR)
AgentLogger.log(AgentLogger.MAIN,'====================================================== STARTING AGENT ====================================================== \n\n')
from com.manageengine.monagent import AgentInitializer
from com.manageengine.monagent.util import AgentUtil, AgentBuffer

def init_agent():
    try:
        AgentConstants.APPLICATION_LOCK = open(AgentConstants.AGENT_LOCK_FILE, 'w')
        try:
            fcntl.lockf(AgentConstants.APPLICATION_LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except IOError:
            print('Site24x7 monitoring agent is already running')
            sys.exit(1)
    except Exception as e:
        print('Please login as root or use sudo to run Site24x7 monitoring agent')
        traceback.print_exc()
        sys.exit(1)

# Daemon Threads:
#    Memory Manager
#    Status Thread

# Non-Daemon Threads:(Must complete the specified task and then terminate)
#    Scheduler and its Worker Threads
#    File Uploader
#    Request Server Thread


def agent_main():
    try:
        #check if uninstall flag file is present
        if os.path.exists(AgentConstants.AGENT_UNINSTALL_FLAG_FILE):
            AgentLogger.log(AgentLogger.MAIN,'\n ======================================= UNINSTALL MONITORING AGENT ======================================= ')
            return False
        #shutdown listener
        AgentUtil.shutdownListener()
        if not AgentInitializer.initialize():
            AgentLogger.log([AgentLogger.MAIN, AgentLogger.CRITICAL],'\n ************************* Problem While Initializing Agent. Hence Quiting!!! ************************* ')
            return False        
    except Exception as e:
        AgentLogger.log([AgentLogger.MAIN, AgentLogger.CRITICAL],'\n *************************** Exception While Initializing Agent *************************** '+ repr(e))
        traceback.print_exc()
        return False         
    return True

def start_agent():
    init_agent()
    
    try:
        if not agent_main():
            AgentLogger.log([AgentLogger.MAIN,AgentLogger.CRITICAL],'************************* PROBLEM WHILE STARTING AGENT. HENCE QUITING!!! ************************* ')
        else:
            AgentLogger.log(AgentLogger.MAIN,'=============================== AGENT STARTED SUCCESSFULLY =============================== \n')
            while not AgentUtil.TERMINATE_AGENT:                        
                AgentUtil.TERMINATE_AGENT_NOTIFIER.wait(AgentConstants.AGENT_SLEEP_INTERVAL)
                # Prevent conf backup when shutdown is initiated.
                if not AgentUtil.TERMINATE_AGENT:
                    AgentUtil.backupConfFile()
    except Exception as e:        
        AgentLogger.log(AgentLogger.CRITICAL,'************************* PROBLEM WHILE STARTING AGENT. HENCE QUITING!!! ************************* '+ repr(e))        
    finally:
        AgentUtil.TerminateAgent()
        AgentUtil.cleanAll()

if __name__ == '__main__':
    start_agent()
        

        
