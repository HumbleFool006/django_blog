
'''
@author: Sriram VS

Script Executor - schedules one time or periodic execution of scripts

'''
#$Id$
import json
import os
import time
import traceback
from com.manageengine.monagent.logger import AgentLogger
from com.manageengine.monagent.actions.ScriptHandler import scriptHandler 
from com.manageengine.monagent.scheduler import AgentScheduler
from com.manageengine.monagent.scheduler.AgentScheduler import Scheduler

ID_VS_TASK = {}

#TODO - Edit Update action - Store a map with [ script id vs scheduler object ]
def scriptExecutor(task_list=None):
    global ID_VS_TASK
    try:
        for dict_task in task_list:
            interval=0
            key=dict_task['SCRIPT_ID']
            if key in ID_VS_TASK:
                removeSchedule(key)
            scheduleInfo = AgentScheduler.ScheduleInfo()
            if 'schedule' in dict_task and dict_task['schedule']=='true':
                scheduleInfo.setIsPeriodic(True)
                interval = dict_task['interval']
            else:
                scheduleInfo.setIsPeriodic(False)
            task = executeScripts 
            taskArgs = dict_task
            scheduleInfo.setSchedulerName('AgentScheduler')
            scheduleInfo.setTaskName(key)
            scheduleInfo.setTime(time.time())
            scheduleInfo.setTask(task)
            scheduleInfo.setTaskArgs(taskArgs)
            scheduleInfo.setInterval(interval)
            scheduleInfo.setLogger(AgentLogger.STDOUT)
            AgentScheduler.schedule(scheduleInfo)
            AgentLogger.log(AgentLogger.STDOUT,'schedule info {0}'.format(scheduleInfo))
            ID_VS_TASK[key]=scheduleInfo
            AgentLogger.log(AgentLogger.STDOUT,'========= ID VS TASK ========'+repr(ID_VS_TASK))
    except Exception as e:
        traceback.print_exc()
            
def executeScripts(dict_task):
    AgentLogger.log(AgentLogger.STDOUT,'========= Task Invoked ========')
    sh = scriptHandler(dict_task)
    sh.run()
    
def removeSchedule(key):
    if key in ID_VS_TASK:
        AgentLogger.log(AgentLogger.STDOUT,'========= Deleting the Existing Task ========')
        scheduleInfo = AgentScheduler.ScheduleInfo()
        scheduleInfo.setSchedulerName('AgentScheduler')
        scheduleInfo.setTaskName(key)
        AgentScheduler.deleteSchedule(scheduleInfo)